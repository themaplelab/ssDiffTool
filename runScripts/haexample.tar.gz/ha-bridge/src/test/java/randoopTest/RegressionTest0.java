package randoopTest;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = true;
	public static int iteration = 0;
	
    @Test
    public void test001() throws Throwable {
		System.out.println("BEGIN iteration: "+ iteration);
        iteration+=1;
		System.out.println("BEGIN testset at: "+ System.currentTimeMillis());
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        spark.Request request5 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecurityData("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 21");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap6 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TOleV5eazHo=" + "'", str8.equals("TOleV5eazHo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo13 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "x1T290LjcjM=" + "'", str8.equals("x1T290LjcjM="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user14 = bridgeSecurity4.getAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "oKC+S8zP5xw=" + "'", str8.equals("oKC+S8zP5xw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PrnkV/IS3NQ=" + "'", str8.equals("PrnkV/IS3NQ="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "txIizSNdH3eKioe8bLtOyg==" + "'", str9.equals("txIizSNdH3eKioe8bLtOyg=="));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2W1XmTcQE70=" + "'", str8.equals("2W1XmTcQE70="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Y2vTuB4aQSM=" + "'", str8.equals("Y2vTuB4aQSM="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AwVWcWs70do=" + "'", str9.equals("AwVWcWs70do="));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap11 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "t2vfVmcFAQE=" + "'", str8.equals("t2vfVmcFAQE="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = bridgeSecurity4.decrypt("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 21");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1FG3Z42mGe0=" + "'", str8.equals("1FG3Z42mGe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap8 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sWlfYGK6wj4=" + "'", str6.equals("sWlfYGK6wj4="));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("AgdIXLa3mJ4shiCOK0ZmWQ==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str7 + "' != '" + "VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM=" + "'", str7.equals("VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM="));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        java.lang.Class<?> wildcardClass8 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2RbEaLaSkA0=" + "'", str6.equals("2RbEaLaSkA0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo11 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7kNn6a7CWfA=" + "'", str8.equals("7kNn6a7CWfA="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

	/*    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = bridgeSecurity4.decrypt("/0sfWrlxKe0=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "NjGz5/ZS/lc=" + "'", str8.equals("NjGz5/ZS/lc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
		}*/

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user11 = bridgeSecurity4.getAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "jl8x8ZYWN+M=" + "'", str8.equals("jl8x8ZYWN+M="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TPrK88314/8=" + "'", str9.equals("TPrK88314/8="));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "K5FRchIW16POn+n46jJdOw==" + "'", str9.equals("K5FRchIW16POn+n46jJdOw=="));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "jCNLOdazWrWnKbusv+YGWw==" + "'", str9.equals("jCNLOdazWrWnKbusv+YGWw=="));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "SJxM8FnahE4=" + "'", str8.equals("SJxM8FnahE4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap5 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "parP9kMQXrM=" + "'", str8.equals("parP9kMQXrM="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.findWhitelistUserByDeviceType("KksMosKUWUk=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "56VjvDJnxIA=" + "'", str8.equals("56VjvDJnxIA="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7BvxbNAok68=" + "'", str8.equals("7BvxbNAok68="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "f0/bhvLSu2HH2TJnjXzykQ==" + "'", str14.equals("f0/bhvLSu2HH2TJnjXzykQ=="));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean11 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "77EwZGgXRyg=" + "'", str8.equals("77EwZGgXRyg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap5 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        spark.Request request8 = null;
        com.bwssystems.HABridge.User user9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request8, user9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        boolean boolean13 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "K4bUHcq6tbc=" + "'", str8.equals("K4bUHcq6tbc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        spark.Request request8 = null;
        com.bwssystems.HABridge.User user9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request8, user9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = bridgeSecurity4.createWhitelistUser("AgdIXLa3mJ4shiCOK0ZmWQ==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "pcygyXNa82Q=" + "'", str6.equals("pcygyXNa82Q="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

	/*    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.decrypt("iSLTHMgtr34=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "s1qU8jU1EDg=" + "'", str6.equals("s1qU8jU1EDg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "s1qU8jU1EDg=" + "'", str9.equals("s1qU8jU1EDg="));
}*/

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "nC9QyZ7LSR4=" + "'", str8.equals("nC9QyZ7LSR4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "zZLPXBkS6gs5w9GI6VZXPw==" + "'", str14.equals("zZLPXBkS6gs5w9GI6VZXPw=="));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean15 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sdkkPlch6lk=" + "'", str8.equals("sdkkPlch6lk="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "t5qt2ykB6KZXOOE0euLOOQ==" + "'", str14.equals("t5qt2ykB6KZXOOE0euLOOQ=="));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM=");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7PYBf07+BZo=" + "'", str8.equals("7PYBf07+BZo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CWhS8RWBGm1cdO1TwIDkTA==" + "'", str9.equals("CWhS8RWBGm1cdO1TwIDkTA=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

	/*    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = bridgeSecurity4.decrypt("/0sfWrlxKe0=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
		}*/

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CSRcUQ9ptmQ=" + "'", str8.equals("CSRcUQ9ptmQ="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "H1dYNvRSaM8i8b3iHL+GjA==" + "'", str14.equals("H1dYNvRSaM8i8b3iHL+GjA=="));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        boolean boolean10 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LtqMHNW0jZHoVZAFOT4cdg==" + "'", str9.equals("LtqMHNW0jZHoVZAFOT4cdg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.Class<?> wildcardClass7 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.Class<?> wildcardClass6 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        spark.Request request7 = null;
        com.bwssystems.HABridge.User user8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.addAuthenticatedUser(request7, user8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "im9VMtNIThU=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3S/8yD545f0=" + "'", str8.equals("3S/8yD545f0="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AB605Ht+AM4=" + "'", str9.equals("AB605Ht+AM4="));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YhCmNGU/D1I=" + "'", str8.equals("YhCmNGU/D1I="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.lang.Class<?> wildcardClass7 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3QWgHibi3aA=" + "'", str6.equals("3QWgHibi3aA="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        boolean boolean8 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str15 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JTqN4px2MCA=" + "'", str8.equals("JTqN4px2MCA="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str15 + "' != '" + "vNDrmklA2z0=" + "'", str15.equals("vNDrmklA2z0="));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo9 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "42XjJdVi9So=" + "'", str6.equals("42XjJdVi9So="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str15 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request16 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/wNNWLyyVTI=" + "'", str8.equals("/wNNWLyyVTI="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6Hq0ClA79bQ=" + "'", str15.equals("6Hq0ClA79bQ="));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo10 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3PT5BNVV0Tk=" + "'", str6.equals("3PT5BNVV0Tk="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str15 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "MTWPrClTtW6Sx46QrxTwYw==" + "'", str9.equals("MTWPrClTtW6Sx46QrxTwYw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.Class<?> wildcardClass10 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "qBoEoMQ1svc=" + "'", str6.equals("qBoEoMQ1svc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "qBoEoMQ1svc=" + "'", str9.equals("qBoEoMQ1svc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user11 = bridgeSecurity4.getAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "FxeAdzGXxD41bNiXJSDcfA==" + "'", str9.equals("FxeAdzGXxD41bNiXJSDcfA=="));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap5 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean15 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1u1WCd7i5mEQI0H+mYq5xQ==" + "'", str9.equals("1u1WCd7i5mEQI0H+mYq5xQ=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray13 = bridgeSecurity4.validateWhitelistUser("Udvdl9L+Gi8=", "YbmZ3/rbft8=", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "iW++cjfuWX/7PapbRtprBw==" + "'", str9.equals("iW++cjfuWX/7PapbRtprBw=="));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "eObzeOB/bLA=" + "'", str6.equals("eObzeOB/bLA="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "mvGlrjD0zzw=" + "'", str6.equals("mvGlrjD0zzw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "2RbEaLaSkA0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "GFthVTzc9nY=");
        java.lang.String str11 = bridgeSecurity10.getSecurityDescriptorData();
        spark.Request request12 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity10.removeAuthenticatedUser(request12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "316rGwj1YO8=" + "'", str11.equals("316rGwj1YO8="));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        java.lang.String str11 = bridgeSecurity4.encrypt("IL84Zc5yzqk=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "HKiNpzK24Isj6aF//YckfA==" + "'", str9.equals("HKiNpzK24Isj6aF//YckfA=="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "wPEUA7mvNk0wEXxADeV0JA==" + "'", str11.equals("wPEUA7mvNk0wEXxADeV0JA=="));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("IL84Zc5yzqk=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.addUser(user10);
        spark.Request request12 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user13 = bridgeSecurity4.getAuthenticatedUser(request12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        spark.Request request7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.removeAuthenticatedUser(request7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        spark.Request request10 = null;
        com.bwssystems.HABridge.User user11 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request10, user11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BZw08KN6Anc=" + "'", str8.equals("BZw08KN6Anc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        java.lang.String str11 = bridgeSecurity4.encrypt("IL84Zc5yzqk=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "X9lhu15V42/pgCawYsTGhQ==" + "'", str9.equals("X9lhu15V42/pgCawYsTGhQ=="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "k3IA/fBHHrqDX49shdcUdw==" + "'", str11.equals("k3IA/fBHHrqDX49shdcUdw=="));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "WdxGd5SO9lDMeWH0MJHq7w==" + "'", str9.equals("WdxGd5SO9lDMeWH0MJHq7w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "k9jgL0Apdmc=" + "'", str9.equals("k9jgL0Apdmc="));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray13 = bridgeSecurity4.validateWhitelistUser("iIu7I4m7bzI=", "y7VqE+OV/hI=", true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ga1cyCoR8aw=" + "'", str6.equals("ga1cyCoR8aw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ga1cyCoR8aw=" + "'", str9.equals("ga1cyCoR8aw="));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        boolean boolean10 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap11 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "V//aUj/wzNpVQ+Btw4Md9Q==" + "'", str9.equals("V//aUj/wzNpVQ+Btw4Md9Q=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "WIyYVP0J09Y=" + "'", str9.equals("WIyYVP0J09Y="));
    }

	/*    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = bridgeSecurity4.decrypt("l3pzr192eg3u3idPv1PAYA==");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "mXBEhKHlMjE=" + "'", str8.equals("mXBEhKHlMjE="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wu8P9+7avsAIK8JpRmcGvg==" + "'", str14.equals("Wu8P9+7avsAIK8JpRmcGvg=="));
}*/

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "EBlw6aUc3IyQrBW60ScV4w==" + "'", str9.equals("EBlw6aUc3IyQrBW60ScV4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        spark.Request request12 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "7xn0OIhuTT4=" + "'", str6.equals("7xn0OIhuTT4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str15 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = bridgeSecurity4.findWhitelistUserByDeviceType("X0zos1V37jc=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "938yAZ9t5i0=" + "'", str8.equals("938yAZ9t5i0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str15 + "' != '" + "x7oqn7oLhx0=" + "'", str15.equals("x7oqn7oLhx0="));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "o3DpwjZiYHY=" + "'", str8.equals("o3DpwjZiYHY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

	/*    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        bridgeSecurity4.removeTestUsers();
        java.lang.String str14 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2pL0LYSiR0Q=" + "'", str8.equals("2pL0LYSiR0Q="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "8njCp8E4aAzcvaiGiVgNsXoQkePRDyaFbk/Ctv2tKxPa6Kat0vXpw86fsxzPgsVH" + "'", str14.equals("8njCp8E4aAzcvaiGiVgNsXoQkePRDyaFbk/Ctv2tKxPa6Kat0vXpw86fsxzPgsVH"));
}*/

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity6.validatePassword(user8);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        java.lang.String str11 = bridgeSecurity4.encrypt("IL84Zc5yzqk=");
        spark.Request request12 = null;
        com.bwssystems.HABridge.User user13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request12, user13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GeaEiRPu+AJKm1iI49YJZg==" + "'", str9.equals("GeaEiRPu+AJKm1iI49YJZg=="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XyS3x8Usg5tUbPn5bzqCFw==" + "'", str11.equals("XyS3x8Usg5tUbPn5bzqCFw=="));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        spark.Request request9 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user10 = bridgeSecurity4.getAuthenticatedUser(request9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "WooSl9MSaSw=" + "'", str8.equals("WooSl9MSaSw="));
    }

	/*    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("2RbEaLaSkA0=", "4X6XeKuEPTc=", false);
        spark.Request request19 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user20 = bridgeSecurity4.getAuthenticatedUser(request19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "QksNOAJyp4M=" + "'", str8.equals("QksNOAJyp4M="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray18);
		}*/

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        char[] charArray2 = new char[] { '#', '4' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "zu8lksnpsdI=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "zu8lksnpsdI=" + "'", str5.equals("zu8lksnpsdI="));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request18 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Ltn+cLe0MAs=" + "'", str8.equals("Ltn+cLe0MAs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9lbSUSt/T48=" + "'", str17.equals("9lbSUSt/T48="));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Y+RoKuH/ez2selqNg4uPmQ==" + "'", str9.equals("Y+RoKuH/ez2selqNg4uPmQ=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0CwOw9yDKs4=" + "'", str12.equals("0CwOw9yDKs4="));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LMrVpfaG9mk=" + "'", str9.equals("LMrVpfaG9mk="));
    }

	/*    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setUseLinkButton(false);
        spark.Request request19 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user20 = bridgeSecurity4.getAuthenticatedUser(request19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "SHfOYCZ7iSk=" + "'", str8.equals("SHfOYCZ7iSk="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
		}*/

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("Udvdl9L+Gi8=", "2X+4ikkL/ZL0tw6MbStYzEXTytXq0+n90pvtsURrry4=", true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "FRFPgvCngrI=" + "'", str8.equals("FRFPgvCngrI="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        boolean boolean13 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0hzWv0Bk32U=" + "'", str8.equals("0hzWv0Bk32U="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.lang.String str8 = bridgeSecurity4.encrypt("jx24Qv4r0a6MMiSBdf8RoA==");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean9 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BWhr3/b3q5GChUUo87MqIXxpmZ2yVMyhP64qHrRPqjU=" + "'", str8.equals("BWhr3/b3q5GChUUo87MqIXxpmZ2yVMyhP64qHrRPqjU="));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = bridgeSecurity4.createWhitelistUser("qEqWrj85d8U=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "llF4tp90pCY=" + "'", str8.equals("llF4tp90pCY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "IDWbYOJGkJ8=" + "'", str6.equals("IDWbYOJGkJ8="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean9 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+9y1huf+9VQ=" + "'", str6.equals("+9y1huf+9VQ="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

	/*    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean18 = bridgeSecurity4.isSecure();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap19 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "mOd06CAunEc=" + "'", str8.equals("mOd06CAunEc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap19);
		}*/

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        spark.Request request10 = null;
        com.bwssystems.HABridge.User user11 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request10, user11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aw/qNTTN+Rs=" + "'", str6.equals("aw/qNTTN+Rs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str12 = bridgeSecurity4.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("X0zos1V37jc=", "zN2czKA6V/g=", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "rNmlvSN10ROlsb4LKaK7qQ==" + "'", str9.equals("rNmlvSN10ROlsb4LKaK7qQ=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        bridgeSecurity4.removeTestUsers();
        spark.Request request14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "IBgBfSqBkd4=" + "'", str8.equals("IBgBfSqBkd4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        java.lang.String str8 = bridgeSecurity6.getSecurityDescriptorData();
        java.lang.String str9 = bridgeSecurity6.getSecurityDescriptorData();
        bridgeSecurity6.setSecurityData("mvGlrjD0zzw=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "uErXI5ZBhfw=" + "'", str8.equals("uErXI5ZBhfw="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "uErXI5ZBhfw=" + "'", str9.equals("uErXI5ZBhfw="));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8j7APiHmKu4=" + "'", str8.equals("8j7APiHmKu4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dx/reF/0M2n8SBz4BuN+uqSfFClbVOAD7RUCl0QXZoQ4G2A0I5ivwYxyfHN+ffK8" + "'", str13.equals("dx/reF/0M2n8SBz4BuN+uqSfFClbVOAD7RUCl0QXZoQ4G2A0I5ivwYxyfHN+ffK8"));
    }

	/*    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean18 = bridgeSecurity4.isSecure();
        java.lang.Class<?> wildcardClass19 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "B4KDRkG35Dg=" + "'", str8.equals("B4KDRkG35Dg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass19);
		}*/

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        boolean boolean7 = bridgeSecurity6.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        spark.Request request13 = null;
        com.bwssystems.HABridge.User user14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request13, user14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4DVn/9MnmZU=" + "'", str8.equals("4DVn/9MnmZU="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        boolean boolean13 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray17 = bridgeSecurity4.validateWhitelistUser("2RbEaLaSkA0=", "iGduU+OZvM9MDe7qZDqFvQ==", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9rq46+g7C4w=" + "'", str8.equals("9rq46+g7C4w="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

	/*    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str18 = bridgeSecurity4.decrypt("iIu7I4m7bzI=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7ZcuAHAp1Bc=" + "'", str8.equals("7ZcuAHAp1Bc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
		}*/

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "IuA/GwWtYYg=" + "'", str8.equals("IuA/GwWtYYg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str12 + "' != '" + "7gTLt9Yr8Bw=" + "'", str12.equals("7gTLt9Yr8Bw="));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        boolean boolean13 = bridgeSecurity4.isSettingsChanged();
        java.lang.Class<?> wildcardClass14 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BjRkURVhXYc=" + "'", str8.equals("BjRkURVhXYc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity6.addUser(user7);
        spark.Request request9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.removeAuthenticatedUser(request9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity6.addUser(user7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = bridgeSecurity6.findWhitelistUserByDeviceType("1OfhISHDeJ60titA5xYUKQ==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("B3kEANHfIwE=");
        boolean boolean9 = bridgeSecurity4.isSecure();
        java.lang.Class<?> wildcardClass10 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean14 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0LzdLxKMr7h9oqQBmljRUQ==" + "'", str9.equals("0LzdLxKMr7h9oqQBmljRUQ=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("DtwoFwev/HU=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Le6WHP2mvnY=" + "'", str8.equals("Le6WHP2mvnY="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "zhLMQWkFkds=" + "'", str9.equals("zhLMQWkFkds="));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        java.lang.String str11 = bridgeSecurity4.encrypt("IL84Zc5yzqk=");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.addUser(user14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yV6hqsXY0uJyqNbOJqL6TQ==" + "'", str9.equals("yV6hqsXY0uJyqNbOJqL6TQ=="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DRumfOTlB6WhgEW0GfXtew==" + "'", str11.equals("DRumfOTlB6WhgEW0GfXtew=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/BYZcIVllrY=" + "'", str8.equals("/BYZcIVllrY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo10 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "iB/OfhExi5g=" + "'", str6.equals("iB/OfhExi5g="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "iB/OfhExi5g=" + "'", str9.equals("iB/OfhExi5g="));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        spark.Request request13 = null;
        com.bwssystems.HABridge.User user14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request13, user14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "XgxUjKFw89k=" + "'", str8.equals("XgxUjKFw89k="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

	/*    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("2RbEaLaSkA0=", "4X6XeKuEPTc=", false);
        bridgeSecurity4.removeTestUsers();
        java.lang.String str21 = bridgeSecurity4.createWhitelistUser("");
        spark.Request request22 = null;
        com.bwssystems.HABridge.User user23 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request22, user23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "FGKXYVPI5ng=" + "'", str8.equals("FGKXYVPI5ng="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str21 + "' != '" + "be8debfebe1541ee911b45aed02eb89a" + "'", str21.equals("be8debfebe1541ee911b45aed02eb89a"));
}*/

	/*    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "s/EPe03Ndr0=" + "'", str8.equals("s/EPe03Ndr0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap17);
		}*/

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity6.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo9 = bridgeSecurity6.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        bridgeSecurity4.setSecurityData("VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM=");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.delUser(user9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = bridgeSecurity4.findWhitelistUserByDeviceType("QuUi1O2bGWo=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("B3kEANHfIwE=");
        boolean boolean9 = bridgeSecurity4.isSecure();
        com.bwssystems.HABridge.SecurityInfo securityInfo10 = bridgeSecurity4.getSecurityInfo();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo10);
    }

	/*    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("X0zos1V37jc=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap19 = null;
        bridgeSecurity4.setWhitelist(strMap19);
        bridgeSecurity4.setSecureHueApi(false);
        java.lang.String str24 = bridgeSecurity4.findWhitelistUserByDeviceType("/0sfWrlxKe0=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "jKXiZEFoNbw=" + "'", str8.equals("jKXiZEFoNbw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str24);
		}*/

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        java.lang.Class<?> wildcardClass9 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9MofHCzqg+4=" + "'", str8.equals("9MofHCzqg+4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.lang.String str8 = bridgeSecurity4.encrypt("jx24Qv4r0a6MMiSBdf8RoA==");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean11 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ZPC84OHlHrAyKQ+ofraY6RrZ/UB7Bc7ODe//EEdB4Vw=" + "'", str8.equals("ZPC84OHlHrAyKQ+ofraY6RrZ/UB7Bc7ODe//EEdB4Vw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str12 = bridgeSecurity4.getExecGarden();
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Sth5gjT71D1smRtAhaFLqg==" + "'", str9.equals("Sth5gjT71D1smRtAhaFLqg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.addUser(user12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AL3Xe68avOg=" + "'", str9.equals("AL3Xe68avOg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

	/*    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setUseLinkButton(false);
        spark.Request request19 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "J8J+nVVEDNU=" + "'", str8.equals("J8J+nVVEDNU="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
		}*/

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "z8RsrvDvioo=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "2RbEaLaSkA0=");
        java.lang.String str10 = bridgeSecurity8.encrypt("P+48NszqJgg=");
        java.lang.String str11 = bridgeSecurity8.getExecGarden();
        spark.Request request12 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity8.removeAuthenticatedUser(request12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hwt8njKe82RDJ26bw4a9Jg==" + "'", str10.equals("hwt8njKe82RDJ26bw4a9Jg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2RbEaLaSkA0=" + "'", str11.equals("2RbEaLaSkA0="));
    }

	/*    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        bridgeSecurity6.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str11 = bridgeSecurity6.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str13 = bridgeSecurity6.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        bridgeSecurity6.setSettingsChanged(false);
        spark.Request request16 = null;
        com.bwssystems.HABridge.User user17 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.addAuthenticatedUser(request16, user17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "c4575a438bb6435589b2c5ca6090718a" + "'", str11.equals("c4575a438bb6435589b2c5ca6090718a"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str13);
		}*/

	/*    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        bridgeSecurity6.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str11 = bridgeSecurity6.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str13 = bridgeSecurity6.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity6.validatePassword(user14);
        java.lang.String str17 = bridgeSecurity6.createWhitelistUser("DP+amTMQbfE=");
        bridgeSecurity6.setSecurityData("FE3nwIKvRM4=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1e6b066dadf640249b352da37a9a8b31" + "'", str11.equals("1e6b066dadf640249b352da37a9a8b31"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str17 + "' != '" + "7470b79660ec4ec6bdb05ce895787ccd" + "'", str17.equals("7470b79660ec4ec6bdb05ce895787ccd"));
}*/

	/*    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        boolean boolean12 = bridgeSecurity4.isSecureHueApi();
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PohoFl8vIwM=" + "'", str6.equals("PohoFl8vIwM="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
		}*/

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = bridgeSecurity4.createWhitelistUser("iGduU+OZvM9MDe7qZDqFvQ==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1YFa/3jtFnI=" + "'", str9.equals("1YFa/3jtFnI="));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.addUser(user10);
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "VMud6NE8qaE=" + "'", str8.equals("VMud6NE8qaE="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        bridgeSecurity4.setSettingsChanged(false);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9oW/iOvr4ANwFiOvzXY5MA==" + "'", str9.equals("9oW/iOvr4ANwFiOvzXY5MA=="));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.delUser(user10);
        spark.Request request12 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user13 = bridgeSecurity4.getAuthenticatedUser(request12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "OSQcTDw9LN4=" + "'", str9.equals("OSQcTDw9LN4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean15 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "LdyPG0Ouqaw=" + "'", str8.equals("LdyPG0Ouqaw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "QK3r0eR+oi4sJOEmhJdOcA==" + "'", str14.equals("QK3r0eR+oi4sJOEmhJdOcA=="));
    }

	/*    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("B3kEANHfIwE=");
        boolean boolean9 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setUseLinkButton(false);
        spark.Request request12 = null;
        com.bwssystems.HABridge.User user13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request12, user13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
		}*/

	/*    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean18 = bridgeSecurity4.isSecure();
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray22 = bridgeSecurity4.validateWhitelistUser("2pL0LYSiR0Q=", "FO9EdHCyNNwc/VWTKzgU1A==", false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "fzQnhLc++do=" + "'", str8.equals("fzQnhLc++do="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray22);
		}*/

	/*    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("B3kEANHfIwE=");
        boolean boolean9 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setUseLinkButton(false);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
		}*/

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "C+JPE4TpKoE=" + "'", str6.equals("C+JPE4TpKoE="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

	/*    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("X0zos1V37jc=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap19 = null;
        bridgeSecurity4.setWhitelist(strMap19);
        bridgeSecurity4.setSecureHueApi(false);
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.setPassword(user23);
        boolean boolean25 = bridgeSecurity4.isUseLinkButton();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "U1to02nMuwg=" + "'", str8.equals("U1to02nMuwg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
		}*/

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM=");
        java.lang.String str8 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "N2+WlD2gf/DFUAhIkubcsRQM0xnsVdfCyTRhj0JIOwtkk0ntQTHwZDJsTxLFFTNY" + "'", str8.equals("N2+WlD2gf/DFUAhIkubcsRQM0xnsVdfCyTRhj0JIOwtkk0ntQTHwZDJsTxLFFTNY"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str11 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "OXgZn+Yt674=" + "'", str8.equals("OXgZn+Yt674="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "KyhlaAJ7QZo=" + "'", str11.equals("KyhlaAJ7QZo="));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = bridgeSecurity4.createWhitelistUser("2RbEaLaSkA0=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("w652SAwN9/WH9SG5poRryg==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5NtkNDW6YdI=" + "'", str8.equals("5NtkNDW6YdI="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Ii48ePh4ocM=" + "'", str8.equals("Ii48ePh4ocM="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "zZEHBlrXNC4=" + "'", str6.equals("zZEHBlrXNC4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        bridgeSecurity4.setSettingsChanged(false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = bridgeSecurity4.createWhitelistUser("NIcjHHV86dY=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GwjBuOQeg8IJ6sOzkrfxzQ==" + "'", str9.equals("GwjBuOQeg8IJ6sOzkrfxzQ=="));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = bridgeSecurity4.createWhitelistUser("zu8lksnpsdI=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("dY+wPgQ6Wci3Pe/ctX8Hn8X88Pg6+LW8zOlTYfvFirE=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TDbV3PHuIn0=" + "'", str8.equals("TDbV3PHuIn0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        java.lang.String str15 = bridgeSecurity4.encrypt("2pL0LYSiR0Q=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "L+rezViVwSHxKGyGzjrbNg==" + "'", str9.equals("L+rezViVwSHxKGyGzjrbNg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AA5ae3yOYhSpGhy+69shYg==" + "'", str15.equals("AA5ae3yOYhSpGhy+69shYg=="));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sxpXHVekk6s=" + "'", str8.equals("sxpXHVekk6s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "p2WKGzMS2HsFqSVMf/nDoA==" + "'", str14.equals("p2WKGzMS2HsFqSVMf/nDoA=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity6.validatePassword(user8);
        bridgeSecurity6.setSecurityData("8+39rNDzQsc=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
    }

	/*    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("2RbEaLaSkA0=", "4X6XeKuEPTc=", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass19 = hueErrorArray18.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AbfLKU6fg04=" + "'", str8.equals("AbfLKU6fg04="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray18);
		}*/

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("X0zos1V37jc=");
        java.lang.String str20 = bridgeSecurity4.createWhitelistUser("zu8lksnpsdI=");
        boolean boolean21 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9IHPAkCYduI=" + "'", str8.equals("9IHPAkCYduI="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str20 + "' != '" + "e831e9e107b942fca04145618da2cc50" + "'", str20.equals("e831e9e107b942fca04145618da2cc50"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str15 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+OWCANbxtic=" + "'", str8.equals("+OWCANbxtic="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Mk+ql7gH1BM=" + "'", str15.equals("Mk+ql7gH1BM="));
    }

	/*    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        bridgeSecurity6.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str11 = bridgeSecurity6.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str13 = bridgeSecurity6.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity6.setPassword(user14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "b05d5ef9389b4f52aa8653ea49298cfc" + "'", str11.equals("b05d5ef9389b4f52aa8653ea49298cfc"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
		}*/

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "tF14rWEeiqs=" + "'", str8.equals("tF14rWEeiqs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "H1Uiy61G4GBZzgrFNBNpzg==" + "'", str14.equals("H1Uiy61G4GBZzgrFNBNpzg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        char[] charArray2 = new char[] { '#', '4' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "zu8lksnpsdI=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

	/*    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("B3kEANHfIwE=");
        boolean boolean9 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setUseLinkButton(false);
        java.lang.String str12 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/0sfWrlxKe0=" + "'", str12.equals("/0sfWrlxKe0="));
		}*/

	/*    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        java.lang.String str11 = bridgeSecurity4.encrypt("IL84Zc5yzqk=");
        char[] charArray14 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity16 = new com.bwssystems.HABridge.BridgeSecurity(charArray14, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity18 = new com.bwssystems.HABridge.BridgeSecurity(charArray14, "X0zos1V37jc=");
        java.lang.String str19 = bridgeSecurity18.getExecGarden();
        bridgeSecurity18.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str23 = bridgeSecurity18.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str25 = bridgeSecurity18.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap26 = bridgeSecurity18.getWhitelist();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BpBcRBHtrXsmdI22JGbW9A==" + "'", str9.equals("BpBcRBHtrXsmdI22JGbW9A=="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CG0qE92T+6F94Vs0GfLf2A==" + "'", str11.equals("CG0qE92T+6F94Vs0GfLf2A=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "X0zos1V37jc=" + "'", str19.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1f3ab282cb1f480e9dcb1b17d3d48bf6" + "'", str23.equals("1f3ab282cb1f480e9dcb1b17d3d48bf6"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap26);
		}*/

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str13 = bridgeSecurity4.encrypt("VXWjsrU83xU=");
        java.lang.String str14 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Nfy2GVRSDkdu46AHsosnzA==" + "'", str9.equals("Nfy2GVRSDkdu46AHsosnzA=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str13 + "' != '" + "xe82liTz4a0+pdr8DKR7HQ==" + "'", str13.equals("xe82liTz4a0+pdr8DKR7HQ=="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "KSji4K7lLcw=" + "'", str14.equals("KSji4K7lLcw="));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        char[] charArray2 = new char[] { '#', '4' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "zu8lksnpsdI=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Udvdl9L+Gi8=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        spark.Request request11 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1/kMR+6EOqo=" + "'", str8.equals("1/kMR+6EOqo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

	/*    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("B3kEANHfIwE=");
        boolean boolean9 = bridgeSecurity4.isSecure();
        java.lang.String str11 = bridgeSecurity4.encrypt("fACjdGNujck=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ifSUGbAqrtQ8bYwcKec/Iw==" + "'", str11.equals("ifSUGbAqrtQ8bYwcKec/Iw=="));
}*/

	/*    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("Udvdl9L+Gi8=");
        java.lang.String str11 = bridgeSecurity4.createWhitelistUser("2X+4ikkL/ZL0tw6MbStYzEXTytXq0+n90pvtsURrry4=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "jUFtdK0k0bo=" + "'", str6.equals("jUFtdK0k0bo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2b44ebcfac24414b8dec209d26a9a1e6" + "'", str11.equals("2b44ebcfac24414b8dec209d26a9a1e6"));
}*/

	/*    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean18 = bridgeSecurity4.isSecure();
        java.lang.String str19 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("7470b79660ec4ec6bdb05ce895787ccd");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "KmHREBqDvrg=" + "'", str8.equals("KmHREBqDvrg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1oj5YlrCyku1OcepoAw0sbR3iVCo+4cW+c7drh06kVsB1u4RMumARBjM0rXLHuVX" + "'", str19.equals("1oj5YlrCyku1OcepoAw0sbR3iVCo+4cW+c7drh06kVsB1u4RMumARBjM0rXLHuVX"));
}*/

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "eKnUamiVTdw=" + "'", str8.equals("eKnUamiVTdw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        spark.Request request12 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user13 = bridgeSecurity4.getAuthenticatedUser(request12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AEXnk5sAx/PkG9H66r0aaA==" + "'", str9.equals("AEXnk5sAx/PkG9H66r0aaA=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap11 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HLOxLluOBWw=" + "'", str6.equals("HLOxLluOBWw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

	/*    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str16 = bridgeSecurity4.encrypt("7gTLt9Yr8Bw=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "56Z5EBwugSvt390jAvsoEA==" + "'", str9.equals("56Z5EBwugSvt390jAvsoEA=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "b1QdiTYw8k6T/oSy9CaYWw==" + "'", str16.equals("b1QdiTYw8k6T/oSy9CaYWw=="));
}*/

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        bridgeSecurity4.setSecurityData("VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM=");
        spark.Request request9 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user10 = bridgeSecurity4.getAuthenticatedUser(request9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("jx24Qv4r0a6MMiSBdf8RoA==");
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.setPassword(user8);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray13 = bridgeSecurity4.validateWhitelistUser("ZPU9vGh+HDjoE2CwJ9td6g==", "f4UfQ6X+ZxU=", true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str7 + "' != '" + "H62mqGf5t8gyxs7ZMpzHOmBL4BFf0RN0WxGq4pdTARk=" + "'", str7.equals("H62mqGf5t8gyxs7ZMpzHOmBL4BFf0RN0WxGq4pdTARk="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str12 = bridgeSecurity4.getExecGarden();
        spark.Request request13 = null;
        com.bwssystems.HABridge.User user14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request13, user14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0gPlnpy6pheVJ/G2OwJ5XQ==" + "'", str9.equals("0gPlnpy6pheVJ/G2OwJ5XQ=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

	/*    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = bridgeSecurity4.decrypt("Yw7eHBjsqSE=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
		}*/

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        java.lang.String str8 = bridgeSecurity6.getSecurityDescriptorData();
        java.lang.String str10 = bridgeSecurity6.encrypt("y7VqE+OV/hI=");
        java.lang.String str11 = bridgeSecurity6.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1NDTFlCtvms=" + "'", str8.equals("1NDTFlCtvms="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str10 + "' != '" + "W9m4aJiHjTomqI3hjsq+Yg==" + "'", str10.equals("W9m4aJiHjTomqI3hjsq+Yg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "X0zos1V37jc=" + "'", str11.equals("X0zos1V37jc="));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.addUser(user10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = bridgeSecurity4.createWhitelistUser("utCj36DblUA=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "OE6MqcBzecs=" + "'", str8.equals("OE6MqcBzecs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "2RbEaLaSkA0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "GFthVTzc9nY=");
        java.lang.Class<?> wildcardClass11 = charArray2.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

	/*    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("X0zos1V37jc=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap19 = null;
        bridgeSecurity4.setWhitelist(strMap19);
        bridgeSecurity4.setSecureHueApi(false);
        char[] charArray25 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity27 = new com.bwssystems.HABridge.BridgeSecurity(charArray25, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity29 = new com.bwssystems.HABridge.BridgeSecurity(charArray25, "X0zos1V37jc=");
        java.lang.String str30 = bridgeSecurity29.getExecGarden();
        bridgeSecurity29.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str34 = bridgeSecurity29.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str36 = bridgeSecurity29.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap37 = bridgeSecurity29.getWhitelist();
        bridgeSecurity4.setWhitelist(strMap37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hgucCXZP3lQ=" + "'", str8.equals("hgucCXZP3lQ="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "X0zos1V37jc=" + "'", str30.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str34 + "' != '" + "b8325e059985453e822f106cb64dfbad" + "'", str34.equals("b8325e059985453e822f106cb64dfbad"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap37);
		}*/

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("y7VqE+OV/hI=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str15 = bridgeSecurity4.findWhitelistUserByDeviceType("5a720cae94044210ba30433c86a3b96a");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4Ai2eD8d2fgpABgiCIpwHg==" + "'", str9.equals("4Ai2eD8d2fgpABgiCIpwHg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        java.lang.Class<?> wildcardClass17 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "oNapjfuCLDU=" + "'", str8.equals("oNapjfuCLDU="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "w+LZcjvNr54=" + "'", str8.equals("w+LZcjvNr54="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

	/*    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean18 = bridgeSecurity4.isSecure();
        java.lang.String str19 = bridgeSecurity4.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = bridgeSecurity4.getWhitelist();
        spark.Request request21 = null;
        com.bwssystems.HABridge.User user22 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request21, user22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "y5QkBzsrb0c=" + "'", str8.equals("y5QkBzsrb0c="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str19 + "' != '" + "gymiVRUQ9m7txfpmFjKl10DIWW1Z91rMO2v2ZijaVAYYejARSd9ersUlE4AA8G0x" + "'", str19.equals("gymiVRUQ9m7txfpmFjKl10DIWW1Z91rMO2v2ZijaVAYYejARSd9ersUlE4AA8G0x"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap20);
		}*/

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.delUser(user10);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "kQMaqQWHSek=" + "'", str8.equals("kQMaqQWHSek="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "8Sen0O7fbIY=" + "'", str9.equals("8Sen0O7fbIY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ry0K8B9preA=" + "'", str6.equals("ry0K8B9preA="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ry0K8B9preA=" + "'", str9.equals("ry0K8B9preA="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        char[] charArray2 = new char[] { '#', '4' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "zu8lksnpsdI=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "P+48NszqJgg=");
        bridgeSecurity6.setSecurityData("2X+4ikkL/ZL0tw6MbStYzEXTytXq0+n90pvtsURrry4=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

	/*    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        bridgeSecurity4.removeTestUsers();
        com.bwssystems.HABridge.SecurityInfo securityInfo14 = bridgeSecurity4.getSecurityInfo();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ccZMb8/AD1w=" + "'", str8.equals("ccZMb8/AD1w="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo14);
		}*/

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        spark.Request request12 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user13 = bridgeSecurity4.getAuthenticatedUser(request12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CGFWyYODlTQ=" + "'", str8.equals("CGFWyYODlTQ="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ob7IG6dqziY=" + "'", str9.equals("ob7IG6dqziY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
    }

	/*    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        bridgeSecurity6.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str11 = bridgeSecurity6.createWhitelistUser("2RbEaLaSkA0=");
        boolean boolean12 = bridgeSecurity6.isUseLinkButton();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0845cd87c5524618b0b32c2b2a1a1ebd" + "'", str11.equals("0845cd87c5524618b0b32c2b2a1a1ebd"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
		}*/

	/*    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.decrypt("JNdxb7HIQ9F/K/zyAe2XT3GEsznnIJHEBpAzLaBR5Y8=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/0sfWrlxKe0=" + "'", str8.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
		}*/

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "KmHREBqDvrg=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap9 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "gCihrjcWNm4=" + "'", str6.equals("gCihrjcWNm4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GdJmP8bJfIw=" + "'", str8.equals("GdJmP8bJfIw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        bridgeSecurity4.setSecurityData("VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM=");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        java.lang.String str11 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

	/*    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("Udvdl9L+Gi8=");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.decrypt("1c9299f4c2394d9b8f234fd1d09d4d55");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DEW+jhuaQac=" + "'", str6.equals("DEW+jhuaQac="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
		}*/

	/*    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        bridgeSecurity6.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str11 = bridgeSecurity6.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str13 = bridgeSecurity6.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity6.validatePassword(user14);
        char[] charArray18 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity20 = new com.bwssystems.HABridge.BridgeSecurity(charArray18, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity22 = new com.bwssystems.HABridge.BridgeSecurity(charArray18, "X0zos1V37jc=");
        java.lang.String str23 = bridgeSecurity22.getExecGarden();
        bridgeSecurity22.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str27 = bridgeSecurity22.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str29 = bridgeSecurity22.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap30 = bridgeSecurity22.getWhitelist();
        bridgeSecurity6.convertWhitelist(strMap30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "94e5fb7e921346109f66f9f2e1a46048" + "'", str11.equals("94e5fb7e921346109f66f9f2e1a46048"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "X0zos1V37jc=" + "'", str23.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1e23cfd0374e4bcaa7660c8ca45bf35b" + "'", str27.equals("1e23cfd0374e4bcaa7660c8ca45bf35b"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap30);
		}*/

	/*    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        boolean boolean12 = bridgeSecurity4.isSecureHueApi();
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user14 = bridgeSecurity4.getAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ucrHDvjRFnk=" + "'", str6.equals("ucrHDvjRFnk="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
		}*/

	/*    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = bridgeSecurity4.decrypt("0845cd87c5524618b0b32c2b2a1a1ebd");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
		}*/

	/*    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str19 = bridgeSecurity4.createWhitelistUser("z8RsrvDvioo=");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray23 = bridgeSecurity4.validateWhitelistUser("pobt1Nrdt7U=", "1c9299f4c2394d9b8f234fd1d09d4d55", false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "bLqXF/IcJ7U=" + "'", str8.equals("bLqXF/IcJ7U="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZQlYaL24kEGQAlyn2R+COzpU6b9+O1ZvLfwT0pBBBRpWiHSUwJNRqpdFw4hjd4vZ" + "'", str17.equals("ZQlYaL24kEGQAlyn2R+COzpU6b9+O1ZvLfwT0pBBBRpWiHSUwJNRqpdFw4hjd4vZ"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str19 + "' != '" + "74c4d28def084cf6b4018d01dfa9954b" + "'", str19.equals("74c4d28def084cf6b4018d01dfa9954b"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray23);
		}*/

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("jx24Qv4r0a6MMiSBdf8RoA==");
        bridgeSecurity4.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TaYLRUIBOdIsPlq+mM9vhw07vMXLYzMKdgYsiia0RdE=" + "'", str7.equals("TaYLRUIBOdIsPlq+mM9vhw07vMXLYzMKdgYsiia0RdE="));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.encrypt("IuA/GwWtYYg=");
        java.lang.String str18 = bridgeSecurity4.encrypt("mOd06CAunEc=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5CWl6VjKl98=" + "'", str8.equals("5CWl6VjKl98="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "WlXLjqDDrCbWb+YxNyj2mA==" + "'", str16.equals("WlXLjqDDrCbWb+YxNyj2mA=="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ubbPsteJyTgRzYeaRKrHqw==" + "'", str18.equals("ubbPsteJyTgRzYeaRKrHqw=="));
    }

	/*    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean18 = bridgeSecurity4.isSecure();
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.setPassword(user19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "oECoJb2ocaE=" + "'", str8.equals("oECoJb2ocaE="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
		}*/

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        java.lang.String str8 = bridgeSecurity6.getSecurityDescriptorData();
        boolean boolean9 = bridgeSecurity6.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0Skd4gTcVH4=" + "'", str8.equals("0Skd4gTcVH4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.encrypt("IuA/GwWtYYg=");
        bridgeSecurity4.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "jx4z3FJgdps=" + "'", str8.equals("jx4z3FJgdps="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "nB+8rpquEQux/BMc5hFVHA==" + "'", str16.equals("nB+8rpquEQux/BMc5hFVHA=="));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        bridgeSecurity4.setSecurityData("VlY4D0TWdnfw3CmVC3Pexw8LuS3twdyRy3C2R/2dSVM=");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.delUser(user11);
        java.lang.Class<?> wildcardClass13 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        java.lang.String str10 = bridgeSecurity4.decrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/0sfWrlxKe0=" + "'", str8.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
    }

	/*    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        bridgeSecurity4.removeTestUsers();
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.delUser(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9S+p8CeaSWQ=" + "'", str8.equals("9S+p8CeaSWQ="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "KbsG61JwCTw8GXCxrS2yuiP7Afoe3JSWZzy+XyOjJAq9Wad8Mvyg8x2D5A7zb1ln" + "'", str16.equals("KbsG61JwCTw8GXCxrS2yuiP7Afoe3JSWZzy+XyOjJAq9Wad8Mvyg8x2D5A7zb1ln"));
}*/

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("Udvdl9L+Gi8=");
        java.lang.String str10 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "gM7bsvjvGz8=" + "'", str6.equals("gM7bsvjvGz8="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

	/*    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("X0zos1V37jc=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap19 = null;
        bridgeSecurity4.setWhitelist(strMap19);
        bridgeSecurity4.setSecureHueApi(false);
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.setPassword(user23);
        com.bwssystems.HABridge.User user25 = null;
        java.lang.String str26 = bridgeSecurity4.addUser(user25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ekAXnLGqnP0=" + "'", str8.equals("ekAXnLGqnP0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "invalid user object given" + "'", str26.equals("invalid user object given"));
		}*/

	/*    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean18 = bridgeSecurity4.isSecure();
        java.lang.String str19 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str21 = bridgeSecurity4.decrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mf46quxSKbI=" + "'", str8.equals("Mf46quxSKbI="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str19 + "' != '" + "InOFv1Q/jMheO60TFzJb8vXxlmSRwJM618tHTfCRyH1Uk8R5qTRycwj8R2SYL2qM" + "'", str19.equals("InOFv1Q/jMheO60TFzJb8vXxlmSRwJM618tHTfCRyH1Uk8R5qTRycwj8R2SYL2qM"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
		}*/

	/*    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.SecurityInfo securityInfo15 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str19 = bridgeSecurity4.encrypt("LrDttcoB6tc=");
        boolean boolean20 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "fFXNJgG2/fU=" + "'", str8.equals("fFXNJgG2/fU="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo15);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str19 + "' != '" + "nHEK80Mz4uaqursz8j5Hmw==" + "'", str19.equals("nHEK80Mz4uaqursz8j5Hmw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
		}*/

	/*    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        bridgeSecurity4.convertWhitelist(strMap15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "EAUUhmgOPTI=" + "'", str8.equals("EAUUhmgOPTI="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
		}*/

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        java.lang.Class<?> wildcardClass17 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "V/AJzOOmdWM=" + "'", str8.equals("V/AJzOOmdWM="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("zu8lksnpsdI=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("X0zos1V37jc=");
        java.lang.String str19 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "zUdHdMN6Whg=" + "'", str8.equals("zUdHdMN6Whg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BN/nxpGWkOgqrUSCCokGsPV10En6OKjkPXSyR/ERs9jaDZgU2rLJdIfsYtIHu66X" + "'", str19.equals("BN/nxpGWkOgqrUSCCokGsPV10En6OKjkPXSyR/ERs9jaDZgU2rLJdIfsYtIHu66X"));
    }

	/*    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        boolean boolean12 = bridgeSecurity4.isUseLinkButton();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DJ9WNIhO34k=" + "'", str6.equals("DJ9WNIhO34k="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
		}*/

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        bridgeSecurity4.setSecurityData("");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

	/*    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "X0zos1V37jc=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        bridgeSecurity6.setSecurityData("2RbEaLaSkA0=");
        java.lang.String str11 = bridgeSecurity6.createWhitelistUser("2RbEaLaSkA0=");
        java.lang.String str13 = bridgeSecurity6.findWhitelistUserByDeviceType("IuA/GwWtYYg=");
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity6.validatePassword(user14);
        boolean boolean16 = bridgeSecurity6.isSecure();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "X0zos1V37jc=" + "'", str7.equals("X0zos1V37jc="));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "826570d99b3f4b7a98432b0610244b36" + "'", str11.equals("826570d99b3f4b7a98432b0610244b36"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
		}*/

	/*    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "/0sfWrlxKe0=");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("B3kEANHfIwE=");
        boolean boolean9 = bridgeSecurity4.isSecure();
        boolean boolean10 = bridgeSecurity4.isSecureHueApi();
        boolean boolean11 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/0sfWrlxKe0=" + "'", str5.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/0sfWrlxKe0=" + "'", str6.equals("/0sfWrlxKe0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
		}*/

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        bridgeSecurity4.setSettingsChanged(true);
        boolean boolean15 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "WCOI4GhHi0g=" + "'", str6.equals("WCOI4GhHi0g="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("im9VMtNIThU=");
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5FF6QPAdrd8=" + "'", str8.equals("5FF6QPAdrd8="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "u7bE1vhjXgT8Aznm8whuJQ==" + "'", str14.equals("u7bE1vhjXgT8Aznm8whuJQ=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        boolean boolean12 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "xJ4d/UJZiCk=" + "'", str6.equals("xJ4d/UJZiCk="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
		System.out.println("END testset at: "+ System.currentTimeMillis()); 
	}

	/*    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("z3wYw3Yqbarn2z6jhJlq3w==");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str13 = bridgeSecurity4.findWhitelistUserByDeviceType("2X+4ikkL/ZL0tw6MbStYzEXTytXq0+n90pvtsURrry4=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ZKeNvVXn6Yw=" + "'", str6.equals("ZKeNvVXn6Yw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str13);
		System.out.println("END testset at: "+ System.currentTimeMillis());
		}*/
}
