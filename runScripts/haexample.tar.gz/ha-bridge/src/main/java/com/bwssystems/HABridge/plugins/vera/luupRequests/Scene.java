package com.bwssystems.HABridge.plugins.vera.luupRequests;

public class Scene {
	private String active;
	private String name;
	private String id;
	private String room;
	private String veraname;
	private String veraaddress;
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getVeraname() {
		return veraname;
	}
	public void setVeraname(String veraname) {
		this.veraname = veraname;
	}
	public String getVeraaddress() {
		return veraaddress;
	}
	public void setVeraaddress(String veraaddress) {
		this.veraaddress = veraaddress;
	}
	
}
