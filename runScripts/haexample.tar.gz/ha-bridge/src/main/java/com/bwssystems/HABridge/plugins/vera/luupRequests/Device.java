package com.bwssystems.HABridge.plugins.vera.luupRequests;

public class Device {
	
	private String name;
	private String altid;
	private String id;
	private String category;
	private String subcategory;
	private String room;
	private String parent;
	private String status;
	private String level;
	private String state;
	private String comment;
	private String veraname;
	private String veraaddress;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAltid() {
		return altid;
	}
	public void setAltid(String altid) {
		this.altid = altid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubcategory() {
		return subcategory;
	}
	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getParent() {
		return parent;
	}
	public void setParent(String parent) {
		this.parent = parent;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getVeraname() {
		return veraname;
	}
	public void setVeraname(String veraname) {
		this.veraname = veraname;
	}
	public String getVeraaddress() {
		return veraaddress;
	}
	public void setVeraaddress(String veraaddress) {
		this.veraaddress = veraaddress;
	}
	
}
