package com.bwssystems.HABridge.plugins.fhem;

public class FHEMCommand {
	private String url;
	private String command;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}

}
