package com.bwssystems.HABridge;

public class LinkParams {
	private Integer seconds;
	private boolean silent;

	public Integer getSeconds() {
		return seconds;
	}
	public void setSeconds(Integer seconds) {
		this.seconds = seconds;
	}
	public boolean isSilent() {
		return silent;
	}
	public void setSilent(boolean silent) {
		this.silent = silent;
	}

}
