package com.bwssystems.HABridge.hue;

public class ColorMap {
	private double red;
	private double green;
	private double blue;
	private long R;
	private long G;
	private long B;
	private double X;
	private double Y;
	private Double Z;
	private double z;
	public double getRed() {
		return red;
	}
	public void setRed(double red) {
		this.red = red;
	}
	public double getGreen() {
		return green;
	}
	public void setGreen(double green) {
		this.green = green;
	}
	public double getBlue() {
		return blue;
	}
	public void setBlue(double blue) {
		this.blue = blue;
	}
	public long getR() {
		return R;
	}
	public void setR(long r) {
		R = r;
	}
	public long getG() {
		return G;
	}
	public void setG(long g) {
		G = g;
	}
	public long getB() {
		return B;
	}
	public void setB(long b) {
		B = b;
	}
	public double getX() {
		return X;
	}
	public void setX(double x) {
		X = x;
	}
	public double getY() {
		return Y;
	}
	public void setY(double y) {
		Y = y;
	}
	public Double getZ() {
		return Z;
	}
	public void setZ(Double z) {
		Z = z;
	}
	public double getz() {
		return z;
	}
	public void setz(double z) {
		this.z = z;
	}

}
