package com.bwssystems.HABridge.api.hue;

public class HueConstants {
	public final static String HUB_VERSION = "9999999999";
	public final static String API_VERSION = "1.19.0";
	public final static String MODEL_ID = "BSB002";
	public final static String UUID_PREFIX = "2f402f80-da50-11e1-9b23-";
}
