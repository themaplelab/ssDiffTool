package com.bwssystems.HABridge.devicemanagmeent;

public interface ResourceHandler {
	public Object getItems(String type);
	public void refresh();
}
