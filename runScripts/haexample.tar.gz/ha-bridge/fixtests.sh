#sed -i -E 's/(org\.junit\.Assert\.fail\(.*)(\))/\1\+System\.currentTimeMillis\(\)\2/g' src/test/java/randoopTest/RegressionTest0.java

#sed -i -E 's/(org\.junit\.Assert\.fail\(.*)(\))/\1\+System\.currentTimeMillis\(\)\2/g' src/test/java/randoopTest/RegressionTest1.java

#sed -i -E 's/(org\.junit\.Assert\.fail\(.*)(\))/\1\+System\.currentTimeMillis\(\)\2/g' src/test/java/randoopTest/RegressionTest2.java

#sed -i -E 's/(org\.junit\.Assert\.fail\(.*)(\))/\1\+System\.currentTimeMillis\(\)\2/g' src/test/java/randoopTest/RegressionTest3.java

sed -i -E 's/if \(debug\)//g' src/test/java/randoopTest/RegressionTest0.java  
