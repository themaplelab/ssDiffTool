mvn compile assembly:single -Dmaven.test.skip=true
