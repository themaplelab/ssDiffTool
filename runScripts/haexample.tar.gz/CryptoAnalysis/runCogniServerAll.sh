##############
#
# usage: ./runCogniServerAll.sh <reponame> <branch-name> <prefixcp> <extracp> <suffixcp> <experimentnumber>
###############

currentdir=$(pwd)
projectdir=/root/$1
branch=$2
prefixcp=$3
originaldir=$4
suffixdir=$5
i=$6

echo "--------------------"
echo "STARTING UP COGNISERVER"
echo "This is repo $1"
echo "This is misuse num $2"
echo "This is prefixcp $3"
echo "This is extracp $4"
echo "This is suffixdir $5"
echo "This is experiment number $i"
echo "--------------------"


redefdir=${projectdir}/patch/$branch
patchlist=$currentdir/allpatchesMU.out

ssDiff="/root/ssDiffTool/target/ssDiffTool-1.0-SNAPSHOT-jar-with-dependencies.jar"
rtjce="/root/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/images/j2sdk-image/jre/lib/rt.jar:/root/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/images/j2sdk-image/jre/lib/jce.jar"
cp=".:$ssDiff:$rtjce:${currentdir}/adapterOutput/"
rulesDir="/root/CryptoAnalysis/CryptoAnalysis/src/main/resources/JavaCryptographicArchitecture"
sootcp=$prefixcp:.:$ssDiff:$rtjce:${currentdir}/adapterOutput/:${redefdir}
differcp=$prefixcp:.:$ssDiff:$rtjce:${currentdir}/adapterOutput/:${redefdir}
cogni=/root/.m2/repository/de/darmstadt/tu/crossing/CrySL/de.darmstadt.tu.crossing.CrySL/2.0.0-SNAPSHOT/de.darmstadt.tu.crossing.CrySL-2.0.0-SNAPSHOT.jar

rm /root/${1}HotFixResults/ALL$branch.txt

touch /root/${1}HotFixResults/ALL$branch.txt

#checkURLTimestamps was for fixing a bug in scc access, really not sure why it happens
java -Dcom.ibm.j9ddr.structurefile=/root/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/vm/j9ddr.dat  -Xshareclasses:checkURLTimestamps,name=Cryptotest -Djava.library.path=$LD_LIBRARY_PATH:/root/openj9-openjdk-jdk8/openj9/runtime/ddrext:/root/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/jdk/classes/com/ibm/oti/shared/ -cp $prefixcp:$originaldir:/root/soot/target/sootclasses-trunk-jar-with-dependencies.jar:/root/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/jdk/ddr/classes/com/ibm/j9ddr/vm29/structure/:CryptoAnalysis/build/CryptoAnalysis-2.7.1-SNAPSHOT-jar-with-dependencies.jar:$cogni:/root/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/jdk/classes/com/ibm/oti/shared/:/root/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/images/j2sdk-image/jre/lib/ddr/j9ddr.jar:$cp:$suffixdir  crypto.TCPCryptoRunner --rulesDir=$rulesDir --patchlist=$patchlist -sootCp=$sootcp -redefcp $redefdir -differClasspath $differcp &> /root/${1}HotFixResults/ALL$branch.txt

