###############
# runs hotfixer
#
# Usage:
#   ./runALL.sh
#
###############
declare -a repos=(
    #"ha-bridge:misuse1and5"                                                                         
    #"ha-bridge:misuse2and7"                                                                         
    "ha-bridge:misuse3and8"
    #"ha-bridge:misuse4and6"
)

declare -a classespath=(
    #"/root/eval/ha-bridge/target/classes"
    #"/root/eval/ha-bridge/target/classes"
    #"/root/eval/ha-bridge/target/classes"
    "/root/ha-bridge/target/classes"
)
declare -a originaldir=(
	#"/root/eval/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"
	#"/root/eval/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"
	#"/root/eval/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"
	"/root/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"
	)

declare -a suffixdir=(

	"placeholder"
	#"placeholder"
	#"placeholder"
	#"placeholder"
)

declare -a testCommands=(

    #"mvn test -fae"
    #"mvn test -fae"
    #"mvn test -fae"
    "mvn test -fae"
)
declare -a testdirs=(

	#"src/test/java/randoopTest"
	#"src/test/java/randoopTest"
	"src/test/java/randoopTest"
	#"src/test/java/randoopTest"

)


#might want to start off with a fresh scc
#java -Xshareclasses:destroy,name=Cryptotest

for index in "${!repos[@]}"
do

	repo="$(cut -d':' -f1 <<<"${repos[index]}")"
	thisbranch="$(cut -d':' -f2 <<<"${repos[index]}")"
	testcommand="${testCommands[index]}"

	mkdir /root/${repo}HotFixResults
	mkdir /root/${repo}HotFixResults/adapterOutputs /root/${repo}HotFixResults/adapterOutputs/$thisbranch
	
	echo "THIS JUST UP: ${repos[index]}"
	echo $(date)
	echo "############################"
	echo "Using this classpath: ${classespath[index]}"

	
	#move around test file set for specific experiment
	#since each experiment has its own test file setup
	#start the run on the master branch, can do automatically if no changed files on current branch
	cd /root/$repo
	#git checkout master
	git branch
	#find . -name RegressionTest* | xargs rm
	#commented out bc prev set it up manually for this example
	#cp /root/alltests/$repo/$thisbranch/* /root/$repo/${testdirs[index]}
#	mvn test-compile
#	mvn compile
	
	for i in {1..1}
	do
		echo "THIS JUST UP: ${repos[index]} EXPERIMENT $i"
		echo "############################"
#		mkdir /root/allExp/adapterOutputs/${repo}/$thisbranch/$i
		
		
		cd /root/CryptoAnalysis/
		#<reponame> <branch-name> <prefixcp> <extracp> <suffixcp> <experimentnumber>  
		./runCogniServerAll.sh $repo $thisbranch ${classespath[index]} ${originaldir[index]} ${suffixdir[index]} $i &
		sleep 40
		cd /root/
		./runHotFixALL.sh $repo $thisbranch "$testcommand" $i
		

		find /root/CryptoAnalysis/adapterOutput -name "*.class" | xargs -I '{}' mv {} /root/${repo}HotFixResults/adapterOutputs/$thisbranch/
		
	done	

	
echo "############################"

done
