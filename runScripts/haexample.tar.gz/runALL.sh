###############
# runs hotfixer
#
# Usage:
#   ./runALL.sh
#
###############
#the not dones
#declare -a repos=(#     try last ha-bridge last again)
declare -a repos=(

#		"dragonite-java:misuse1" 
	#"instagram4j:misuse1"
 #                 "ha-bridge:misuse1and5"
  #                "ha-bridge:misuse2and7"
                  "ha-bridge:misuse3and8"
#                  "ha-bridge:misuse4and6"

     #             "jeesuite-libs:misuse1and4"
	#			      "jeesuite-libs:misuse2and5"
#                  "jeesuite-libs:misuse3"
     #             "jeesuite-libs:misuse6and7"
 #                 "jeesuite-libs:misuse8"
#                  "jeesuite-libs:misuse9"

         #         "NettyGameServer:misuse1"
#                  "NettyGameServer:misuse2and3"
    #          "NettyGameServer:misuse4"
#	"smart:misuse1and6"
       #           "smart:misuse2and5"
      #            "smart:misuse3"
     #             "smart:misuse4and7"
    #              "smart:misuse8"
#				  "whatsmars:misuse1and3"
 #                 "whatsmars:misuse2and4"
	#                 "whatsmars:misuse5and9"
#	"whatsmars:misuse6and11" 
	#                "whatsmars:misuse7and12"
#	"whatsmars:misuse8and10"
				  #               "whatsmars:misuse13")
				  )
declare -a classespath=(
	#	"/root/eval/dragonite-java/dragonite-sdk/build/classes/java/main/"
	#	"/root/eval/instagram4j/target/classes"
    #"/root/eval/ha-bridge/target/classes"
    #"/root/eval/ha-bridge/target/classes"
    #"/root/eval/ha-bridge/target/classes"
    "/root/eval/ha-bridge/target/classes"
    #"/root/eval/jeesuite-libs/jeesuite-common/target/classes"
    #"/root/eval/jeesuite-libs/jeesuite-common/target/classes"
    #"/root/eval/jeesuite-libs/jeesuite-common/target/classes"
   #"/root/eval/jeesuite-libs/jeesuite-common/target/classes"
   # "/root/eval/jeesuite-libs/jeesuite-common/target/classes"
  #  "/root/eval/jeesuite-libs/jeesuite-common/target/classes"
    "/root/eval/NettyGameServer/game-common/target/classes"
   # "/root/eval/NettyGameServer/game-common/target/classes"
    #"/root/eval/NettyGameServer/game-common/target/classes"
   #"/root/eval/smart/smart-sso/smart-sso-server/target/classes:/root/eval/smart/smart-mvc/target/classes"
   # "/root/eval/smart/smart-sso/smart-sso-server/target/classes:/root/eval/smart/smart-mvc/target/classes"
   # "/root/eval/smart/smart-sso/smart-sso-server/target/classes:/root/eval/smart/smart-mvc/target/classes"
   # "/root/eval/smart/smart-sso/smart-sso-server/target/classes:/root/eval/smart/smart-mvc/target/classes"
"/root/eval/whatsmars/whatsmars-common/target/classes"
"/root/eval/whatsmars/whatsmars-common/target/classes"
"/root/eval/whatsmars/whatsmars-common/target/classes"
"/root/eval/whatsmars/whatsmars-common/target/classes"
"/root/eval/whatsmars/whatsmars-common/target/classes")

declare -a originaldir=(
	#"placeholder"
	
	#"/root/eval/instagram4j/target/instagram4j-1.8-SNAPSHOT-jar-with-dependencies.jar"

	#"/root/eval/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"
	#"/root/eval/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"
	#"/root/eval/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"
	"/root/eval/ha-bridge/target/ha-bridge-5.2.2-jar-with-dependencies.jar"

	#"placeholder"
    #"placeholder"
    #"placeholder"
    "placeholder"
	"placeholder"
    "placeholder"

	"placeholder"
    "placeholder"
    "placeholder"
	
	"placeholder"
    "placeholder"
    "placeholder"
    "placeholder"
	
	"placeholder"
    "placeholder"
    "placeholder"
    "placeholder"
    "placeholder"
	)

declare -a suffixdir=(

	#"placeholder"

	"placeholder"

	#"placeholder"
    #"placeholder"
    #"placeholder"
    #"placeholder"
	
	#"placeholder"
   #"placeholder"
   # "placeholder"
    #"placeholder"
    #"placeholder"
   # "placeholder"

    "/root/eval/NettyGameServer/game-common/target/game-common-1.2.5-SNAPSHOT-jar-with-dependencies.jar"
    #"/root/eval/NettyGameServer/game-common/target/game-common-1.2.5-SNAPSHOT-jar-with-dependencies.jar"
   # "/root/eval/NettyGameServer/game-common/target/game-common-1.2.5-SNAPSHOT-jar-with-dependencies.jar"

    #"/root/eval/smartDeps/smart-sso-client-1.3.0.jar:/root/eval/smartDeps/smart-mvc-1.3.0.jar"
    #"/root/eval/smartDeps/smart-sso-client-1.3.0.jar:/root/eval/smartDeps/smart-mvc-1.3.0.jar"
    #"/root/eval/smartDeps/smart-sso-client-1.3.0.jar:/root/eval/smartDeps/smart-mvc-1.3.0.jar"
    #"/root/eval/smartDeps/smart-sso-client-1.3.0.jar:/root/eval/smartDeps/smart-mvc-1.3.0.jar"

    "placeholder"
    "placeholder"
    "placeholder"
    "placeholder"
    "placeholder"	
)

declare -a testCommands=(
	#"gradle test --info --rerun-tasks"

#	"mvn test -fae"

     #                    "mvn test -fae"
      #                   "mvn test -fae"
       #                  "mvn test -fae"
                         "mvn test -fae"

        #                 "cd jeesuite-common; mvn test -fae"
         #                "cd jeesuite-common; mvn test -fae -X"
          #               "cd jeesuite-common; mvn test -fae -X"
      #                   "cd jeesuite-common; mvn test -fae -X"
       #                  "cd jeesuite-common; mvn test -fae -X"
    #                     "cd jeesuite-common; mvn test -fae -X"

                         "mvn test -fae -X"
         #                "mvn test -fae -X"
		#				 "mvn test -fae -X"

	#					 "mvn clean compile test-compile; cp /root/eval/smartpom/pom.xml /root/eval/smart/smart-sso/smart-sso-server/ ;  cd smart-sso/smart-sso-server; mvn test -fae; git checkout -- /root/eval/smart/smart-sso/smart-sso-server/pom.xml"
		#				 "mvn clean compile test-compile; cp /root/eval/smartpom/pom.xml /root/eval/smart/smart-sso/smart-sso-server/ ;  cd smart-sso/smart-sso-server; mvn test -fae; git checkout -- /root/eval/smart/smart-sso/smart-sso-server/pom.xml"
		#				 "mvn clean compile test-compile; cp /root/eval/smartpom/pom.xml /root/eval/smart/smart-sso/smart-sso-server/ ;  cd smart-sso/smart-sso-server; mvn test -fae; git checkout -- /root/eval/smart/smart-sso/smart-sso-server/pom.xml"

		#				 "mvn clean compile test-compile; cp /root/eval/smartpom/pom.xml /root/eval/smart/smart-sso/smart-sso-server/ ;  cd smart-sso/smart-sso-server; mvn test -fae; git checkout -- /root/eval/smart/smart-sso/smart-sso-server/pom.xml"


						 "cd whatsmars-common; mvn test -fae"
                         "cd whatsmars-common; mvn test -fae"
                         "cd whatsmars-common; mvn test -fae"
                         "cd whatsmars-common; mvn test -fae"
                         "cd whatsmars-common; mvn test -fae")
declare -a testdirs=(
	#"dragonite-sdk/src/test/java/randoopTest/randoopTest/"

#	"src/test/java/randoopTest/randoopTest/"

	#"src/test/java/randoopTest"
	#"src/test/java/randoopTest"
	"src/test/java/randoopTest"
#	"src/test/java/randoopTest"

	#"jeesuite-common/src/test/java/randoopTest"
	#"jeesuite-common/src/test/java/randoopTest"
	#"jeesuite-common/src/test/java/randoopTest"
#	"jeesuite-common/src/test/java/randoopTest"
 #   "jeesuite-common/src/test/java/randoopTest"
    #"jeesuite-common/src/test/java/randoopTest"

	"game-common/src/test/java/randoopTest/randoopTest/"
 #   "game-common/src/test/java/randoopTest/randoopTest/"
    #"game-common/src/test/java/randoopTest/randoopTest/"

	#"smart-sso/smart-sso-server/src/test/java/randoopTest"
 #   "smart-sso/smart-sso-server/src/test/java/randoopTest"
  #  "smart-sso/smart-sso-server/src/test/java/randoopTest"
#	"smart-sso/smart-sso-server/src/test/java/randoopTest"

	"whatsmars-common/src/test/java/randoopTest"
    "whatsmars-common/src/test/java/randoopTest"
    "whatsmars-common/src/test/java/randoopTest"
	"whatsmars-common/src/test/java/randoopTest"
    "whatsmars-common/src/test/java/randoopTest"
)


#mkdir allExp allExp/adapterOutputs
#start off all exps with a fresh scc
#java -Xshareclasses:destroy,name=Cryptotest

for index in "${!repos[@]}"
do

	repo="$(cut -d':' -f1 <<<"${repos[index]}")"
    thisbranch="$(cut -d':' -f2 <<<"${repos[index]}")"
	testcommand="${testCommands[index]}"

#	mkdir /root/eval/allExp/${repo} /root/eval/allExp/${repo}/$thisbranch
#	mkdir /root/eval/allExp/adapterOutputs/${repo}/ /root/eval/allExp/adapterOutputs/${repo}/$thisbranch

	mkdir /root/eval/${repo}HotFixResults
	mkdir /root/eval/${repo}HotFixResults/adapterOutputs /root/eval/${repo}HotFixResults/adapterOutputs/$thisbranch
	
	echo "THIS JUST UP: ${repos[index]}"
	echo $(date)
    echo "############################"
	echo "Using this classpath: ${classespath[index]}"

	
	#fix test file set for specific experiment
	cd /root/eval/$repo
	#git checkout master
	git branch
	#find . -name RegressionTest* | xargs rm
	#cp /root/eval/alltests/$repo/$thisbranch/* /root/eval/$repo/${testdirs[index]}
#	mvn test-compile
#	mvn compile
	
	for i in {1..1}
	do
		echo "THIS JUST UP: ${repos[index]} EXPERIMENT $i"
		echo "############################"
#		mkdir /root/eval/allExp/adapterOutputs/${repo}/$thisbranch/$i
		
		
		cd /root/CryptoAnalysis/
		#<reponame> <branch-name> <prefixcp> <extracp> <suffixcp> <experimentnumber>  
		./runCogniServerAll.sh $repo $thisbranch ${classespath[index]} ${originaldir[index]} ${suffixdir[index]} $i &
		sleep 40
		cd /root/eval/
		./runHotFixALL.sh $repo $thisbranch "$testcommand" $i
		
		#keep the gradle specific outputs
		if [ "$repo" = "dragonite-java" ]; then
			mkdir /root/eval/allExp/${repo}/$thisbranch/$i
			find /root/eval/$repo/dragonite-sdk/build/test-results/test/ -name "*.xml" | xargs -I '{}' mv {} /root/eval/${repo}HotFixResults/

			#/root/eval/allExp/${repo}/$thisbranch/$i/
		fi

		find /root/CryptoAnalysis/adapterOutput -name "*.class" | xargs -I '{}' mv {} /root/eval/${repo}HotFixResults/adapterOutputs/$thisbranch/
		
	done	

	
echo "############################"

done
