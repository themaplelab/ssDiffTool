##############
#usage: ./runHotFixALL.sh <reponame> <branch-name> <test command> <experiment number>
#############

repo=$1
branch=$2
testCommand=$3
i=$4

echo "--------------------"
echo "STARTING UP TESTS"
echo "This is repo $1"
echo "This is misuse num $2"
echo "This is testcommand $3"
echo "This is experiment number $4"
echo "--------------------"


cd /root/eval/"$repo"
pwd

rm /root/eval/${repo}HotFixResults/TEST$branch.txt /root/eval/${repo}HotFixResults/REPORT$branch.txt

touch /root/eval/${repo}HotFixResults/TEST$branch.txt
touch /root/eval/${repo}HotFixResults/REPORT$branch.txt

#touch /root/eval/allExp/${repo}/$branch/TEST$i.txt                                                             
#touch /root/eval/allExp/${repo}/$branch/REPORT$i.txt                                                           
#touch /root/eval/allExp/${repo}/$branch/ALL$i.txt

eval "${testCommand}" &>  /root/eval/${repo}HotFixResults/TEST$branch.txt 
    echo "Running with: ${testCommand}" > /root/eval/${repo}HotFixResults/REPORT$branch.txt
    echo "Results:" >> /root/eval/${repo}HotFixResults/REPORT$branch.txt
    echo "---------------------------------------" >> /root/eval/${repo}HotFixResults/REPORT$branch.txt
    grep "Tests run" /root/eval/${repo}HotFixResults/TEST$branch.txt  >> /root/eval/${repo}HotFixResults/REPORT$branch.txt

	if grep -q "REDEFINITION PASSED"  /root/eval/${repo}HotFixResults/TEST$branch.txt  ; then

		echo "REDEFINITION PASSED" >> /root/eval/${repo}HotFixResults/REPORT$branch.txt

	else
		echo "REDEFINITION FAILED" >> /root/eval/${repo}HotFixResults/REPORT$branch.txt
		
	fi

	echo "---------------------------------------" >> /root/eval/${repo}HotFixResults/REPORT$branch.txt
	awk '/======================= CogniCrypt Summary ==========================$/,/=====================================================================$/' /root/eval/${repo}HotFixResults/ALL$branch.txt 
	
	cat /root/eval/${repo}HotFixResults/REPORT$branch.txt
