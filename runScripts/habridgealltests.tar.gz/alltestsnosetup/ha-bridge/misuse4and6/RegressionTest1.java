package randoopTest;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = true;

    @Test
    public void test501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test501");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
    }

    @Test
    public void test502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test502");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str22 = bridgeSecurity4.decrypt("kL+KdGOexBw=");
        bridgeSecurity4.removeTestUsers();
        java.lang.String str25 = bridgeSecurity4.findWhitelistUserByDeviceType("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==");
        bridgeSecurity4.setUseLinkButton(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test503");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap11 = null;
        bridgeSecurity4.setWhitelist(strMap11);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDb8tLTV7R5XcnwcHs7x35TQKdyO/NwznOKdT+dr2AjqpvNqODUW83dwFkRl3nMQZA2JbkF5psEai4Qe8xJ/5zu+TK4wf4LtwDvoCbVYM5RMcB5g6s/A4s7kphlQ8YKhURADCEH8MY1vMRaV9fA368QpeE1l+8aNRsoV9lKHvdfp+OqEw9HIIgjoMc0pIYHUyQWHeRbUUZyParj831VWfwUs=", "dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==", false);
        spark.Request request17 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
    }

    @Test
    public void test504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test504");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = bridgeSecurity4.getWhitelist();
        java.lang.Class<?> wildcardClass14 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test505");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(false);
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test506");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request17 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
    }

    @Test
    public void test507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test507");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity8.setPassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity8.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test508");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        boolean boolean17 = bridgeSecurity4.isSecureHueApi();
        spark.Request request18 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test509");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("");
        java.lang.String str10 = bridgeSecurity4.encrypt("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv" + "'", str10.equals("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv"));
    }

    @Test
    public void test510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test510");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        spark.Request request14 = null;
        com.bwssystems.HABridge.User user15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request14, user15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test511");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("78c3dd49e2154049b82d066622b77921");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test512");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=");
        bridgeSecurity4.setSecureHueApi(false);
        java.lang.String str22 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "3EYePaPfLTY=" + "'", str22.equals("3EYePaPfLTY="));
    }

    @Test
    public void test513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test513");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "6e9e7ee432894f038d93910b9500043a");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "271ccd7813564ac79d3802d4b46e3711");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test514");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        java.lang.String str17 = bridgeSecurity4.getExecGarden();
        java.lang.String str18 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.addUser(user19);
        bridgeSecurity4.setSecurityData("1a15a27f3f6b4f57a8c4d0b12d5e469a");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "vky18BIQu+s=" + "'", str18.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
    }

    @Test
    public void test515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test515");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(true);
        spark.Request request7 = null;
        com.bwssystems.HABridge.User user8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request7, user8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test516");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        bridgeSecurity4.setSecurityData("null");
        boolean boolean15 = bridgeSecurity4.isUseLinkButton();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test517");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test518");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "c3da07e1f7cf429e8da0853ae01c69a4");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test519");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity8.validatePassword(user9);
        java.lang.Class<?> wildcardClass11 = loginResult10.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test520");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.addUser(user19);
        spark.Request request21 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
    }

    @Test
    public void test521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test521");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        java.lang.String str10 = bridgeSecurity4.getExecGarden();
        char[] charArray13 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity15 = new com.bwssystems.HABridge.BridgeSecurity(charArray13, "hi!");
        bridgeSecurity15.setSettingsChanged(false);
        java.lang.String str19 = bridgeSecurity15.encrypt("");
        com.bwssystems.HABridge.User user20 = null;
        com.bwssystems.HABridge.LoginResult loginResult21 = bridgeSecurity15.validatePassword(user20);
        com.bwssystems.HABridge.User user22 = null;
        java.lang.String str23 = bridgeSecurity15.addUser(user22);
        com.bwssystems.HABridge.User user24 = null;
        java.lang.String str25 = bridgeSecurity15.setPassword(user24);
        com.bwssystems.HABridge.User user26 = null;
        java.lang.String str27 = bridgeSecurity15.addUser(user26);
        bridgeSecurity15.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.SecurityInfo securityInfo30 = bridgeSecurity15.getSecurityInfo();
        java.lang.String str32 = bridgeSecurity15.createWhitelistUser("29bcbebd2c5b459da1d142deafdd72a0");
        com.bwssystems.HABridge.SecurityInfo securityInfo33 = bridgeSecurity15.getSecurityInfo();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap34 = bridgeSecurity15.getWhitelist();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3EYePaPfLTY=" + "'", str19.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "invalid user object given" + "'", str23.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "invalid user object given" + "'", str25.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "invalid user object given" + "'", str27.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo30);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0a869f5ef4a14c089a7faf41545fcce5" + "'", str32.equals("0a869f5ef4a14c089a7faf41545fcce5"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap34);
    }

    @Test
    public void test522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test522");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        char[] charArray20 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity22 = new com.bwssystems.HABridge.BridgeSecurity(charArray20, "hi!");
        bridgeSecurity22.setSettingsChanged(false);
        java.lang.String str26 = bridgeSecurity22.encrypt("");
        com.bwssystems.HABridge.User user27 = null;
        com.bwssystems.HABridge.LoginResult loginResult28 = bridgeSecurity22.validatePassword(user27);
        bridgeSecurity22.setSecurityData("null");
        com.bwssystems.HABridge.User user31 = null;
        com.bwssystems.HABridge.LoginResult loginResult32 = bridgeSecurity22.validatePassword(user31);
        java.lang.String str34 = bridgeSecurity22.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity22.setUseLinkButton(true);
        java.lang.String str38 = bridgeSecurity22.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean39 = bridgeSecurity22.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap40 = bridgeSecurity22.getWhitelist();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "3EYePaPfLTY=" + "'", str26.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult32);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9a2e9c28b63a4a449e63ba061ef61faf" + "'", str34.equals("9a2e9c28b63a4a449e63ba061ef61faf"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str38.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap40);
    }

    @Test
    public void test523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test523");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap18 = bridgeSecurity4.getWhitelist();
        java.lang.String str20 = bridgeSecurity4.createWhitelistUser("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        java.lang.String str22 = bridgeSecurity4.encrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap23 = null;
        bridgeSecurity4.convertWhitelist(strMap23);
        bridgeSecurity4.removeTestUsers();
        bridgeSecurity4.setSecurityData("d50fb50ada7943d5bf30c23795ece848");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str17.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap18);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str20 + "' != '" + "b03fec1f1b9b445284976322b0b34e88" + "'", str20.equals("b03fec1f1b9b445284976322b0b34e88"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE=" + "'", str22.equals("TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE="));
    }

    @Test
    public void test524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test524");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo14 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test525");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        com.bwssystems.HABridge.SecurityInfo securityInfo17 = bridgeSecurity4.getSecurityInfo();
        com.bwssystems.HABridge.User user18 = null;
        com.bwssystems.HABridge.LoginResult loginResult19 = bridgeSecurity4.validatePassword(user18);
        bridgeSecurity4.setSecurityData("1a15a27f3f6b4f57a8c4d0b12d5e469a");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult19);
    }

    @Test
    public void test526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test526");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        java.lang.String str12 = bridgeSecurity4.decrypt("3EYePaPfLTY=");
        bridgeSecurity4.setUseLinkButton(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test527");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str22 = bridgeSecurity4.createWhitelistUser("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao");
        spark.Request request23 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str22 + "' != '" + "6d73aa86706c4d78ad11d985dddbfbeb" + "'", str22.equals("6d73aa86706c4d78ad11d985dddbfbeb"));
    }

    @Test
    public void test528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test528");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test529");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray20 = bridgeSecurity4.validateWhitelistUser("78c3dd49e2154049b82d066622b77921", "8a01ee9c2e034fd9b92fff9729fdc26c", true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray20);
    }

    @Test
    public void test530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test530");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.setUseLinkButton(true);
        java.lang.String str20 = bridgeSecurity4.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean21 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecureHueApi(false);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray27 = bridgeSecurity4.validateWhitelistUser("7f2db4f220d849f8b1e4019acd9f2e4a", "ff532457ca3d495ca1ed5f138db53d0c", false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "06a1255552d34362947a4c70578dd8f2" + "'", str16.equals("06a1255552d34362947a4c70578dd8f2"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str20.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray27);
    }

    @Test
    public void test531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test531");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.lang.String str8 = bridgeSecurity4.encrypt("null");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("");
        java.lang.String str13 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "vky18BIQu+s=" + "'", str8.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test532");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getExecGarden();
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str19 = bridgeSecurity4.decrypt("d71f194d3b4e4a269dfa508e14c3beef");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "vky18BIQu+s=" + "'", str17.equals("vky18BIQu+s="));
    }

    @Test
    public void test533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test533");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        com.bwssystems.HABridge.User user17 = null;
        com.bwssystems.HABridge.LoginResult loginResult18 = bridgeSecurity4.validatePassword(user17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult18);
    }

    @Test
    public void test534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test534");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str18 = bridgeSecurity4.encrypt("3353c0ff82c64a049b8f236d73302bf0");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RcpVKLenswLoi1IYt9DNJQ/bsN1yZT29RV7SeeNEO0fdWCJbjgUdPQ==" + "'", str18.equals("RcpVKLenswLoi1IYt9DNJQ/bsN1yZT29RV7SeeNEO0fdWCJbjgUdPQ=="));
    }

    @Test
    public void test535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test535");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test536");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "415008f611d24b0baac0147ef09bfd50");
        char[] charArray9 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity11 = new com.bwssystems.HABridge.BridgeSecurity(charArray9, "hi!");
        bridgeSecurity11.setSettingsChanged(false);
        java.lang.String str15 = bridgeSecurity11.encrypt("");
        com.bwssystems.HABridge.User user16 = null;
        com.bwssystems.HABridge.LoginResult loginResult17 = bridgeSecurity11.validatePassword(user16);
        bridgeSecurity11.setSecurityData("null");
        com.bwssystems.HABridge.User user20 = null;
        com.bwssystems.HABridge.LoginResult loginResult21 = bridgeSecurity11.validatePassword(user20);
        java.lang.String str23 = bridgeSecurity11.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity11.setUseLinkButton(true);
        java.lang.String str27 = bridgeSecurity11.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean28 = bridgeSecurity11.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap29 = bridgeSecurity11.getWhitelist();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.convertWhitelist(strMap29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3EYePaPfLTY=" + "'", str15.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult21);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str23 + "' != '" + "db2931e8d4f24b208144bafd806f3a2d" + "'", str23.equals("db2931e8d4f24b208144bafd806f3a2d"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str27.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap29);
    }

    @Test
    public void test537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test537");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = bridgeSecurity4.getWhitelist();
        spark.Request request14 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user15 = bridgeSecurity4.getAuthenticatedUser(request14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap13);
    }

    @Test
    public void test538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test538");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.addUser(user16);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap18 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
    }

    @Test
    public void test539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test539");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        com.bwssystems.HABridge.SecurityInfo securityInfo17 = bridgeSecurity4.getSecurityInfo();
        char[] charArray20 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity22 = new com.bwssystems.HABridge.BridgeSecurity(charArray20, "hi!");
        bridgeSecurity22.setSettingsChanged(false);
        java.lang.String str26 = bridgeSecurity22.encrypt("");
        com.bwssystems.HABridge.User user27 = null;
        com.bwssystems.HABridge.LoginResult loginResult28 = bridgeSecurity22.validatePassword(user27);
        bridgeSecurity22.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray34 = bridgeSecurity22.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user35 = null;
        java.lang.String str36 = bridgeSecurity22.setPassword(user35);
        java.lang.String str38 = bridgeSecurity22.encrypt("hi!");
        com.bwssystems.HABridge.User user39 = null;
        java.lang.String str40 = bridgeSecurity22.addUser(user39);
        char[] charArray43 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity45 = new com.bwssystems.HABridge.BridgeSecurity(charArray43, "hi!");
        java.lang.String str46 = bridgeSecurity45.getExecGarden();
        java.lang.String str47 = bridgeSecurity45.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user48 = null;
        java.lang.String str49 = bridgeSecurity45.delUser(user48);
        java.lang.String str50 = bridgeSecurity45.getSecurityDescriptorData();
        java.lang.String str52 = bridgeSecurity45.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user53 = null;
        java.lang.String str54 = bridgeSecurity45.setPassword(user53);
        boolean boolean55 = bridgeSecurity45.isSettingsChanged();
        bridgeSecurity45.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str58 = bridgeSecurity45.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap59 = bridgeSecurity45.getWhitelist();
        char[] charArray62 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity64 = new com.bwssystems.HABridge.BridgeSecurity(charArray62, "hi!");
        bridgeSecurity64.setSettingsChanged(false);
        java.lang.String str68 = bridgeSecurity64.encrypt("");
        com.bwssystems.HABridge.User user69 = null;
        com.bwssystems.HABridge.LoginResult loginResult70 = bridgeSecurity64.validatePassword(user69);
        bridgeSecurity64.setSecurityData("null");
        com.bwssystems.HABridge.User user73 = null;
        com.bwssystems.HABridge.LoginResult loginResult74 = bridgeSecurity64.validatePassword(user73);
        java.lang.String str76 = bridgeSecurity64.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity64.setUseLinkButton(true);
        java.lang.String str80 = bridgeSecurity64.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean81 = bridgeSecurity64.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap82 = bridgeSecurity64.getWhitelist();
        bridgeSecurity45.convertWhitelist(strMap82);
        bridgeSecurity22.convertWhitelist(strMap82);
        bridgeSecurity4.convertWhitelist(strMap82);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "3EYePaPfLTY=" + "'", str26.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "invalid user object given" + "'", str36.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "kL+KdGOexBw=" + "'", str38.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "invalid user object given" + "'", str40.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "vky18BIQu+s=" + "'", str47.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "invalid user object given" + "'", str49.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "vky18BIQu+s=" + "'", str50.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "3EYePaPfLTY=" + "'", str52.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "invalid user object given" + "'", str54.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str58.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap59);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "3EYePaPfLTY=" + "'", str68.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult70);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult74);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str76 + "' != '" + "85324a5cc5ad4e37bcb1c84831001f3f" + "'", str76.equals("85324a5cc5ad4e37bcb1c84831001f3f"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str80.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap82);
    }

    @Test
    public void test540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test540");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        boolean boolean19 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.removeTestUsers();
        com.bwssystems.HABridge.User user21 = null;
        java.lang.String str22 = bridgeSecurity4.setPassword(user21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "invalid user object given" + "'", str22.equals("invalid user object given"));
    }

    @Test
    public void test541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test541");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setSettingsChanged(false);
        bridgeSecurity4.setSecurityData("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test542");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray20 = bridgeSecurity4.validateWhitelistUser("b03fec1f1b9b445284976322b0b34e88", "67b8963abbc84602a40594a7681d8f40", false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray20);
    }

    @Test
    public void test543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test543");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = null;
        bridgeSecurity4.setWhitelist(strMap17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.addUser(user19);
        java.lang.String str21 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setUseLinkButton(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str21.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
    }

    @Test
    public void test544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test544");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "3EYePaPfLTY=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str12 = bridgeSecurity10.encrypt("kL+KdGOexBw=");
        java.lang.String str14 = bridgeSecurity10.encrypt("invalid user object given");
        java.lang.String str16 = bridgeSecurity10.encrypt("");
        java.lang.Class<?> wildcardClass17 = bridgeSecurity10.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str12.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=" + "'", str14.equals("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3EYePaPfLTY=" + "'", str16.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test545");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.Class<?> wildcardClass7 = bridgeSecurity6.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test546");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = bridgeSecurity4.getWhitelist();
        bridgeSecurity4.setUseLinkButton(false);
        java.lang.String str21 = bridgeSecurity4.decrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test547");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        boolean boolean15 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean20 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test548");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("837526a07b484cde9389790a569ea74e");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test549");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        java.lang.String str12 = bridgeSecurity4.decrypt("3EYePaPfLTY=");
        char[] charArray15 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity17 = new com.bwssystems.HABridge.BridgeSecurity(charArray15, "hi!");
        bridgeSecurity17.setSettingsChanged(false);
        java.lang.String str21 = bridgeSecurity17.encrypt("");
        com.bwssystems.HABridge.User user22 = null;
        com.bwssystems.HABridge.LoginResult loginResult23 = bridgeSecurity17.validatePassword(user22);
        bridgeSecurity17.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray29 = bridgeSecurity17.validateWhitelistUser("vky18BIQu+s=", "", false);
        java.lang.String str31 = bridgeSecurity17.findWhitelistUserByDeviceType("OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==");
        char[] charArray34 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity36 = new com.bwssystems.HABridge.BridgeSecurity(charArray34, "hi!");
        java.lang.String str37 = bridgeSecurity36.getExecGarden();
        bridgeSecurity36.setSecurityData("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user40 = null;
        java.lang.String str41 = bridgeSecurity36.setPassword(user40);
        bridgeSecurity36.setSecurityData("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==");
        char[] charArray46 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity48 = new com.bwssystems.HABridge.BridgeSecurity(charArray46, "hi!");
        bridgeSecurity48.setSettingsChanged(false);
        java.lang.String str52 = bridgeSecurity48.encrypt("");
        com.bwssystems.HABridge.User user53 = null;
        com.bwssystems.HABridge.LoginResult loginResult54 = bridgeSecurity48.validatePassword(user53);
        bridgeSecurity48.setSecurityData("null");
        com.bwssystems.HABridge.User user57 = null;
        com.bwssystems.HABridge.LoginResult loginResult58 = bridgeSecurity48.validatePassword(user57);
        java.lang.String str60 = bridgeSecurity48.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity48.setUseLinkButton(true);
        java.lang.String str64 = bridgeSecurity48.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean65 = bridgeSecurity48.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap66 = bridgeSecurity48.getWhitelist();
        bridgeSecurity36.setWhitelist(strMap66);
        bridgeSecurity17.convertWhitelist(strMap66);
        bridgeSecurity4.setWhitelist(strMap66);
        com.bwssystems.HABridge.User user70 = null;
        java.lang.String str71 = bridgeSecurity4.setPassword(user70);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "3EYePaPfLTY=" + "'", str21.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "invalid user object given" + "'", str41.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray46);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "3EYePaPfLTY=" + "'", str52.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult54);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult58);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str60 + "' != '" + "cd55c835f4074aca86d975429b0a18e4" + "'", str60.equals("cd55c835f4074aca86d975429b0a18e4"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str64.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap66);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "invalid user object given" + "'", str71.equals("invalid user object given"));
    }

    @Test
    public void test550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test550");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
    }

    @Test
    public void test551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test551");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getExecGarden();
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("c9e5025ced324e8e98912d564245c4c1");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "vky18BIQu+s=" + "'", str17.equals("vky18BIQu+s="));
    }

    @Test
    public void test552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test552");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        bridgeSecurity4.convertWhitelist(strMap15);
        boolean boolean17 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.Class<?> wildcardClass20 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test553");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test554");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "29bcbebd2c5b459da1d142deafdd72a0");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity14 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "29bcbebd2c5b459da1d142deafdd72a0");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test555");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3EYePaPfLTY=" + "'", str7.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test556");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        boolean boolean17 = bridgeSecurity4.isSecureHueApi();
        bridgeSecurity4.removeTestUsers();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test557");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap10 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test558");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        bridgeSecurity4.setSecurityData("kL+KdGOexBw=");
        java.lang.String str19 = bridgeSecurity4.encrypt("WaMm26d5svFxJ1MHQvnBeOzin5v5Q9oCWjWjjFb1w1dFj1kMAfluAorf0nFmXyCOPlqgEybTvZWM9wldr7sh6GuAjxH96tlrbECcPbr6JRVomRCCJn9FxhTJG+rbwFX117Qp2IrSeG5S8lW/ss/zY2wdVjljyZD/qKdZgbGLhI7j+cHjuwSXX7SkDQ1cSzk3AkTCvQi5mxlhN1+8dQkTHX2h9XfdgrlsbHgoWPo7oT+cTDHgVf9ss6U3skW2luOFJyMOHOy9fNY3H6K4Mi7yYOodrJK6BVS/");
        java.lang.Class<?> wildcardClass20 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PG4bEuEJ4vDv28OwTKhkyT23M0OcYQpncPtV+9Xaqjbm5nyeswR5cDgfOePEtTOAtQ6sqCe9RfX4nV8WcfObMTVYtHVCFIk8J1eJ/Ui0xs/FG2tQsv9ScXl2fQ5Rkm35J8KRIii9tiWop4dReakCRsmJCZxDBO2ftjDXYelWYsALovmUTg/ZN1DxpMoYLy8fDvUB5jIreiYXU7+dt+uqmBJseUFAOl++wBDFuBMivvLeKiPrZDFFmyB9C0TH1++ztuDZXS3LCWAlUxv3y+ihWo55+gDJfk+D6RmNa+KeRdHrZX0P4QAFr2X6L7OjemL4ubKpXCf7TUVdj92lkX8eTiei95MCZVg3DKe7qicWtJgpnXxsC4dzuGLzg0e5lz/aV9z0NGrQJZg=" + "'", str19.equals("PG4bEuEJ4vDv28OwTKhkyT23M0OcYQpncPtV+9Xaqjbm5nyeswR5cDgfOePEtTOAtQ6sqCe9RfX4nV8WcfObMTVYtHVCFIk8J1eJ/Ui0xs/FG2tQsv9ScXl2fQ5Rkm35J8KRIii9tiWop4dReakCRsmJCZxDBO2ftjDXYelWYsALovmUTg/ZN1DxpMoYLy8fDvUB5jIreiYXU7+dt+uqmBJseUFAOl++wBDFuBMivvLeKiPrZDFFmyB9C0TH1++ztuDZXS3LCWAlUxv3y+ihWo55+gDJfk+D6RmNa+KeRdHrZX0P4QAFr2X6L7OjemL4ubKpXCf7TUVdj92lkX8eTiei95MCZVg3DKe7qicWtJgpnXxsC4dzuGLzg0e5lz/aV9z0NGrQJZg="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test559");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        bridgeSecurity4.setSecurityData("OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==");
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.delUser(user16);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap18 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap18);
    }

    @Test
    public void test560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test560");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.setUseLinkButton(true);
        java.lang.String str20 = bridgeSecurity4.encrypt("9f4baaf0ce184925bd2d1687893b7f02");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5dbbcd594eb346ed84c299bb76ec4e0b" + "'", str16.equals("5dbbcd594eb346ed84c299bb76ec4e0b"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rpTAMT1wSYokbaECEIDKbnDbouvA/Wlra1EBrHtPCFtqn/ZaZ2FBQA==" + "'", str20.equals("rpTAMT1wSYokbaECEIDKbnDbouvA/Wlra1EBrHtPCFtqn/ZaZ2FBQA=="));
    }

    @Test
    public void test561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test561");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        java.lang.String str7 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean8 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "vky18BIQu+s=" + "'", str7.equals("vky18BIQu+s="));
    }

    @Test
    public void test562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test562");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        char[] charArray19 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity21 = new com.bwssystems.HABridge.BridgeSecurity(charArray19, "hi!");
        bridgeSecurity21.setSettingsChanged(false);
        java.lang.String str25 = bridgeSecurity21.encrypt("");
        com.bwssystems.HABridge.User user26 = null;
        com.bwssystems.HABridge.LoginResult loginResult27 = bridgeSecurity21.validatePassword(user26);
        bridgeSecurity21.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray33 = bridgeSecurity21.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user34 = null;
        java.lang.String str35 = bridgeSecurity21.setPassword(user34);
        java.lang.String str37 = bridgeSecurity21.encrypt("hi!");
        com.bwssystems.HABridge.User user38 = null;
        java.lang.String str39 = bridgeSecurity21.addUser(user38);
        char[] charArray42 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity44 = new com.bwssystems.HABridge.BridgeSecurity(charArray42, "hi!");
        java.lang.String str45 = bridgeSecurity44.getExecGarden();
        java.lang.String str46 = bridgeSecurity44.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user47 = null;
        java.lang.String str48 = bridgeSecurity44.delUser(user47);
        java.lang.String str49 = bridgeSecurity44.getSecurityDescriptorData();
        java.lang.String str51 = bridgeSecurity44.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user52 = null;
        java.lang.String str53 = bridgeSecurity44.setPassword(user52);
        boolean boolean54 = bridgeSecurity44.isSettingsChanged();
        bridgeSecurity44.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str57 = bridgeSecurity44.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap58 = bridgeSecurity44.getWhitelist();
        char[] charArray61 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity63 = new com.bwssystems.HABridge.BridgeSecurity(charArray61, "hi!");
        bridgeSecurity63.setSettingsChanged(false);
        java.lang.String str67 = bridgeSecurity63.encrypt("");
        com.bwssystems.HABridge.User user68 = null;
        com.bwssystems.HABridge.LoginResult loginResult69 = bridgeSecurity63.validatePassword(user68);
        bridgeSecurity63.setSecurityData("null");
        com.bwssystems.HABridge.User user72 = null;
        com.bwssystems.HABridge.LoginResult loginResult73 = bridgeSecurity63.validatePassword(user72);
        java.lang.String str75 = bridgeSecurity63.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity63.setUseLinkButton(true);
        java.lang.String str79 = bridgeSecurity63.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean80 = bridgeSecurity63.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap81 = bridgeSecurity63.getWhitelist();
        bridgeSecurity44.convertWhitelist(strMap81);
        bridgeSecurity21.convertWhitelist(strMap81);
        bridgeSecurity4.convertWhitelist(strMap81);
        java.lang.String str86 = bridgeSecurity4.encrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3EYePaPfLTY=" + "'", str25.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "invalid user object given" + "'", str35.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "kL+KdGOexBw=" + "'", str37.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "invalid user object given" + "'", str39.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "vky18BIQu+s=" + "'", str46.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "invalid user object given" + "'", str48.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "vky18BIQu+s=" + "'", str49.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "3EYePaPfLTY=" + "'", str51.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "invalid user object given" + "'", str53.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str57.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray61);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3EYePaPfLTY=" + "'", str67.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult69);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult73);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str75 + "' != '" + "ba2b415b3ce14cdf9c092497e0f37278" + "'", str75.equals("ba2b415b3ce14cdf9c092497e0f37278"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str79.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap81);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q=" + "'", str86.equals("qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q="));
    }

    @Test
    public void test563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test563");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        java.lang.String str20 = bridgeSecurity4.encrypt("hi!");
        com.bwssystems.HABridge.User user21 = null;
        java.lang.String str22 = bridgeSecurity4.addUser(user21);
        com.bwssystems.HABridge.User user23 = null;
        com.bwssystems.HABridge.LoginResult loginResult24 = bridgeSecurity4.validatePassword(user23);
        com.bwssystems.HABridge.User user25 = null;
        java.lang.String str26 = bridgeSecurity4.setPassword(user25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "kL+KdGOexBw=" + "'", str20.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "invalid user object given" + "'", str22.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "invalid user object given" + "'", str26.equals("invalid user object given"));
    }

    @Test
    public void test564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test564");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "e6a98d636e49402a9c9814b4cb018bb1");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test565");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity8.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = bridgeSecurity8.createWhitelistUser("9af6cfa7f07d41b9b05825a637cc817f");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test566");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity8.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        com.bwssystems.HABridge.LoginResult loginResult12 = bridgeSecurity8.validatePassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity8.addUser(user13);
        spark.Request request15 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user16 = bridgeSecurity8.getAuthenticatedUser(request15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test567");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str19 = bridgeSecurity4.createWhitelistUser("ea2d98d3d2194598a44367e74ee3651c");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str17.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str19 + "' != '" + "f4be13e2e9fc4278b385b44cd8f893c4" + "'", str19.equals("f4be13e2e9fc4278b385b44cd8f893c4"));
    }

    @Test
    public void test568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test568");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        bridgeSecurity4.convertWhitelist(strMap15);
        boolean boolean17 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str21 = bridgeSecurity4.encrypt("e310e2ad74af4c72824a25b8b8eb7d1e");
        java.lang.String str22 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "fBrvqur8zNvGOeIIzVqIBHO8G8YE73YD4BGFyineSFbu6923o61yUg==" + "'", str21.equals("fBrvqur8zNvGOeIIzVqIBHO8G8YE73YD4BGFyineSFbu6923o61yUg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

    @Test
    public void test569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test569");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.lang.Class<?> wildcardClass20 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test570");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        java.lang.String str10 = bridgeSecurity4.getExecGarden();
        char[] charArray13 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity15 = new com.bwssystems.HABridge.BridgeSecurity(charArray13, "hi!");
        bridgeSecurity15.setSettingsChanged(false);
        java.lang.String str19 = bridgeSecurity15.encrypt("");
        com.bwssystems.HABridge.User user20 = null;
        com.bwssystems.HABridge.LoginResult loginResult21 = bridgeSecurity15.validatePassword(user20);
        com.bwssystems.HABridge.User user22 = null;
        java.lang.String str23 = bridgeSecurity15.addUser(user22);
        com.bwssystems.HABridge.User user24 = null;
        java.lang.String str25 = bridgeSecurity15.setPassword(user24);
        com.bwssystems.HABridge.User user26 = null;
        java.lang.String str27 = bridgeSecurity15.addUser(user26);
        bridgeSecurity15.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.SecurityInfo securityInfo30 = bridgeSecurity15.getSecurityInfo();
        java.lang.String str32 = bridgeSecurity15.createWhitelistUser("29bcbebd2c5b459da1d142deafdd72a0");
        com.bwssystems.HABridge.SecurityInfo securityInfo33 = bridgeSecurity15.getSecurityInfo();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap34 = bridgeSecurity15.getWhitelist();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "kL+KdGOexBw=" + "'", str9.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3EYePaPfLTY=" + "'", str19.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "invalid user object given" + "'", str23.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "invalid user object given" + "'", str25.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "invalid user object given" + "'", str27.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo30);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str32 + "' != '" + "cf977476e8364ec8919370c920ed4cf4" + "'", str32.equals("cf977476e8364ec8919370c920ed4cf4"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap34);
    }

    @Test
    public void test571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test571");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str22 = bridgeSecurity4.createWhitelistUser("");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray26 = bridgeSecurity4.validateWhitelistUser("e310e2ad74af4c72824a25b8b8eb7d1e", "8a01ee9c2e034fd9b92fff9729fdc26c", true);
        bridgeSecurity4.setUseLinkButton(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str22 + "' != '" + "b0b0e0d0f8de460c8005105a3be22a79" + "'", str22.equals("b0b0e0d0f8de460c8005105a3be22a79"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray26);
    }

    @Test
    public void test572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test572");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.createWhitelistUser("\uFFFD\f\u0004\uFFFD\uFFFDE\u01F7\uFFFD\u0007g\\^\uFFFD\uFFFDjC\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
    }

    @Test
    public void test573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test573");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        bridgeSecurity4.setWhitelist(strMap13);
        boolean boolean15 = bridgeSecurity4.isUseLinkButton();
        spark.Request request16 = null;
        com.bwssystems.HABridge.User user17 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request16, user17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test574");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str18 = bridgeSecurity4.decrypt("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=");
        java.lang.String str19 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "vky18BIQu+s=" + "'", str19.equals("vky18BIQu+s="));
    }

    @Test
    public void test575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test575");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        bridgeSecurity4.setWhitelist(strMap13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("null", "YEunCl55a+cBkjozhBjMSw==", true);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = null;
        bridgeSecurity4.setWhitelist(strMap20);
        java.lang.String str22 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray26 = bridgeSecurity4.validateWhitelistUser("BQLlg2avssKuA3tHG48yrQkYepFWwI2iyuZpatSxp9WgrEAmx4i26y7sZfjN90pCG43JNHQl7lGaFqVf7E+Sng==", "ea2d98d3d2194598a44367e74ee3651c", false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray26);
    }

    @Test
    public void test576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test576");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.setUseLinkButton(true);
        java.lang.String str20 = bridgeSecurity4.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        java.lang.String str22 = bridgeSecurity4.encrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.setPassword(user23);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray28 = bridgeSecurity4.validateWhitelistUser("415008f611d24b0baac0147ef09bfd50", "b3caa27087444510b22884a96461cbed", true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1b2694dc3e544376b40b407c8d09cf3b" + "'", str16.equals("1b2694dc3e544376b40b407c8d09cf3b"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str20.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE=" + "'", str22.equals("TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray28);
    }

    @Test
    public void test577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test577");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        bridgeSecurity4.setWhitelist(strMap13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("null", "YEunCl55a+cBkjozhBjMSw==", true);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = null;
        bridgeSecurity4.setWhitelist(strMap20);
        bridgeSecurity4.setSecureHueApi(true);
        java.lang.Class<?> wildcardClass24 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test578");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        boolean boolean17 = bridgeSecurity4.isSecureHueApi();
        bridgeSecurity4.setUseLinkButton(true);
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.addUser(user20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
    }

    @Test
    public void test579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test579");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.addUser(user19);
        com.bwssystems.HABridge.SecurityInfo securityInfo21 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSecureHueApi(false);
        char[] charArray26 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity28 = new com.bwssystems.HABridge.BridgeSecurity(charArray26, "hi!");
        java.lang.String str29 = bridgeSecurity28.getExecGarden();
        java.lang.String str30 = bridgeSecurity28.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user31 = null;
        java.lang.String str32 = bridgeSecurity28.delUser(user31);
        java.lang.String str33 = bridgeSecurity28.getSecurityDescriptorData();
        java.lang.String str35 = bridgeSecurity28.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user36 = null;
        java.lang.String str37 = bridgeSecurity28.setPassword(user36);
        boolean boolean38 = bridgeSecurity28.isSettingsChanged();
        bridgeSecurity28.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str41 = bridgeSecurity28.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap42 = bridgeSecurity28.getWhitelist();
        char[] charArray45 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity47 = new com.bwssystems.HABridge.BridgeSecurity(charArray45, "hi!");
        bridgeSecurity47.setSettingsChanged(false);
        java.lang.String str51 = bridgeSecurity47.encrypt("");
        com.bwssystems.HABridge.User user52 = null;
        com.bwssystems.HABridge.LoginResult loginResult53 = bridgeSecurity47.validatePassword(user52);
        bridgeSecurity47.setSecurityData("null");
        com.bwssystems.HABridge.User user56 = null;
        com.bwssystems.HABridge.LoginResult loginResult57 = bridgeSecurity47.validatePassword(user56);
        java.lang.String str59 = bridgeSecurity47.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity47.setUseLinkButton(true);
        java.lang.String str63 = bridgeSecurity47.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean64 = bridgeSecurity47.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap65 = bridgeSecurity47.getWhitelist();
        bridgeSecurity28.convertWhitelist(strMap65);
        bridgeSecurity4.setWhitelist(strMap65);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "vky18BIQu+s=" + "'", str30.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "invalid user object given" + "'", str32.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "vky18BIQu+s=" + "'", str33.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "3EYePaPfLTY=" + "'", str35.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "invalid user object given" + "'", str37.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str41.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "3EYePaPfLTY=" + "'", str51.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult53);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult57);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str59 + "' != '" + "94c7dd28f3094a869b2e552600e9d1b2" + "'", str59.equals("94c7dd28f3094a869b2e552600e9d1b2"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str63.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap65);
    }

    @Test
    public void test580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test580");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.setSecurityData("vky18BIQu+s=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test581");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        java.lang.String str11 = bridgeSecurity4.decrypt("3EYePaPfLTY=");
        java.lang.String str13 = bridgeSecurity4.decrypt("837526a07b484cde9389790a569ea74e");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\uFFFD\f\u0004\uFFFD\uFFFDE\u01F7\uFFFD\u0007g\\^\uFFFD\uFFFDjC\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD" + "'", str13.equals("\uFFFD\f\u0004\uFFFD\uFFFDE\u01F7\uFFFD\u0007g\\^\uFFFD\uFFFDjC\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD"));
    }

    @Test
    public void test582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test582");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        com.bwssystems.HABridge.User user17 = null;
        com.bwssystems.HABridge.LoginResult loginResult18 = bridgeSecurity4.validatePassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str21 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test583");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean19 = bridgeSecurity4.isSecure();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test584");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.addUser(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        boolean boolean14 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test585");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str9 = bridgeSecurity8.getExecGarden();
        boolean boolean10 = bridgeSecurity8.isSettingsChanged();
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity8.delUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity8.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test586");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.delUser(user14);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test587");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.setUseLinkButton(true);
        java.lang.String str20 = bridgeSecurity4.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean21 = bridgeSecurity4.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap22 = bridgeSecurity4.getWhitelist();
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.addUser(user23);
        java.lang.String str25 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "80c53e70da9b47549bfe65ca403e8530" + "'", str16.equals("80c53e70da9b47549bfe65ca403e8530"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str20.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str25 + "' != '" + "WaMm26d5svFxJ1MHQvnBeOzin5v5Q9oCWjWjjFb1w1dFj1kMAfluAorf0nFmXyCOPlqgEybTvZVG4ykb8nhSzFxnD3a0zqZ0cOBEPQ7codInowz/drVTR6VquRifHKIUvdRP3G1w9hY5M7MJS+jfVvm/BqCkLRopprEbHWEJsUDPQQ660YiWKoDpEaDZdkj3omQC9NKPEZtPvwSLrokgJy7JppHH0N+7YUzx22H7Vlair0rt1b8aKY2njUSomTcnH8amJIvETGyBKLb8lQZ5C0oWD6HCOc4h" + "'", str25.equals("WaMm26d5svFxJ1MHQvnBeOzin5v5Q9oCWjWjjFb1w1dFj1kMAfluAorf0nFmXyCOPlqgEybTvZVG4ykb8nhSzFxnD3a0zqZ0cOBEPQ7codInowz/drVTR6VquRifHKIUvdRP3G1w9hY5M7MJS+jfVvm/BqCkLRopprEbHWEJsUDPQQ660YiWKoDpEaDZdkj3omQC9NKPEZtPvwSLrokgJy7JppHH0N+7YUzx22H7Vlair0rt1b8aKY2njUSomTcnH8amJIvETGyBKLb8lQZ5C0oWD6HCOc4h"));
    }

    @Test
    public void test588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test588");
        char[] charArray0 = null;
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity2 = new com.bwssystems.HABridge.BridgeSecurity(charArray0, "ea2d98d3d2194598a44367e74ee3651c");
    }

    @Test
    public void test589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test589");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test590");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("kL+KdGOexBw=", "OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==", true);
        com.bwssystems.HABridge.SecurityInfo securityInfo19 = bridgeSecurity4.getSecurityInfo();
        java.lang.String str21 = bridgeSecurity4.findWhitelistUserByDeviceType("invalid user object given");
        java.lang.String str22 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str22.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
    }

    @Test
    public void test591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test591");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap19 = null;
        bridgeSecurity4.convertWhitelist(strMap19);
        java.lang.String str22 = bridgeSecurity4.createWhitelistUser("vky18BIQu+s=");
        spark.Request request23 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user24 = bridgeSecurity4.getAuthenticatedUser(request23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ba44dccecd924771a9ffadc34c85379c" + "'", str22.equals("ba44dccecd924771a9ffadc34c85379c"));
    }

    @Test
    public void test592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test592");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        bridgeSecurity4.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test593");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.lang.String str14 = bridgeSecurity4.createWhitelistUser("415008f611d24b0baac0147ef09bfd50");
        bridgeSecurity4.removeTestUsers();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32b61a5023be4ae8a629f6c1e1c549c1" + "'", str14.equals("32b61a5023be4ae8a629f6c1e1c549c1"));
    }

    @Test
    public void test594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test594");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.decrypt("ba2b415b3ce14cdf9c092497e0f37278");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test595");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        com.bwssystems.HABridge.User user18 = null;
        com.bwssystems.HABridge.LoginResult loginResult19 = bridgeSecurity4.validatePassword(user18);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str21 = bridgeSecurity4.decrypt("e310e2ad74af4c72824a25b8b8eb7d1e");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult19);
    }

    @Test
    public void test596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test596");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        char[] charArray19 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity21 = new com.bwssystems.HABridge.BridgeSecurity(charArray19, "hi!");
        bridgeSecurity21.setSettingsChanged(false);
        java.lang.String str25 = bridgeSecurity21.encrypt("");
        com.bwssystems.HABridge.User user26 = null;
        com.bwssystems.HABridge.LoginResult loginResult27 = bridgeSecurity21.validatePassword(user26);
        bridgeSecurity21.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray33 = bridgeSecurity21.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user34 = null;
        java.lang.String str35 = bridgeSecurity21.setPassword(user34);
        java.lang.String str37 = bridgeSecurity21.encrypt("hi!");
        com.bwssystems.HABridge.User user38 = null;
        java.lang.String str39 = bridgeSecurity21.addUser(user38);
        char[] charArray42 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity44 = new com.bwssystems.HABridge.BridgeSecurity(charArray42, "hi!");
        java.lang.String str45 = bridgeSecurity44.getExecGarden();
        java.lang.String str46 = bridgeSecurity44.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user47 = null;
        java.lang.String str48 = bridgeSecurity44.delUser(user47);
        java.lang.String str49 = bridgeSecurity44.getSecurityDescriptorData();
        java.lang.String str51 = bridgeSecurity44.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user52 = null;
        java.lang.String str53 = bridgeSecurity44.setPassword(user52);
        boolean boolean54 = bridgeSecurity44.isSettingsChanged();
        bridgeSecurity44.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str57 = bridgeSecurity44.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap58 = bridgeSecurity44.getWhitelist();
        char[] charArray61 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity63 = new com.bwssystems.HABridge.BridgeSecurity(charArray61, "hi!");
        bridgeSecurity63.setSettingsChanged(false);
        java.lang.String str67 = bridgeSecurity63.encrypt("");
        com.bwssystems.HABridge.User user68 = null;
        com.bwssystems.HABridge.LoginResult loginResult69 = bridgeSecurity63.validatePassword(user68);
        bridgeSecurity63.setSecurityData("null");
        com.bwssystems.HABridge.User user72 = null;
        com.bwssystems.HABridge.LoginResult loginResult73 = bridgeSecurity63.validatePassword(user72);
        java.lang.String str75 = bridgeSecurity63.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity63.setUseLinkButton(true);
        java.lang.String str79 = bridgeSecurity63.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean80 = bridgeSecurity63.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap81 = bridgeSecurity63.getWhitelist();
        bridgeSecurity44.convertWhitelist(strMap81);
        bridgeSecurity21.convertWhitelist(strMap81);
        bridgeSecurity4.convertWhitelist(strMap81);
        java.lang.String str86 = bridgeSecurity4.findWhitelistUserByDeviceType("9af6cfa7f07d41b9b05825a637cc817f");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3EYePaPfLTY=" + "'", str25.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "invalid user object given" + "'", str35.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "kL+KdGOexBw=" + "'", str37.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "invalid user object given" + "'", str39.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "vky18BIQu+s=" + "'", str46.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "invalid user object given" + "'", str48.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "vky18BIQu+s=" + "'", str49.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "3EYePaPfLTY=" + "'", str51.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "invalid user object given" + "'", str53.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str57.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray61);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3EYePaPfLTY=" + "'", str67.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult69);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult73);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str75 + "' != '" + "b576ac33eb5c43459bcd41300898242f" + "'", str75.equals("b576ac33eb5c43459bcd41300898242f"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str79.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap81);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str86);
    }

    @Test
    public void test597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test597");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        java.lang.String str7 = bridgeSecurity6.getSecurityDescriptorData();
        bridgeSecurity6.setSecurityData("t0Xx+HXTLr+rqj3DRV4xUYo75zRCw7O5NBPMk+P0a1SbRmxc94jCqA==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "vky18BIQu+s=" + "'", str7.equals("vky18BIQu+s="));
    }

    @Test
    public void test598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test598");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap21 = null;
        bridgeSecurity4.convertWhitelist(strMap21);
        java.lang.String str23 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.SecurityInfo securityInfo24 = bridgeSecurity4.getSecurityInfo();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo24);
    }

    @Test
    public void test599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test599");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.lang.String str21 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        bridgeSecurity4.removeTestUsers();
        boolean boolean23 = bridgeSecurity4.isSecure();
        boolean boolean24 = bridgeSecurity4.isSecure();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test600");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "06ad7a26a22b4780aa1cf6e8f6f2db6e");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test601");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str13 = bridgeSecurity4.encrypt("kL+KdGOexBw=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean14 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str13.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
    }

    @Test
    public void test602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test602");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        boolean boolean10 = bridgeSecurity4.isSettingsChanged();
        spark.Request request11 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user12 = bridgeSecurity4.getAuthenticatedUser(request11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test603");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        java.lang.String str11 = bridgeSecurity4.decrypt("3EYePaPfLTY=");
        java.lang.String str13 = bridgeSecurity4.decrypt("837526a07b484cde9389790a569ea74e");
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.addUser(user14);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray19 = bridgeSecurity4.validateWhitelistUser("9af6cfa7f07d41b9b05825a637cc817f", "b3caa27087444510b22884a96461cbed", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\uFFFD\f\u0004\uFFFD\uFFFDE\u01F7\uFFFD\u0007g\\^\uFFFD\uFFFDjC\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD" + "'", str13.equals("\uFFFD\f\u0004\uFFFD\uFFFDE\u01F7\uFFFD\u0007g\\^\uFFFD\uFFFDjC\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test604");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.lang.String str11 = bridgeSecurity4.findWhitelistUserByDeviceType("YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str12.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
    }

    @Test
    public void test605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test605");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.Class<?> wildcardClass13 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test606");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        bridgeSecurity6.setSecurityData("vky18BIQu+s=");
        java.lang.String str9 = bridgeSecurity6.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity6.delUser(user10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test607");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity8.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        com.bwssystems.HABridge.LoginResult loginResult12 = bridgeSecurity8.validatePassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity8.addUser(user13);
        bridgeSecurity8.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test608");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test609");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        java.lang.String str9 = bridgeSecurity8.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
    }

    @Test
    public void test610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test610");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = bridgeSecurity4.decrypt("f4be13e2e9fc4278b385b44cd8f893c4");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3EYePaPfLTY=" + "'", str7.equals("3EYePaPfLTY="));
    }

    @Test
    public void test611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test611");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.lang.String str21 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        bridgeSecurity4.setSecurityData("06ad7a26a22b4780aa1cf6e8f6f2db6e");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test612");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("kL+KdGOexBw=", "OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==", true);
        boolean boolean19 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test613");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.lang.String str21 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        spark.Request request22 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user23 = bridgeSecurity4.getAuthenticatedUser(request22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test614");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        boolean boolean15 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test615");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str16 = bridgeSecurity4.decrypt("vky18BIQu+s=");
        com.bwssystems.HABridge.User user17 = null;
        com.bwssystems.HABridge.LoginResult loginResult18 = bridgeSecurity4.validatePassword(user17);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult18);
    }

    @Test
    public void test616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test616");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        java.lang.String str21 = bridgeSecurity4.encrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str23 = bridgeSecurity4.findWhitelistUserByDeviceType("8881cc864e4845c882c1ddc6b2adac66");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q=" + "'", str21.equals("qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q="));
    }

    @Test
    public void test617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test617");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        com.bwssystems.HABridge.SecurityInfo securityInfo17 = bridgeSecurity4.getSecurityInfo();
        com.bwssystems.HABridge.User user18 = null;
        com.bwssystems.HABridge.LoginResult loginResult19 = bridgeSecurity4.validatePassword(user18);
        com.bwssystems.HABridge.User user20 = null;
        com.bwssystems.HABridge.LoginResult loginResult21 = bridgeSecurity4.validatePassword(user20);
        java.lang.Class<?> wildcardClass22 = loginResult21.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test618");
        char[] charArray6 = new char[] { ' ', '4', ' ', '#', '#', '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray6, "1a15a27f3f6b4f57a8c4d0b12d5e469a");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity8.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        com.bwssystems.HABridge.LoginResult loginResult12 = bridgeSecurity8.validatePassword(user11);
        bridgeSecurity8.setSecurityData("vky18BIQu+s=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult12);
    }

    @Test
    public void test619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test619");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo17 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test620");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
    }

    @Test
    public void test621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test621");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str21 = bridgeSecurity4.createWhitelistUser("b27db0fca20a40e6a9959b3b34b06567");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1896eb2b19904ccfabcc6ec6552e09e3" + "'", str21.equals("1896eb2b19904ccfabcc6ec6552e09e3"));
    }

    @Test
    public void test622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test622");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.delUser(user9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test623");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.lang.Class<?> wildcardClass11 = bridgeSecurity10.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test624");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.setPassword(user19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
    }

    @Test
    public void test625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test625");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        com.bwssystems.HABridge.LoginResult loginResult12 = bridgeSecurity4.validatePassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test626");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = bridgeSecurity4.getWhitelist();
        bridgeSecurity4.setUseLinkButton(false);
        boolean boolean20 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray24 = bridgeSecurity4.validateWhitelistUser("78c3dd49e2154049b82d066622b77921", "6e9e7ee432894f038d93910b9500043a", true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray24);
    }

    @Test
    public void test627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test627");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        boolean boolean11 = bridgeSecurity4.isSecureHueApi();
        bridgeSecurity4.removeTestUsers();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test628");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        bridgeSecurity4.setWhitelist(strMap13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("null", "YEunCl55a+cBkjozhBjMSw==", true);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = null;
        bridgeSecurity4.setWhitelist(strMap20);
        bridgeSecurity4.setSecureHueApi(true);
        bridgeSecurity4.removeTestUsers();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str26 = bridgeSecurity4.decrypt("9b2be6d12e1846cba1b5f6a16b3251ef");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test629");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "3EYePaPfLTY=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str12 = bridgeSecurity10.encrypt("kL+KdGOexBw=");
        java.lang.String str14 = bridgeSecurity10.encrypt("invalid user object given");
        bridgeSecurity10.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str12.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=" + "'", str14.equals("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg="));
    }

    @Test
    public void test630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test630");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE=");
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity10.setPassword(user11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test631");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        java.lang.Class<?> wildcardClass16 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test632");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "vky18BIQu+s=" + "'", str7.equals("vky18BIQu+s="));
    }

    @Test
    public void test633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test633");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = bridgeSecurity4.getWhitelist();
        bridgeSecurity4.setUseLinkButton(false);
        java.lang.String str20 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("85324a5cc5ad4e37bcb1c84831001f3f");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test634");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        java.lang.String str11 = bridgeSecurity4.encrypt("vky18BIQu+s=");
        java.lang.String str13 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.lang.String str14 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "YEunCl55a+cBkjozhBjMSw==" + "'", str11.equals("YEunCl55a+cBkjozhBjMSw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3EYePaPfLTY=" + "'", str13.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "vky18BIQu+s=" + "'", str14.equals("vky18BIQu+s="));
    }

    @Test
    public void test635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test635");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        java.lang.String str12 = bridgeSecurity4.encrypt("6e9e7ee432894f038d93910b9500043a");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("null", "e6a98d636e49402a9c9814b4cb018bb1", true);
        spark.Request request17 = null;
        com.bwssystems.HABridge.User user18 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request17, user18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==" + "'", str12.equals("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
    }

    @Test
    public void test636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test636");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "vky18BIQu+s=" + "'", str10.equals("vky18BIQu+s="));
    }

    @Test
    public void test637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test637");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap11 = null;
        bridgeSecurity4.setWhitelist(strMap11);
        bridgeSecurity4.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test638");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.lang.String str11 = bridgeSecurity4.findWhitelistUserByDeviceType("YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.User user12 = null;
        com.bwssystems.HABridge.LoginResult loginResult13 = bridgeSecurity4.validatePassword(user12);
        boolean boolean14 = bridgeSecurity4.isUseLinkButton();
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("ea2d98d3d2194598a44367e74ee3651c");
        java.lang.String str18 = bridgeSecurity4.encrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "23abd1081bb8465bbcf5058bf644bcaf" + "'", str16.equals("23abd1081bb8465bbcf5058bf644bcaf"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "3EYePaPfLTY=" + "'", str18.equals("3EYePaPfLTY="));
    }

    @Test
    public void test639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test639");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        java.lang.String str17 = bridgeSecurity4.decrypt("efmI7rRPXdi3mmYSHGk6Gw==");
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.delUser(user18);
        bridgeSecurity4.setSecurityData("67b8963abbc84602a40594a7681d8f40");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "kL+KdGOexBw=" + "'", str17.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test640");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean18 = bridgeSecurity4.isSettingsChanged();
        spark.Request request19 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user20 = bridgeSecurity4.getAuthenticatedUser(request19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str17.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test641");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        java.lang.String str11 = bridgeSecurity4.decrypt("WaMm26d5svFxJ1MHQvnBeOzin5v5Q9oCWjWjjFb1w1dFj1kMAfluAorf0nFmXyCOPlqgEybTvZVG4ykb8nhSzFxnD3a0zqZ0cOBEPQ7codInowz/drVTR6VquRifHKIUvdRP3G1w9hY5M7MJS+jfVvm/BqCkLRopprEbHWEJsUDPQQ660YiWKoDpEaDZdkj3omQC9NKPEZtPvwSLrokgJy7JppHH0N+7YUzx22H7Vlair0rt1b8aKY2njUSomTcnH8amJIvETGyBKLb8lQZ5C0oWD6HCOc4h");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3EYePaPfLTY=" + "'", str7.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{\"useLinkButton\":true,\"secureHueApi\":false,\"whitelist\":{\"80c53e70da9b47549bfe65ca403e8530\":{\"lastUseDate\":\"2020-03-17T05:21:19\",\"createDate\":\"2020-03-17T05:21:19\",\"name\":\"YEunCl55a+cBkjozhBjMSw\\u003d\\u003d\"}}}" + "'", str11.equals("{\"useLinkButton\":true,\"secureHueApi\":false,\"whitelist\":{\"80c53e70da9b47549bfe65ca403e8530\":{\"lastUseDate\":\"2020-03-17T05:21:19\",\"createDate\":\"2020-03-17T05:21:19\",\"name\":\"YEunCl55a+cBkjozhBjMSw\\u003d\\u003d\"}}}"));
    }

    @Test
    public void test642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test642");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str16 = bridgeSecurity4.decrypt("vky18BIQu+s=");
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean20 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test643");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.setPassword(user8);
        boolean boolean10 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray14 = bridgeSecurity4.validateWhitelistUser("23abd1081bb8465bbcf5058bf644bcaf", "c3da07e1f7cf429e8da0853ae01c69a4", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test644");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        bridgeSecurity4.setSecurityData("vky18BIQu+s=");
        java.lang.String str13 = bridgeSecurity4.decrypt("t0Xx+HXTLr+rqj3DRV4xUYo75zRCw7O5NBPMk+P0a1SbRmxc94jCqA==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "29bcbebd2c5b459da1d142deafdd72a0" + "'", str13.equals("29bcbebd2c5b459da1d142deafdd72a0"));
    }

    @Test
    public void test645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test645");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.delUser(user10);
        bridgeSecurity4.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test646");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str22 = bridgeSecurity4.createWhitelistUser("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str24 = bridgeSecurity4.decrypt("invalid user object given");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 20");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str22 + "' != '" + "cd43ab7b50974a7aa6590ab92a0110de" + "'", str22.equals("cd43ab7b50974a7aa6590ab92a0110de"));
    }

    @Test
    public void test647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test647");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=");
        java.lang.String str16 = bridgeSecurity4.encrypt("kL+KdGOexBw=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str14.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str16.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
    }

    @Test
    public void test648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test648");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "415008f611d24b0baac0147ef09bfd50");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "415008f611d24b0baac0147ef09bfd50" + "'", str7.equals("415008f611d24b0baac0147ef09bfd50"));
    }

    @Test
    public void test649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test649");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        boolean boolean7 = bridgeSecurity6.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test650");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        bridgeSecurity4.setWhitelist(strMap13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("null", "YEunCl55a+cBkjozhBjMSw==", true);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = null;
        bridgeSecurity4.setWhitelist(strMap20);
        bridgeSecurity4.setSecureHueApi(true);
        java.lang.String str25 = bridgeSecurity4.createWhitelistUser("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str25 + "' != '" + "32b0992e8c4347aabacb8b48b6315137" + "'", str25.equals("32b0992e8c4347aabacb8b48b6315137"));
    }

    @Test
    public void test651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test651");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test652");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        java.lang.String str11 = bridgeSecurity4.encrypt("vky18BIQu+s=");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.addUser(user12);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "YEunCl55a+cBkjozhBjMSw==" + "'", str11.equals("YEunCl55a+cBkjozhBjMSw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test653");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.lang.String str11 = bridgeSecurity4.findWhitelistUserByDeviceType("YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str13 = bridgeSecurity4.decrypt("rpTAMT1wSYokbaECEIDKbnDbouvA/Wlra1EBrHtPCFtqn/ZaZ2FBQA==");
        boolean boolean14 = bridgeSecurity4.isSecure();
        boolean boolean15 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9f4baaf0ce184925bd2d1687893b7f02" + "'", str13.equals("9f4baaf0ce184925bd2d1687893b7f02"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test654");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("kL+KdGOexBw=", "OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==", true);
        com.bwssystems.HABridge.SecurityInfo securityInfo19 = bridgeSecurity4.getSecurityInfo();
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.addUser(user20);
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user24 = null;
        java.lang.String str25 = bridgeSecurity4.setPassword(user24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "invalid user object given" + "'", str25.equals("invalid user object given"));
    }

    @Test
    public void test655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test655");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean18 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "vky18BIQu+s=" + "'", str17.equals("vky18BIQu+s="));
    }

    @Test
    public void test656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test656");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "vky18BIQu+s=" + "'", str12.equals("vky18BIQu+s="));
    }

    @Test
    public void test657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test657");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray20 = bridgeSecurity4.validateWhitelistUser("", "OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==", false);
        com.bwssystems.HABridge.User user21 = null;
        java.lang.String str22 = bridgeSecurity4.addUser(user21);
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.setPassword(user23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "invalid user object given" + "'", str22.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
    }

    @Test
    public void test658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test658");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str16 = bridgeSecurity4.decrypt("vky18BIQu+s=");
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray21 = bridgeSecurity4.validateWhitelistUser("hi!", "\uFFFD\f\u0004\uFFFD\uFFFDE\u01F7\uFFFD\u0007g\\^\uFFFD\uFFFDjC\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test659");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str16 = bridgeSecurity4.decrypt("vky18BIQu+s=");
        com.bwssystems.HABridge.User user17 = null;
        com.bwssystems.HABridge.LoginResult loginResult18 = bridgeSecurity4.validatePassword(user17);
        spark.Request request19 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user20 = bridgeSecurity4.getAuthenticatedUser(request19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult18);
    }

    @Test
    public void test660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test660");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.delUser(user10);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test661");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        java.lang.String str19 = bridgeSecurity4.getExecGarden();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap20);
    }

    @Test
    public void test662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test662");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        java.lang.String str20 = bridgeSecurity4.encrypt("hi!");
        com.bwssystems.HABridge.User user21 = null;
        java.lang.String str22 = bridgeSecurity4.addUser(user21);
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.addUser(user23);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray28 = bridgeSecurity4.validateWhitelistUser("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao", "6e9e7ee432894f038d93910b9500043a", true);
        char[] charArray31 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity33 = new com.bwssystems.HABridge.BridgeSecurity(charArray31, "hi!");
        bridgeSecurity33.setSettingsChanged(false);
        java.lang.String str37 = bridgeSecurity33.encrypt("");
        com.bwssystems.HABridge.User user38 = null;
        com.bwssystems.HABridge.LoginResult loginResult39 = bridgeSecurity33.validatePassword(user38);
        bridgeSecurity33.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray45 = bridgeSecurity33.validateWhitelistUser("vky18BIQu+s=", "", false);
        java.lang.String str47 = bridgeSecurity33.findWhitelistUserByDeviceType("OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==");
        char[] charArray50 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity52 = new com.bwssystems.HABridge.BridgeSecurity(charArray50, "hi!");
        java.lang.String str53 = bridgeSecurity52.getExecGarden();
        bridgeSecurity52.setSecurityData("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user56 = null;
        java.lang.String str57 = bridgeSecurity52.setPassword(user56);
        bridgeSecurity52.setSecurityData("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==");
        char[] charArray62 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity64 = new com.bwssystems.HABridge.BridgeSecurity(charArray62, "hi!");
        bridgeSecurity64.setSettingsChanged(false);
        java.lang.String str68 = bridgeSecurity64.encrypt("");
        com.bwssystems.HABridge.User user69 = null;
        com.bwssystems.HABridge.LoginResult loginResult70 = bridgeSecurity64.validatePassword(user69);
        bridgeSecurity64.setSecurityData("null");
        com.bwssystems.HABridge.User user73 = null;
        com.bwssystems.HABridge.LoginResult loginResult74 = bridgeSecurity64.validatePassword(user73);
        java.lang.String str76 = bridgeSecurity64.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity64.setUseLinkButton(true);
        java.lang.String str80 = bridgeSecurity64.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean81 = bridgeSecurity64.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap82 = bridgeSecurity64.getWhitelist();
        bridgeSecurity52.setWhitelist(strMap82);
        bridgeSecurity33.convertWhitelist(strMap82);
        bridgeSecurity4.convertWhitelist(strMap82);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "kL+KdGOexBw=" + "'", str20.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "invalid user object given" + "'", str22.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "3EYePaPfLTY=" + "'", str37.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "invalid user object given" + "'", str57.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "3EYePaPfLTY=" + "'", str68.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult70);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult74);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str76 + "' != '" + "269915eca5ad46f3b19438a4294f5925" + "'", str76.equals("269915eca5ad46f3b19438a4294f5925"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str80.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap82);
    }

    @Test
    public void test663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test663");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        spark.Request request17 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user18 = bridgeSecurity4.getAuthenticatedUser(request17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a4e9b98f7ce24ad5b42abd5e5f44edb3" + "'", str16.equals("a4e9b98f7ce24ad5b42abd5e5f44edb3"));
    }

    @Test
    public void test664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test664");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        java.lang.String str10 = bridgeSecurity4.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "kL+KdGOexBw=" + "'", str9.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test665");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "rpTAMT1wSYokbaECEIDKbnDbouvA/Wlra1EBrHtPCFtqn/ZaZ2FBQA==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity14 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity16 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "a87d69b8970b442f8a4a40a44266ec49");
        boolean boolean17 = bridgeSecurity16.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test666");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("hi!");
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str12 = bridgeSecurity4.encrypt("ba2b415b3ce14cdf9c092497e0f37278");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "kL+KdGOexBw=" + "'", str9.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "vky18BIQu+s=" + "'", str10.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "nHO1DOrzWt6Qm4xjGGPNA5HjJ3Tv1rElvVGNRssldvYYDn13nnIsFA==" + "'", str12.equals("nHO1DOrzWt6Qm4xjGGPNA5HjJ3Tv1rElvVGNRssldvYYDn13nnIsFA=="));
    }

    @Test
    public void test667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test667");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test668");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        bridgeSecurity4.setSecureHueApi(true);
        char[] charArray19 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity21 = new com.bwssystems.HABridge.BridgeSecurity(charArray19, "hi!");
        bridgeSecurity21.setSettingsChanged(false);
        java.lang.String str25 = bridgeSecurity21.encrypt("");
        com.bwssystems.HABridge.User user26 = null;
        com.bwssystems.HABridge.LoginResult loginResult27 = bridgeSecurity21.validatePassword(user26);
        bridgeSecurity21.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray33 = bridgeSecurity21.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user34 = null;
        java.lang.String str35 = bridgeSecurity21.setPassword(user34);
        java.lang.String str37 = bridgeSecurity21.encrypt("hi!");
        com.bwssystems.HABridge.User user38 = null;
        java.lang.String str39 = bridgeSecurity21.addUser(user38);
        char[] charArray42 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity44 = new com.bwssystems.HABridge.BridgeSecurity(charArray42, "hi!");
        java.lang.String str45 = bridgeSecurity44.getExecGarden();
        java.lang.String str46 = bridgeSecurity44.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user47 = null;
        java.lang.String str48 = bridgeSecurity44.delUser(user47);
        java.lang.String str49 = bridgeSecurity44.getSecurityDescriptorData();
        java.lang.String str51 = bridgeSecurity44.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user52 = null;
        java.lang.String str53 = bridgeSecurity44.setPassword(user52);
        boolean boolean54 = bridgeSecurity44.isSettingsChanged();
        bridgeSecurity44.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str57 = bridgeSecurity44.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap58 = bridgeSecurity44.getWhitelist();
        char[] charArray61 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity63 = new com.bwssystems.HABridge.BridgeSecurity(charArray61, "hi!");
        bridgeSecurity63.setSettingsChanged(false);
        java.lang.String str67 = bridgeSecurity63.encrypt("");
        com.bwssystems.HABridge.User user68 = null;
        com.bwssystems.HABridge.LoginResult loginResult69 = bridgeSecurity63.validatePassword(user68);
        bridgeSecurity63.setSecurityData("null");
        com.bwssystems.HABridge.User user72 = null;
        com.bwssystems.HABridge.LoginResult loginResult73 = bridgeSecurity63.validatePassword(user72);
        java.lang.String str75 = bridgeSecurity63.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity63.setUseLinkButton(true);
        java.lang.String str79 = bridgeSecurity63.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean80 = bridgeSecurity63.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap81 = bridgeSecurity63.getWhitelist();
        bridgeSecurity44.convertWhitelist(strMap81);
        bridgeSecurity21.convertWhitelist(strMap81);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap84 = bridgeSecurity21.getWhitelist();
        bridgeSecurity4.setWhitelist(strMap84);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3EYePaPfLTY=" + "'", str25.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "invalid user object given" + "'", str35.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "kL+KdGOexBw=" + "'", str37.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "invalid user object given" + "'", str39.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "vky18BIQu+s=" + "'", str46.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "invalid user object given" + "'", str48.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "vky18BIQu+s=" + "'", str49.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "3EYePaPfLTY=" + "'", str51.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "invalid user object given" + "'", str53.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str57.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray61);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3EYePaPfLTY=" + "'", str67.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult69);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult73);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str75 + "' != '" + "9fbe0c6272f747098b0aebd3c210f322" + "'", str75.equals("9fbe0c6272f747098b0aebd3c210f322"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str79.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap81);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap84);
    }

    @Test
    public void test669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test669");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.Class<?> wildcardClass15 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test670");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        boolean boolean12 = bridgeSecurity4.isSecure();
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.delUser(user15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test671");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "rpTAMT1wSYokbaECEIDKbnDbouvA/Wlra1EBrHtPCFtqn/ZaZ2FBQA==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity14 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity16 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "a87d69b8970b442f8a4a40a44266ec49");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity18 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "6f89e1f613bc43d39d8e86cbc5dd3914");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test672");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        bridgeSecurity4.setSecureHueApi(true);
        boolean boolean22 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test673");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        boolean boolean8 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test674");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.lang.String str8 = bridgeSecurity4.encrypt("null");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray14 = bridgeSecurity4.validateWhitelistUser("null", "Tz9tiAIAEnmKS1GMfDZ6/g==", true);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.delUser(user15);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo17 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "vky18BIQu+s=" + "'", str8.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test675");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        boolean boolean10 = bridgeSecurity4.isSettingsChanged();
        spark.Request request11 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user12 = bridgeSecurity4.getAuthenticatedUser(request11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test676");
        char[] charArray5 = new char[] { '4', '4', ' ', ' ', '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity7 = new com.bwssystems.HABridge.BridgeSecurity(charArray5, "");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity9 = new com.bwssystems.HABridge.BridgeSecurity(charArray5, "6f89e1f613bc43d39d8e86cbc5dd3914");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test677");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity8.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        com.bwssystems.HABridge.LoginResult loginResult12 = bridgeSecurity8.validatePassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity8.addUser(user13);
        java.lang.String str16 = bridgeSecurity8.encrypt("29bcbebd2c5b459da1d142deafdd72a0");
        java.lang.String str17 = bridgeSecurity8.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str19 = bridgeSecurity8.findWhitelistUserByDeviceType("7f2db4f220d849f8b1e4019acd9f2e4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "t0Xx+HXTLr+rqj3DRV4xUYo75zRCw7O5NBPMk+P0a1SbRmxc94jCqA==" + "'", str16.equals("t0Xx+HXTLr+rqj3DRV4xUYo75zRCw7O5NBPMk+P0a1SbRmxc94jCqA=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "vky18BIQu+s=" + "'", str17.equals("vky18BIQu+s="));
    }

    @Test
    public void test678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test678");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        char[] charArray15 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity17 = new com.bwssystems.HABridge.BridgeSecurity(charArray15, "hi!");
        java.lang.String str18 = bridgeSecurity17.getExecGarden();
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity17.delUser(user19);
        bridgeSecurity17.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean23 = bridgeSecurity17.isSecure();
        java.lang.String str25 = bridgeSecurity17.decrypt("3EYePaPfLTY=");
        char[] charArray28 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity30 = new com.bwssystems.HABridge.BridgeSecurity(charArray28, "hi!");
        bridgeSecurity30.setSettingsChanged(false);
        java.lang.String str34 = bridgeSecurity30.encrypt("");
        com.bwssystems.HABridge.User user35 = null;
        com.bwssystems.HABridge.LoginResult loginResult36 = bridgeSecurity30.validatePassword(user35);
        bridgeSecurity30.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray42 = bridgeSecurity30.validateWhitelistUser("vky18BIQu+s=", "", false);
        java.lang.String str44 = bridgeSecurity30.findWhitelistUserByDeviceType("OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==");
        char[] charArray47 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity49 = new com.bwssystems.HABridge.BridgeSecurity(charArray47, "hi!");
        java.lang.String str50 = bridgeSecurity49.getExecGarden();
        bridgeSecurity49.setSecurityData("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user53 = null;
        java.lang.String str54 = bridgeSecurity49.setPassword(user53);
        bridgeSecurity49.setSecurityData("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==");
        char[] charArray59 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity61 = new com.bwssystems.HABridge.BridgeSecurity(charArray59, "hi!");
        bridgeSecurity61.setSettingsChanged(false);
        java.lang.String str65 = bridgeSecurity61.encrypt("");
        com.bwssystems.HABridge.User user66 = null;
        com.bwssystems.HABridge.LoginResult loginResult67 = bridgeSecurity61.validatePassword(user66);
        bridgeSecurity61.setSecurityData("null");
        com.bwssystems.HABridge.User user70 = null;
        com.bwssystems.HABridge.LoginResult loginResult71 = bridgeSecurity61.validatePassword(user70);
        java.lang.String str73 = bridgeSecurity61.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity61.setUseLinkButton(true);
        java.lang.String str77 = bridgeSecurity61.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean78 = bridgeSecurity61.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap79 = bridgeSecurity61.getWhitelist();
        bridgeSecurity49.setWhitelist(strMap79);
        bridgeSecurity30.convertWhitelist(strMap79);
        bridgeSecurity17.setWhitelist(strMap79);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "3EYePaPfLTY=" + "'", str34.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "invalid user object given" + "'", str54.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray59);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "3EYePaPfLTY=" + "'", str65.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult67);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult71);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str73 + "' != '" + "6962997c6efb43fd851902c3591cc561" + "'", str73.equals("6962997c6efb43fd851902c3591cc561"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str77.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap79);
    }

    @Test
    public void test679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test679");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.lang.String str11 = bridgeSecurity4.findWhitelistUserByDeviceType("YEunCl55a+cBkjozhBjMSw==");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap12 = null;
        bridgeSecurity4.setWhitelist(strMap12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.addUser(user14);
        bridgeSecurity4.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test680");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        java.lang.String str21 = bridgeSecurity4.encrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean22 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q=" + "'", str21.equals("qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test681");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = bridgeSecurity4.getWhitelist();
        bridgeSecurity4.setUseLinkButton(false);
        spark.Request request20 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap17);
    }

    @Test
    public void test682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test682");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.lang.String str8 = bridgeSecurity4.encrypt("null");
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str11 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "vky18BIQu+s=" + "'", str8.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test683");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        java.lang.String str17 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test684");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        java.lang.String str18 = bridgeSecurity4.encrypt("invalid user object given");
        spark.Request request19 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user20 = bridgeSecurity4.getAuthenticatedUser(request19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=" + "'", str18.equals("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg="));
    }

    @Test
    public void test685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test685");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        bridgeSecurity4.setWhitelist(strMap13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("null", "YEunCl55a+cBkjozhBjMSw==", true);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = null;
        bridgeSecurity4.setWhitelist(strMap20);
        java.lang.String str22 = bridgeSecurity4.getExecGarden();
        java.lang.String str23 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str23.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
    }

    @Test
    public void test686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test686");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        java.lang.String str9 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3EYePaPfLTY=" + "'", str7.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test687");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test688");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        com.bwssystems.HABridge.User user18 = null;
        com.bwssystems.HABridge.LoginResult loginResult19 = bridgeSecurity4.validatePassword(user18);
        spark.Request request20 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user21 = bridgeSecurity4.getAuthenticatedUser(request20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult19);
    }

    @Test
    public void test689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test689");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test690");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        bridgeSecurity4.setSecurityData("null");
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("69d8fe9344d940b1ac27bb6d3f620d39");
        boolean boolean17 = bridgeSecurity4.isSecure();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test691");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        bridgeSecurity4.setWhitelist(strMap13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("null", "YEunCl55a+cBkjozhBjMSw==", true);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.addUser(user20);
        java.lang.String str22 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str24 = bridgeSecurity4.decrypt("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str22.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{\"useLinkButton\":false,\"secureHueApi\":false}" + "'", str24.equals("{\"useLinkButton\":false,\"secureHueApi\":false}"));
    }

    @Test
    public void test692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test692");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        com.bwssystems.HABridge.LoginResult loginResult13 = bridgeSecurity4.validatePassword(user12);
        java.lang.String str15 = bridgeSecurity4.encrypt("9b2be6d12e1846cba1b5f6a16b3251ef");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = bridgeSecurity4.createWhitelistUser("r8q+Z+qzF6UxtQEAesMbvUAV/7EfeIeYqdWbTiZV8Hp5mrhkJqOFGQ==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "vYZc6a3s/DHKd9ZP9/w9W3iGYf50Lxe+np7gZqQ6oNuWM1kkm/tbWg==" + "'", str15.equals("vYZc6a3s/DHKd9ZP9/w9W3iGYf50Lxe+np7gZqQ6oNuWM1kkm/tbWg=="));
    }

    @Test
    public void test693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test693");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.lang.String str14 = bridgeSecurity4.createWhitelistUser("415008f611d24b0baac0147ef09bfd50");
        bridgeSecurity4.setUseLinkButton(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a16e87e9eb0b471ea5823bdd3bf8e4c8" + "'", str14.equals("a16e87e9eb0b471ea5823bdd3bf8e4c8"));
    }

    @Test
    public void test694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test694");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = bridgeSecurity4.getWhitelist();
        spark.Request request18 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap17);
    }

    @Test
    public void test695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test695");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        bridgeSecurity4.setSecurityData("c9e5025ced324e8e98912d564245c4c1");
        java.lang.Class<?> wildcardClass11 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test696");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.delUser(user18);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo20 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test697");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test698");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        com.bwssystems.HABridge.SecurityInfo securityInfo17 = bridgeSecurity4.getSecurityInfo();
        com.bwssystems.HABridge.User user18 = null;
        com.bwssystems.HABridge.LoginResult loginResult19 = bridgeSecurity4.validatePassword(user18);
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.delUser(user20);
        com.bwssystems.HABridge.User user22 = null;
        java.lang.String str23 = bridgeSecurity4.setPassword(user22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "invalid user object given" + "'", str23.equals("invalid user object given"));
    }

    @Test
    public void test699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test699");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        java.lang.String str17 = bridgeSecurity4.encrypt("kL+KdGOexBw=");
        spark.Request request18 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str17.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
    }

    @Test
    public void test700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test700");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str18 = bridgeSecurity4.encrypt("WaMm26d5svFxJ1MHQvnBeOzin5v5Q9oCWjWjjFb1w1dFj1kMAfluAorf0nFmXyCOPlqgEybTvZWM9wldr7sh6GuAjxH96tlrbECcPbr6JRVomRCCJn9FxhTJG+rbwFX117Qp2IrSeG5S8lW/ss/zY2wdVjljyZD/qKdZgbGLhI7j+cHjuwSXX7SkDQ1cSzk3AkTCvQi5mxlhN1+8dQkTHX2h9XfdgrlsbHgoWPo7oT+cTDHgVf9ss6U3skW2luOFJyMOHOy9fNY3H6K4Mi7yYOodrJK6BVS/");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PG4bEuEJ4vDv28OwTKhkyT23M0OcYQpncPtV+9Xaqjbm5nyeswR5cDgfOePEtTOAtQ6sqCe9RfX4nV8WcfObMTVYtHVCFIk8J1eJ/Ui0xs/FG2tQsv9ScXl2fQ5Rkm35J8KRIii9tiWop4dReakCRsmJCZxDBO2ftjDXYelWYsALovmUTg/ZN1DxpMoYLy8fDvUB5jIreiYXU7+dt+uqmBJseUFAOl++wBDFuBMivvLeKiPrZDFFmyB9C0TH1++ztuDZXS3LCWAlUxv3y+ihWo55+gDJfk+D6RmNa+KeRdHrZX0P4QAFr2X6L7OjemL4ubKpXCf7TUVdj92lkX8eTiei95MCZVg3DKe7qicWtJgpnXxsC4dzuGLzg0e5lz/aV9z0NGrQJZg=" + "'", str18.equals("PG4bEuEJ4vDv28OwTKhkyT23M0OcYQpncPtV+9Xaqjbm5nyeswR5cDgfOePEtTOAtQ6sqCe9RfX4nV8WcfObMTVYtHVCFIk8J1eJ/Ui0xs/FG2tQsv9ScXl2fQ5Rkm35J8KRIii9tiWop4dReakCRsmJCZxDBO2ftjDXYelWYsALovmUTg/ZN1DxpMoYLy8fDvUB5jIreiYXU7+dt+uqmBJseUFAOl++wBDFuBMivvLeKiPrZDFFmyB9C0TH1++ztuDZXS3LCWAlUxv3y+ihWo55+gDJfk+D6RmNa+KeRdHrZX0P4QAFr2X6L7OjemL4ubKpXCf7TUVdj92lkX8eTiei95MCZVg3DKe7qicWtJgpnXxsC4dzuGLzg0e5lz/aV9z0NGrQJZg="));
    }

    @Test
    public void test701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test701");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity8.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        com.bwssystems.HABridge.LoginResult loginResult12 = bridgeSecurity8.validatePassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity8.addUser(user13);
        java.lang.String str16 = bridgeSecurity8.encrypt("29bcbebd2c5b459da1d142deafdd72a0");
        java.lang.String str17 = bridgeSecurity8.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean18 = bridgeSecurity8.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "t0Xx+HXTLr+rqj3DRV4xUYo75zRCw7O5NBPMk+P0a1SbRmxc94jCqA==" + "'", str16.equals("t0Xx+HXTLr+rqj3DRV4xUYo75zRCw7O5NBPMk+P0a1SbRmxc94jCqA=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "vky18BIQu+s=" + "'", str17.equals("vky18BIQu+s="));
    }

    @Test
    public void test702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test702");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        java.lang.String str11 = bridgeSecurity4.encrypt("vky18BIQu+s=");
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSettingsChanged(true);
        spark.Request request15 = null;
        com.bwssystems.HABridge.User user16 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request15, user16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "YEunCl55a+cBkjozhBjMSw==" + "'", str11.equals("YEunCl55a+cBkjozhBjMSw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "vky18BIQu+s=" + "'", str12.equals("vky18BIQu+s="));
    }

    @Test
    public void test703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test703");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = bridgeSecurity4.getWhitelist();
        bridgeSecurity4.setUseLinkButton(false);
        bridgeSecurity4.setSecureHueApi(true);
        boolean boolean22 = bridgeSecurity4.isSecure();
        spark.Request request23 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test704");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        com.bwssystems.HABridge.SecurityInfo securityInfo17 = bridgeSecurity4.getSecurityInfo();
        com.bwssystems.HABridge.User user18 = null;
        com.bwssystems.HABridge.LoginResult loginResult19 = bridgeSecurity4.validatePassword(user18);
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.delUser(user20);
        java.lang.String str22 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str22 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDb8tLTV7R5XcnwcHs7x35TTp5E59X2xCkBwNAZFWm0Ed3USQZfjjuSPoO9wEFpc2PUbwAC8x4W0Nvo5qQioDze/Gt55pmNMp7BFOsYelUVdOgZbn+COeKw78hQ9GysBqWJZrtlQ7eU54BbRqI1//JaCSqWI7dQ9S78WHDR9ajIub" + "'", str22.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDb8tLTV7R5XcnwcHs7x35TTp5E59X2xCkBwNAZFWm0Ed3USQZfjjuSPoO9wEFpc2PUbwAC8x4W0Nvo5qQioDze/Gt55pmNMp7BFOsYelUVdOgZbn+COeKw78hQ9GysBqWJZrtlQ7eU54BbRqI1//JaCSqWI7dQ9S78WHDR9ajIub"));
    }

    @Test
    public void test705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test705");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
    }

    @Test
    public void test706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test706");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        java.lang.String str11 = bridgeSecurity4.decrypt("3EYePaPfLTY=");
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("85324a5cc5ad4e37bcb1c84831001f3f", "06ad7a26a22b4780aa1cf6e8f6f2db6e", true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test707");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        java.lang.String str21 = bridgeSecurity4.encrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str23 = bridgeSecurity4.createWhitelistUser("06ad7a26a22b4780aa1cf6e8f6f2db6e");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q=" + "'", str21.equals("qUSBHxIHNIKyy4d6hWyQLDwJIdFncR1RJ7o5CCYE0tDU2+rQb1qQcIXPvnPiEH9LVy9aOjDZkPbEwFXqBwCmHKzro27sb2zEkgcF6atJSsz6VndFsetVR5QvPk8znfhOK1lp563x21Q="));
    }

    @Test
    public void test708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test708");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        bridgeSecurity4.setSecurityData("null");
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("69d8fe9344d940b1ac27bb6d3f620d39");
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.setPassword(user19);
        spark.Request request21 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
    }

    @Test
    public void test709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test709");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str22 = bridgeSecurity4.decrypt("kL+KdGOexBw=");
        bridgeSecurity4.removeTestUsers();
        java.lang.String str25 = bridgeSecurity4.findWhitelistUserByDeviceType("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==");
        bridgeSecurity4.setSettingsChanged(false);
        boolean boolean28 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str30 = bridgeSecurity4.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str30.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
    }

    @Test
    public void test710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test710");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=");
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap20 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap20);
    }

    @Test
    public void test711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test711");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.setUseLinkButton(true);
        java.lang.String str20 = bridgeSecurity4.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean21 = bridgeSecurity4.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap22 = bridgeSecurity4.getWhitelist();
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.addUser(user23);
        boolean boolean25 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "fa46b729193b4d4797f2ca9b92c85ce9" + "'", str16.equals("fa46b729193b4d4797f2ca9b92c85ce9"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str20.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test712");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "3EYePaPfLTY=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str12 = bridgeSecurity10.encrypt("kL+KdGOexBw=");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity10.validatePassword(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str12.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
    }

    @Test
    public void test713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test713");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        bridgeSecurity4.convertWhitelist(strMap15);
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test714");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo16 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "vky18BIQu+s=" + "'", str13.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
    }

    @Test
    public void test715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test715");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.Class<?> wildcardClass16 = hueErrorArray15.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test716");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        java.lang.String str20 = bridgeSecurity4.encrypt("hi!");
        com.bwssystems.HABridge.User user21 = null;
        java.lang.String str22 = bridgeSecurity4.addUser(user21);
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.addUser(user23);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray28 = bridgeSecurity4.validateWhitelistUser("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao", "6e9e7ee432894f038d93910b9500043a", true);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap29 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "kL+KdGOexBw=" + "'", str20.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "invalid user object given" + "'", str22.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap29);
    }

    @Test
    public void test717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test717");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.lang.String str14 = bridgeSecurity4.createWhitelistUser("415008f611d24b0baac0147ef09bfd50");
        java.lang.Class<?> wildcardClass15 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str14 + "' != '" + "6aa6ae76c68a44a4be30cb63e60e1b34" + "'", str14.equals("6aa6ae76c68a44a4be30cb63e60e1b34"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test718");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str20 = bridgeSecurity4.findWhitelistUserByDeviceType("ff532457ca3d495ca1ed5f138db53d0c");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test719");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str7 = bridgeSecurity6.getSecurityDescriptorData();
        spark.Request request8 = null;
        com.bwssystems.HABridge.User user9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.addAuthenticatedUser(request8, user9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "vky18BIQu+s=" + "'", str7.equals("vky18BIQu+s="));
    }

    @Test
    public void test720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test720");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        java.lang.String str19 = bridgeSecurity4.getExecGarden();
        java.lang.String str20 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str22 = bridgeSecurity4.encrypt("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str20.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PG4bEuEJ4vDv28OwTKhkyVvOOSID3C8FTCu4koxrG5Ejanngwess1Ue+oXELvpuxjPYacfnNMV4zdv2YzYnImC+/sfRq26t8" + "'", str22.equals("PG4bEuEJ4vDv28OwTKhkyVvOOSID3C8FTCu4koxrG5Ejanngwess1Ue+oXELvpuxjPYacfnNMV4zdv2YzYnImC+/sfRq26t8"));
    }

    @Test
    public void test721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test721");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        com.bwssystems.HABridge.SecurityInfo securityInfo21 = bridgeSecurity4.getSecurityInfo();
        java.lang.String str22 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.Class<?> wildcardClass23 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str22.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test722");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.setUseLinkButton(true);
        java.lang.String str20 = bridgeSecurity4.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean21 = bridgeSecurity4.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap22 = bridgeSecurity4.getWhitelist();
        boolean boolean23 = bridgeSecurity4.isUseLinkButton();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5ad259da84ea4194b76d267307434ee1" + "'", str16.equals("5ad259da84ea4194b76d267307434ee1"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str20.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test723");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
    }

    @Test
    public void test724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test724");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        java.lang.String str17 = bridgeSecurity4.encrypt("kL+KdGOexBw=");
        bridgeSecurity4.setSecurityData("vky18BIQu+s=");
        java.lang.String str20 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str17.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "vky18BIQu+s=" + "'", str20.equals("vky18BIQu+s="));
    }

    @Test
    public void test725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test725");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray13 = bridgeSecurity4.validateWhitelistUser("7a5bb535cb11413894b364274a94a1b5", "94c7dd28f3094a869b2e552600e9d1b2", true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray13);
    }

    @Test
    public void test726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test726");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str16 = bridgeSecurity4.decrypt("vky18BIQu+s=");
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        java.lang.String str21 = bridgeSecurity4.encrypt("r8q+Z+qzF6UxtQEAesMbvUAV/7EfeIeYqdWbTiZV8Hp5mrhkJqOFGQ==");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean22 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "BQLlg2avssKuA3tHG48yrQkYepFWwI2iyuZpatSxp9WgrEAmx4i26y7sZfjN90pCG43JNHQl7lGaFqVf7E+Sng==" + "'", str21.equals("BQLlg2avssKuA3tHG48yrQkYepFWwI2iyuZpatSxp9WgrEAmx4i26y7sZfjN90pCG43JNHQl7lGaFqVf7E+Sng=="));
    }

    @Test
    public void test727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test727");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        bridgeSecurity4.setSecurityData("OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==");
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.delUser(user16);
        boolean boolean18 = bridgeSecurity4.isSecure();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test728");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.delUser(user18);
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str23 = bridgeSecurity4.encrypt("kL+KdGOexBw=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "efmI7rRPXdi3mmYSHGk6Gw==" + "'", str23.equals("efmI7rRPXdi3mmYSHGk6Gw=="));
    }

    @Test
    public void test729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test729");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = null;
        bridgeSecurity4.setWhitelist(strMap17);
        boolean boolean19 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str21 = bridgeSecurity4.encrypt("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDb8tLTV7R5XcnwcHs7x35TSWI8xflvmMYh+yICtCR2RL6bEt1KIf451ZrEklTie8gbS5osQPdqt3gutt0lQF2rrSf6w7VQjsGBVRALaZmLjiRR16f680kATaFXn0nDB7CtuAc1lftISWFLcWHmnc0uQWDYVt2k9fYHDglesLGO9ogRhhEvo+1QfYfi4gmVi3FbYP5x7raXBlkwTdH9+Ye8E=");
        boolean boolean22 = bridgeSecurity4.isUseLinkButton();
        boolean boolean23 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PG4bEuEJ4vDv28OwTKhkyVvOOSID3C8FTCu4koxrG5Ejanngwess1Ue+oXELvpuxk6XZSCci1loipJvIoXZzVmxqB+KSKjrO0XcAj7IHldE/M1iOrddS1Guy6QBuCN3KF+bRjHgTATxO+9zc0kwziLskh0ctkrzQWGVM6RzKIx6gPyK6rdm2YzVsrEYbhYftmdGuH1gomyF2nCxmmbRJ6Igo6A99vIayimu+w/RDqwLoS5PBjBDFFNMmabfJ0iTFTrhrZ7c8inECboUhBX7XeNGJwdxONeLPs3vXiB3zQ465QMep9uLZyiZ5ZoD1Saj48GhWVAXG8SsXQs+I43Xt9yLa11Mv6V8QfUPEWLxxIrQ=" + "'", str21.equals("PG4bEuEJ4vDv28OwTKhkyVvOOSID3C8FTCu4koxrG5Ejanngwess1Ue+oXELvpuxk6XZSCci1loipJvIoXZzVmxqB+KSKjrO0XcAj7IHldE/M1iOrddS1Guy6QBuCN3KF+bRjHgTATxO+9zc0kwziLskh0ctkrzQWGVM6RzKIx6gPyK6rdm2YzVsrEYbhYftmdGuH1gomyF2nCxmmbRJ6Igo6A99vIayimu+w/RDqwLoS5PBjBDFFNMmabfJ0iTFTrhrZ7c8inECboUhBX7XeNGJwdxONeLPs3vXiB3zQ465QMep9uLZyiZ5ZoD1Saj48GhWVAXG8SsXQs+I43Xt9yLa11Mv6V8QfUPEWLxxIrQ="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test730");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        java.lang.String str9 = bridgeSecurity6.decrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test731");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(false);
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.addUser(user18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test732");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        char[] charArray16 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity18 = new com.bwssystems.HABridge.BridgeSecurity(charArray16, "hi!");
        bridgeSecurity18.setSettingsChanged(false);
        java.lang.String str22 = bridgeSecurity18.encrypt("");
        com.bwssystems.HABridge.User user23 = null;
        com.bwssystems.HABridge.LoginResult loginResult24 = bridgeSecurity18.validatePassword(user23);
        bridgeSecurity18.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray30 = bridgeSecurity18.validateWhitelistUser("vky18BIQu+s=", "", false);
        char[] charArray33 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity35 = new com.bwssystems.HABridge.BridgeSecurity(charArray33, "hi!");
        bridgeSecurity35.setSettingsChanged(false);
        java.lang.String str39 = bridgeSecurity35.encrypt("");
        com.bwssystems.HABridge.User user40 = null;
        com.bwssystems.HABridge.LoginResult loginResult41 = bridgeSecurity35.validatePassword(user40);
        bridgeSecurity35.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray47 = bridgeSecurity35.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user48 = null;
        java.lang.String str49 = bridgeSecurity35.setPassword(user48);
        java.lang.String str51 = bridgeSecurity35.encrypt("hi!");
        com.bwssystems.HABridge.User user52 = null;
        java.lang.String str53 = bridgeSecurity35.addUser(user52);
        char[] charArray56 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity58 = new com.bwssystems.HABridge.BridgeSecurity(charArray56, "hi!");
        java.lang.String str59 = bridgeSecurity58.getExecGarden();
        java.lang.String str60 = bridgeSecurity58.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user61 = null;
        java.lang.String str62 = bridgeSecurity58.delUser(user61);
        java.lang.String str63 = bridgeSecurity58.getSecurityDescriptorData();
        java.lang.String str65 = bridgeSecurity58.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user66 = null;
        java.lang.String str67 = bridgeSecurity58.setPassword(user66);
        boolean boolean68 = bridgeSecurity58.isSettingsChanged();
        bridgeSecurity58.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str71 = bridgeSecurity58.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap72 = bridgeSecurity58.getWhitelist();
        char[] charArray75 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity77 = new com.bwssystems.HABridge.BridgeSecurity(charArray75, "hi!");
        bridgeSecurity77.setSettingsChanged(false);
        java.lang.String str81 = bridgeSecurity77.encrypt("");
        com.bwssystems.HABridge.User user82 = null;
        com.bwssystems.HABridge.LoginResult loginResult83 = bridgeSecurity77.validatePassword(user82);
        bridgeSecurity77.setSecurityData("null");
        com.bwssystems.HABridge.User user86 = null;
        com.bwssystems.HABridge.LoginResult loginResult87 = bridgeSecurity77.validatePassword(user86);
        java.lang.String str89 = bridgeSecurity77.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity77.setUseLinkButton(true);
        java.lang.String str93 = bridgeSecurity77.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean94 = bridgeSecurity77.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap95 = bridgeSecurity77.getWhitelist();
        bridgeSecurity58.convertWhitelist(strMap95);
        bridgeSecurity35.convertWhitelist(strMap95);
        bridgeSecurity18.convertWhitelist(strMap95);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "3EYePaPfLTY=" + "'", str22.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "3EYePaPfLTY=" + "'", str39.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "invalid user object given" + "'", str49.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "kL+KdGOexBw=" + "'", str51.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "invalid user object given" + "'", str53.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "vky18BIQu+s=" + "'", str60.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "invalid user object given" + "'", str62.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "vky18BIQu+s=" + "'", str63.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "3EYePaPfLTY=" + "'", str65.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "invalid user object given" + "'", str67.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str71.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap72);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray75);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "3EYePaPfLTY=" + "'", str81.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult83);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult87);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str89 + "' != '" + "53898a43448147fcac5cf7c8c01cbbb8" + "'", str89.equals("53898a43448147fcac5cf7c8c01cbbb8"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str93.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap95);
    }

    @Test
    public void test733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test733");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user12 = null;
        com.bwssystems.HABridge.LoginResult loginResult13 = bridgeSecurity4.validatePassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test734");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        java.lang.String str17 = bridgeSecurity4.getExecGarden();
        java.lang.String str18 = bridgeSecurity4.getSecurityDescriptorData();
        char[] charArray21 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity23 = new com.bwssystems.HABridge.BridgeSecurity(charArray21, "hi!");
        bridgeSecurity23.setSettingsChanged(false);
        java.lang.String str27 = bridgeSecurity23.encrypt("");
        boolean boolean28 = bridgeSecurity23.isSettingsChanged();
        com.bwssystems.HABridge.User user29 = null;
        com.bwssystems.HABridge.LoginResult loginResult30 = bridgeSecurity23.validatePassword(user29);
        com.bwssystems.HABridge.User user31 = null;
        java.lang.String str32 = bridgeSecurity23.setPassword(user31);
        com.bwssystems.HABridge.User user33 = null;
        java.lang.String str34 = bridgeSecurity23.setPassword(user33);
        java.lang.String str35 = bridgeSecurity23.getSecurityDescriptorData();
        bridgeSecurity23.setSecurityData("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=");
        boolean boolean38 = bridgeSecurity23.isUseLinkButton();
        char[] charArray41 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity43 = new com.bwssystems.HABridge.BridgeSecurity(charArray41, "hi!");
        bridgeSecurity43.setSettingsChanged(false);
        java.lang.String str47 = bridgeSecurity43.encrypt("");
        com.bwssystems.HABridge.User user48 = null;
        com.bwssystems.HABridge.LoginResult loginResult49 = bridgeSecurity43.validatePassword(user48);
        bridgeSecurity43.setSecurityData("null");
        com.bwssystems.HABridge.User user52 = null;
        com.bwssystems.HABridge.LoginResult loginResult53 = bridgeSecurity43.validatePassword(user52);
        java.lang.String str55 = bridgeSecurity43.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity43.setUseLinkButton(true);
        java.lang.String str59 = bridgeSecurity43.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean60 = bridgeSecurity43.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap61 = bridgeSecurity43.getWhitelist();
        bridgeSecurity23.setWhitelist(strMap61);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "vky18BIQu+s=" + "'", str18.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "3EYePaPfLTY=" + "'", str27.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "invalid user object given" + "'", str32.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "invalid user object given" + "'", str34.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "vky18BIQu+s=" + "'", str35.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "3EYePaPfLTY=" + "'", str47.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult53);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str55 + "' != '" + "79c92a7063754046bd51baafd4f54d51" + "'", str55.equals("79c92a7063754046bd51baafd4f54d51"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str59.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap61);
    }

    @Test
    public void test735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test735");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        com.bwssystems.HABridge.SecurityInfo securityInfo21 = bridgeSecurity4.getSecurityInfo();
        java.lang.String str22 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request23 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str22.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
    }

    @Test
    public void test736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test736");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.addUser(user18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test737");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
    }

    @Test
    public void test738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test738");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "t0Xx+HXTLr+rqj3DRV4xUYo75zRCw7O5NBPMk+P0a1SbRmxc94jCqA==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test739");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "29bcbebd2c5b459da1d142deafdd72a0");
        java.lang.Class<?> wildcardClass13 = charArray2.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test740");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test741");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        boolean boolean11 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3EYePaPfLTY=" + "'", str7.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test742");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.lang.String str21 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        bridgeSecurity4.removeTestUsers();
        bridgeSecurity4.setSecurityData("null");
        boolean boolean25 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test743");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray20 = bridgeSecurity4.validateWhitelistUser("", "OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str22 = bridgeSecurity4.findWhitelistUserByDeviceType("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray20);
    }

    @Test
    public void test744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test744");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        java.lang.String str19 = bridgeSecurity4.getExecGarden();
        java.lang.String str20 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean21 = bridgeSecurity4.isSecureHueApi();
        bridgeSecurity4.setUseLinkButton(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str20.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test745");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        java.lang.String str16 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap19 = bridgeSecurity4.getWhitelist();
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.addUser(user20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "vky18BIQu+s=" + "'", str16.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
    }

    @Test
    public void test746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test746");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test747");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "ff532457ca3d495ca1ed5f138db53d0c");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test748");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.lang.String str11 = bridgeSecurity4.findWhitelistUserByDeviceType("YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.User user12 = null;
        com.bwssystems.HABridge.LoginResult loginResult13 = bridgeSecurity4.validatePassword(user12);
        com.bwssystems.HABridge.SecurityInfo securityInfo14 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.removeTestUsers();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo14);
    }

    @Test
    public void test749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test749");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.Class<?> wildcardClass11 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "vky18BIQu+s=" + "'", str10.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test750");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.SecurityInfo securityInfo19 = bridgeSecurity4.getSecurityInfo();
        boolean boolean20 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test751");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        boolean boolean19 = bridgeSecurity4.isUseLinkButton();
        java.lang.String str21 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        bridgeSecurity4.removeTestUsers();
        boolean boolean23 = bridgeSecurity4.isSecure();
        java.lang.String str24 = bridgeSecurity4.getExecGarden();
        spark.Request request25 = null;
        com.bwssystems.HABridge.User user26 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request25, user26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
    }

    @Test
    public void test752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test752");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        bridgeSecurity4.convertWhitelist(strMap15);
        boolean boolean17 = bridgeSecurity4.isSecure();
        java.lang.String str19 = bridgeSecurity4.findWhitelistUserByDeviceType("");
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.addUser(user20);
        bridgeSecurity4.removeTestUsers();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
    }

    @Test
    public void test753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test753");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "3EYePaPfLTY=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str11 = bridgeSecurity10.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "YEunCl55a+cBkjozhBjMSw==" + "'", str11.equals("YEunCl55a+cBkjozhBjMSw=="));
    }

    @Test
    public void test754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test754");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        bridgeSecurity6.setSecurityData("vky18BIQu+s=");
        java.lang.String str9 = bridgeSecurity6.getSecurityDescriptorData();
        java.lang.String str10 = bridgeSecurity6.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "vky18BIQu+s=" + "'", str10.equals("vky18BIQu+s="));
    }

    @Test
    public void test755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test755");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity6.addUser(user7);
        java.lang.String str9 = bridgeSecurity6.getExecGarden();
        java.lang.String str10 = bridgeSecurity6.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test756");
        char[] charArray0 = null;
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity2 = new com.bwssystems.HABridge.BridgeSecurity(charArray0, "TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE=");
        spark.Request request3 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user4 = bridgeSecurity2.getAuthenticatedUser(request3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }

    @Test
    public void test757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test757");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap21 = null;
        bridgeSecurity4.convertWhitelist(strMap21);
        boolean boolean23 = bridgeSecurity4.isSecure();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap24 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap24);
    }

    @Test
    public void test758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test758");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        java.lang.String str11 = bridgeSecurity4.decrypt("3EYePaPfLTY=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test759");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.getExecGarden();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "vky18BIQu+s=" + "'", str10.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test760");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        bridgeSecurity4.setSettingsChanged(false);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test761");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.addUser(user19);
        com.bwssystems.HABridge.User user21 = null;
        java.lang.String str22 = bridgeSecurity4.addUser(user21);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray26 = bridgeSecurity4.validateWhitelistUser("9f4baaf0ce184925bd2d1687893b7f02", "r8q+Z+qzF6UxtQEAesMbvUAV/7EfeIeYqdWbTiZV8Hp5mrhkJqOFGQ==", false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "invalid user object given" + "'", str22.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray26);
    }

    @Test
    public void test762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test762");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = null;
        bridgeSecurity4.setWhitelist(strMap17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.addUser(user19);
        java.lang.String str21 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str23 = bridgeSecurity4.createWhitelistUser("6aa6ae76c68a44a4be30cb63e60e1b34");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str21.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ed77876693de44acad6ed190b2a53e23" + "'", str23.equals("ed77876693de44acad6ed190b2a53e23"));
    }

    @Test
    public void test763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test763");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test764");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        bridgeSecurity4.setSecureHueApi(false);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap21 = bridgeSecurity4.getWhitelist();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap21);
    }

    @Test
    public void test765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test765");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test766");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str22 = bridgeSecurity4.decrypt("kL+KdGOexBw=");
        bridgeSecurity4.removeTestUsers();
        java.lang.String str25 = bridgeSecurity4.findWhitelistUserByDeviceType("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==");
        com.bwssystems.HABridge.SecurityInfo securityInfo26 = bridgeSecurity4.getSecurityInfo();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo26);
    }

    @Test
    public void test767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test767");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str21 = bridgeSecurity4.decrypt("ed5c05d7631141868d78915d5ce27cbf");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test768");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap18 = bridgeSecurity4.getWhitelist();
        java.lang.String str20 = bridgeSecurity4.createWhitelistUser("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        java.lang.String str22 = bridgeSecurity4.encrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap23 = null;
        bridgeSecurity4.convertWhitelist(strMap23);
        com.bwssystems.HABridge.SecurityInfo securityInfo25 = bridgeSecurity4.getSecurityInfo();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str17.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap18);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0e1dfd4bdb3b4ac2891cfb1f6d007aab" + "'", str20.equals("0e1dfd4bdb3b4ac2891cfb1f6d007aab"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE=" + "'", str22.equals("TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo25);
    }

    @Test
    public void test769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test769");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = bridgeSecurity4.getWhitelist();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str15 = bridgeSecurity4.decrypt("c003dd10f1474bc083e6426921b467d9");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap13);
    }

    @Test
    public void test770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test770");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        java.lang.String str15 = bridgeSecurity4.decrypt("TJqaVKwgQLBWSdgr9T5cQFm8pQx3H1fpqgmEwKt99tE=");
        java.lang.Class<?> wildcardClass16 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str15.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test771");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        bridgeSecurity4.setUseLinkButton(true);
        boolean boolean19 = bridgeSecurity4.isSecure();
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.setPassword(user20);
        java.lang.String str23 = bridgeSecurity4.encrypt("ff532457ca3d495ca1ed5f138db53d0c");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "bMXv7rQeRe+wvv5OF4wUjIK76HfoP4+g7xtb1wYRXBrLT+UVM4n4fA==" + "'", str23.equals("bMXv7rQeRe+wvv5OF4wUjIK76HfoP4+g7xtb1wYRXBrLT+UVM4n4fA=="));
    }

    @Test
    public void test772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test772");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        boolean boolean17 = bridgeSecurity4.isSecureHueApi();
        bridgeSecurity4.setUseLinkButton(true);
        bridgeSecurity4.setUseLinkButton(false);
        bridgeSecurity4.setUseLinkButton(false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str25 = bridgeSecurity4.decrypt("269915eca5ad46f3b19438a4294f5925");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test773");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        boolean boolean8 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo13 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test774");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        boolean boolean10 = bridgeSecurity4.isSecure();
        boolean boolean11 = bridgeSecurity4.isSecureHueApi();
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.addUser(user14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test775");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("3EYePaPfLTY=");
        java.lang.String str11 = bridgeSecurity4.encrypt("vky18BIQu+s=");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.addUser(user12);
        spark.Request request14 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user15 = bridgeSecurity4.getAuthenticatedUser(request14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Tz9tiAIAEnmKS1GMfDZ6/g==" + "'", str9.equals("Tz9tiAIAEnmKS1GMfDZ6/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "YEunCl55a+cBkjozhBjMSw==" + "'", str11.equals("YEunCl55a+cBkjozhBjMSw=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
    }

    @Test
    public void test776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test776");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "vky18BIQu+s=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity10.delUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity10.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test777");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str19 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str20 = bridgeSecurity4.getSecurityDescriptorData();
        char[] charArray23 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity25 = new com.bwssystems.HABridge.BridgeSecurity(charArray23, "hi!");
        bridgeSecurity25.setSettingsChanged(false);
        java.lang.String str29 = bridgeSecurity25.encrypt("");
        com.bwssystems.HABridge.User user30 = null;
        com.bwssystems.HABridge.LoginResult loginResult31 = bridgeSecurity25.validatePassword(user30);
        com.bwssystems.HABridge.User user32 = null;
        java.lang.String str33 = bridgeSecurity25.addUser(user32);
        com.bwssystems.HABridge.User user34 = null;
        java.lang.String str35 = bridgeSecurity25.setPassword(user34);
        com.bwssystems.HABridge.User user36 = null;
        java.lang.String str37 = bridgeSecurity25.addUser(user36);
        bridgeSecurity25.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        com.bwssystems.HABridge.SecurityInfo securityInfo40 = bridgeSecurity25.getSecurityInfo();
        java.lang.String str42 = bridgeSecurity25.createWhitelistUser("29bcbebd2c5b459da1d142deafdd72a0");
        com.bwssystems.HABridge.SecurityInfo securityInfo43 = bridgeSecurity25.getSecurityInfo();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap44 = bridgeSecurity25.getWhitelist();
        bridgeSecurity4.convertWhitelist(strMap44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str19.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str20.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "3EYePaPfLTY=" + "'", str29.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "invalid user object given" + "'", str33.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "invalid user object given" + "'", str35.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "invalid user object given" + "'", str37.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo40);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str42 + "' != '" + "bf17bed1f18d4c1fbc23a9df47642b42" + "'", str42.equals("bf17bed1f18d4c1fbc23a9df47642b42"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap44);
    }

    @Test
    public void test778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test778");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray15 = bridgeSecurity4.validateWhitelistUser("", "vky18BIQu+s=", false);
        java.lang.String str16 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.delUser(user17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test779");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        java.lang.String str20 = bridgeSecurity4.encrypt("hi!");
        com.bwssystems.HABridge.User user21 = null;
        java.lang.String str22 = bridgeSecurity4.addUser(user21);
        com.bwssystems.HABridge.User user23 = null;
        java.lang.String str24 = bridgeSecurity4.addUser(user23);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray28 = bridgeSecurity4.validateWhitelistUser("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao", "6e9e7ee432894f038d93910b9500043a", true);
        com.bwssystems.HABridge.SecurityInfo securityInfo29 = bridgeSecurity4.getSecurityInfo();
        boolean boolean30 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "kL+KdGOexBw=" + "'", str20.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "invalid user object given" + "'", str22.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "invalid user object given" + "'", str24.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test780");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        spark.Request request16 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test781");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        boolean boolean8 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.addUser(user9);
        spark.Request request11 = null;
        com.bwssystems.HABridge.User user12 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request11, user12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test782");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.lang.String str16 = bridgeSecurity4.decrypt("vky18BIQu+s=");
        boolean boolean17 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.setPassword(user18);
        java.lang.String str21 = bridgeSecurity4.encrypt("r8q+Z+qzF6UxtQEAesMbvUAV/7EfeIeYqdWbTiZV8Hp5mrhkJqOFGQ==");
        java.lang.String str23 = bridgeSecurity4.decrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "BQLlg2avssKuA3tHG48yrQkYepFWwI2iyuZpatSxp9WgrEAmx4i26y7sZfjN90pCG43JNHQl7lGaFqVf7E+Sng==" + "'", str21.equals("BQLlg2avssKuA3tHG48yrQkYepFWwI2iyuZpatSxp9WgrEAmx4i26y7sZfjN90pCG43JNHQl7lGaFqVf7E+Sng=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test783");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        com.bwssystems.HABridge.LoginResult loginResult13 = bridgeSecurity4.validatePassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test784");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean11 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = bridgeSecurity4.createWhitelistUser("6aa6ae76c68a44a4be30cb63e60e1b34");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "vky18BIQu+s=" + "'", str10.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test785");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.SecurityInfo securityInfo10 = bridgeSecurity4.getSecurityInfo();
        bridgeSecurity4.setSecurityData("c003dd10f1474bc083e6426921b467d9");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo10);
    }

    @Test
    public void test786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test786");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.getExecGarden();
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "vky18BIQu+s=" + "'", str10.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "vky18BIQu+s=" + "'", str12.equals("vky18BIQu+s="));
    }

    @Test
    public void test787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test787");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray16 = bridgeSecurity4.validateWhitelistUser("vky18BIQu+s=", "", false);
        char[] charArray19 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity21 = new com.bwssystems.HABridge.BridgeSecurity(charArray19, "hi!");
        bridgeSecurity21.setSettingsChanged(false);
        java.lang.String str25 = bridgeSecurity21.encrypt("");
        com.bwssystems.HABridge.User user26 = null;
        com.bwssystems.HABridge.LoginResult loginResult27 = bridgeSecurity21.validatePassword(user26);
        bridgeSecurity21.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray33 = bridgeSecurity21.validateWhitelistUser("3EYePaPfLTY=", "invalid user object given", true);
        com.bwssystems.HABridge.User user34 = null;
        java.lang.String str35 = bridgeSecurity21.setPassword(user34);
        java.lang.String str37 = bridgeSecurity21.encrypt("hi!");
        com.bwssystems.HABridge.User user38 = null;
        java.lang.String str39 = bridgeSecurity21.addUser(user38);
        char[] charArray42 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity44 = new com.bwssystems.HABridge.BridgeSecurity(charArray42, "hi!");
        java.lang.String str45 = bridgeSecurity44.getExecGarden();
        java.lang.String str46 = bridgeSecurity44.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user47 = null;
        java.lang.String str48 = bridgeSecurity44.delUser(user47);
        java.lang.String str49 = bridgeSecurity44.getSecurityDescriptorData();
        java.lang.String str51 = bridgeSecurity44.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user52 = null;
        java.lang.String str53 = bridgeSecurity44.setPassword(user52);
        boolean boolean54 = bridgeSecurity44.isSettingsChanged();
        bridgeSecurity44.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        java.lang.String str57 = bridgeSecurity44.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap58 = bridgeSecurity44.getWhitelist();
        char[] charArray61 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity63 = new com.bwssystems.HABridge.BridgeSecurity(charArray61, "hi!");
        bridgeSecurity63.setSettingsChanged(false);
        java.lang.String str67 = bridgeSecurity63.encrypt("");
        com.bwssystems.HABridge.User user68 = null;
        com.bwssystems.HABridge.LoginResult loginResult69 = bridgeSecurity63.validatePassword(user68);
        bridgeSecurity63.setSecurityData("null");
        com.bwssystems.HABridge.User user72 = null;
        com.bwssystems.HABridge.LoginResult loginResult73 = bridgeSecurity63.validatePassword(user72);
        java.lang.String str75 = bridgeSecurity63.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity63.setUseLinkButton(true);
        java.lang.String str79 = bridgeSecurity63.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean80 = bridgeSecurity63.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap81 = bridgeSecurity63.getWhitelist();
        bridgeSecurity44.convertWhitelist(strMap81);
        bridgeSecurity21.convertWhitelist(strMap81);
        bridgeSecurity4.convertWhitelist(strMap81);
        boolean boolean85 = bridgeSecurity4.isSettingsChanged();
        spark.Request request86 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "3EYePaPfLTY=" + "'", str25.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "invalid user object given" + "'", str35.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "kL+KdGOexBw=" + "'", str37.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "invalid user object given" + "'", str39.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "vky18BIQu+s=" + "'", str46.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "invalid user object given" + "'", str48.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "vky18BIQu+s=" + "'", str49.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "3EYePaPfLTY=" + "'", str51.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "invalid user object given" + "'", str53.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str57.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strMap58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray61);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3EYePaPfLTY=" + "'", str67.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult69);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult73);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str75 + "' != '" + "bc08effed5754039a72131ab89510d62" + "'", str75.equals("bc08effed5754039a72131ab89510d62"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str79.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap81);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test788");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        java.lang.Class<?> wildcardClass11 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test789");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("fBNQzVqmFPdeAXkTAEyoAjYYd5fez+3sbZRA68kxNvg=");
        java.lang.String str15 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str14.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "vky18BIQu+s=" + "'", str15.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
    }

    @Test
    public void test790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test790");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("null");
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.findWhitelistUserByDeviceType("3EYePaPfLTY=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = null;
        bridgeSecurity4.setWhitelist(strMap17);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.addUser(user19);
        java.lang.String str21 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecureHueApi(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str21.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
    }

    @Test
    public void test791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test791");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity4.removeTestUsers();
        java.lang.String str21 = bridgeSecurity4.createWhitelistUser("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M");
        com.bwssystems.HABridge.User user22 = null;
        java.lang.String str23 = bridgeSecurity4.setPassword(user22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str21 + "' != '" + "57eab76de4044b309b2f94fb139e1bb7" + "'", str21.equals("57eab76de4044b309b2f94fb139e1bb7"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "invalid user object given" + "'", str23.equals("invalid user object given"));
    }

    @Test
    public void test792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test792");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        boolean boolean14 = bridgeSecurity4.isSettingsChanged();
        bridgeSecurity4.setSecurityData("9f4baaf0ce184925bd2d1687893b7f02");
        boolean boolean17 = bridgeSecurity4.isSecureHueApi();
        bridgeSecurity4.setUseLinkButton(true);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test793");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str11 = bridgeSecurity4.decrypt("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.setPassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        com.bwssystems.HABridge.LoginResult loginResult15 = bridgeSecurity4.validatePassword(user14);
        java.lang.String str17 = bridgeSecurity4.decrypt("efmI7rRPXdi3mmYSHGk6Gw==");
        com.bwssystems.HABridge.User user18 = null;
        java.lang.String str19 = bridgeSecurity4.delUser(user18);
        bridgeSecurity4.setSettingsChanged(false);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap22 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "vky18BIQu+s=" + "'", str6.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vky18BIQu+s=" + "'", str9.equals("vky18BIQu+s="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3EYePaPfLTY=" + "'", str11.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "kL+KdGOexBw=" + "'", str17.equals("kL+KdGOexBw="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "invalid user object given" + "'", str19.equals("invalid user object given"));
    }

    @Test
    public void test794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test794");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSecurityData("YEunCl55a+cBkjozhBjMSw==");
        java.lang.String str19 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean20 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3EYePaPfLTY=" + "'", str8.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M" + "'", str19.equals("WaMm26d5svFxJ1MHQvnBeBhSvoh6AcR1dUpzXKx6hNm1QtQcJnwDDQj1gO09/X1M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test795");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        bridgeSecurity4.setSecurityData("Tz9tiAIAEnmKS1GMfDZ6/g==");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        char[] charArray14 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity16 = new com.bwssystems.HABridge.BridgeSecurity(charArray14, "hi!");
        bridgeSecurity16.setSettingsChanged(false);
        java.lang.String str20 = bridgeSecurity16.encrypt("");
        com.bwssystems.HABridge.User user21 = null;
        com.bwssystems.HABridge.LoginResult loginResult22 = bridgeSecurity16.validatePassword(user21);
        bridgeSecurity16.setSecurityData("null");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray28 = bridgeSecurity16.validateWhitelistUser("vky18BIQu+s=", "", false);
        java.lang.String str30 = bridgeSecurity16.findWhitelistUserByDeviceType("OFMmcvPPDT0saBt1L5serI/aIN+6gROo//v0VNqPUOeH/R6uJMmU5g==");
        char[] charArray33 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity35 = new com.bwssystems.HABridge.BridgeSecurity(charArray33, "hi!");
        java.lang.String str36 = bridgeSecurity35.getExecGarden();
        bridgeSecurity35.setSecurityData("3EYePaPfLTY=");
        com.bwssystems.HABridge.User user39 = null;
        java.lang.String str40 = bridgeSecurity35.setPassword(user39);
        bridgeSecurity35.setSecurityData("dS0r7n5A1xyOUAwNKOQKCQsgH9GywXISjR97lKJt7mvwStKgsyTQYg==");
        char[] charArray45 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity47 = new com.bwssystems.HABridge.BridgeSecurity(charArray45, "hi!");
        bridgeSecurity47.setSettingsChanged(false);
        java.lang.String str51 = bridgeSecurity47.encrypt("");
        com.bwssystems.HABridge.User user52 = null;
        com.bwssystems.HABridge.LoginResult loginResult53 = bridgeSecurity47.validatePassword(user52);
        bridgeSecurity47.setSecurityData("null");
        com.bwssystems.HABridge.User user56 = null;
        com.bwssystems.HABridge.LoginResult loginResult57 = bridgeSecurity47.validatePassword(user56);
        java.lang.String str59 = bridgeSecurity47.createWhitelistUser("YEunCl55a+cBkjozhBjMSw==");
        bridgeSecurity47.setUseLinkButton(true);
        java.lang.String str63 = bridgeSecurity47.decrypt("IAw6NaZtYlsYA85FeA+B6au3iuKqRWeTdv4vzSNJg7SuzFF3rDjQPXpm07iC0zTF01bUB7Vv8vv3wRuA8UhrzoF+ljq/vzqv");
        boolean boolean64 = bridgeSecurity47.isSettingsChanged();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap65 = bridgeSecurity47.getWhitelist();
        bridgeSecurity35.setWhitelist(strMap65);
        bridgeSecurity16.convertWhitelist(strMap65);
        bridgeSecurity4.setWhitelist(strMap65);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "3EYePaPfLTY=" + "'", str20.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "invalid user object given" + "'", str40.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "3EYePaPfLTY=" + "'", str51.equals("3EYePaPfLTY="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult53);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult57);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str59 + "' != '" + "03d4bde2941f4a4b9701374884626c1b" + "'", str59.equals("03d4bde2941f4a4b9701374884626c1b"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao" + "'", str63.equals("yTWss9mNHJFyRJ6CPYYgo3y0oxGT2eEzgLBJY/tC99v9I68C9+ts2qk93Q2H23ao"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap65);
		System.out.println("END testset at: "+ System.currentTimeMillis());
    }
}
