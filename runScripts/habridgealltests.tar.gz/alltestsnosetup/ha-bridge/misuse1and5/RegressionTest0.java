package randoopTest;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;
	public static int iteration = 0;
	
    @Test
    public void test001() throws Throwable {
		System.out.println("BEGIN iteration: "+ iteration);
        iteration+=1;
		System.out.println("BEGIN testset at: "+ System.currentTimeMillis());
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        spark.Request request5 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecurityData("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 21");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap6 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo13 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user14 = bridgeSecurity4.getAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UxvDKZLGWU4=" + "'", str9.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap11 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        java.lang.Class<?> wildcardClass8 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo11 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = bridgeSecurity4.decrypt("MKvsXKnSSls=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user11 = bridgeSecurity4.getAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UxvDKZLGWU4=" + "'", str9.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap5 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.findWhitelistUserByDeviceType("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("SSU/a04q1QOSC5z5iNTT4w==");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=" + "'", str14.equals("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0="));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean11 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap5 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        spark.Request request8 = null;
        com.bwssystems.HABridge.User user9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request8, user9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        spark.Request request8 = null;
        com.bwssystems.HABridge.User user9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request8, user9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.createWhitelistUser("SSU/a04q1QOSC5z5iNTT4w==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.delUser(user7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecurityData("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 21");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecurityData("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 21");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("YjOtnQ3PuFs=");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = bridgeSecurity4.decrypt("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 21");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.createWhitelistUser("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        java.lang.String str10 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        spark.Request request7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity6.removeAuthenticatedUser(request7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = bridgeSecurity4.decrypt("UxvDKZLGWU4=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecurityData("invalid user object given");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal base64 character 20");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MKvsXKnSSls=" + "'", str7.equals("MKvsXKnSSls="));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.Class<?> wildcardClass12 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.Class<?> wildcardClass5 = charArray2.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        java.lang.Class<?> wildcardClass7 = bridgeSecurity6.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.createWhitelistUser("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = bridgeSecurity4.findWhitelistUserByDeviceType("YjOtnQ3PuFs=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UxvDKZLGWU4=" + "'", str10.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UxvDKZLGWU4=" + "'", str9.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray12 = bridgeSecurity4.validateWhitelistUser("MKvsXKnSSls=", "UxvDKZLGWU4=", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        java.lang.Class<?> wildcardClass11 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.createWhitelistUser("invalid user object given");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        spark.Request request13 = null;
        com.bwssystems.HABridge.User user14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request13, user14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        spark.Request request9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        boolean boolean6 = bridgeSecurity4.isSettingsChanged();
        java.lang.Class<?> wildcardClass7 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        spark.Request request11 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user12 = bridgeSecurity4.getAuthenticatedUser(request11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.delUser(user15);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        boolean boolean6 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSettingsChanged(true);
        spark.Request request15 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user16 = bridgeSecurity4.getAuthenticatedUser(request15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        spark.Request request7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        spark.Request request7 = null;
        com.bwssystems.HABridge.User user8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request7, user8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean8 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UxvDKZLGWU4=" + "'", str13.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray14 = bridgeSecurity4.validateWhitelistUser("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J", "invalid user object given", true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap14 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UxvDKZLGWU4=" + "'", str13.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        java.lang.String str11 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        spark.Request request8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity3.removeAuthenticatedUser(request8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = bridgeSecurity4.findWhitelistUserByDeviceType("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.addUser(user13);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean15 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.addUser(user13);
        java.lang.String str15 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UxvDKZLGWU4=" + "'", str15.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getExecGarden();
        spark.Request request7 = null;
        com.bwssystems.HABridge.User user8 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request7, user8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        bridgeSecurity4.setSecurityData("YjOtnQ3PuFs=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap7 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "xQ6SmWgtvKo=" + "'", str6.equals("xQ6SmWgtvKo="));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request7 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user8 = bridgeSecurity4.getAuthenticatedUser(request7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "xQ6SmWgtvKo=" + "'", str6.equals("xQ6SmWgtvKo="));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        spark.Request request13 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user14 = bridgeSecurity4.getAuthenticatedUser(request13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        bridgeSecurity4.setSettingsChanged(true);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity3.validatePassword(user8);
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity3.removeAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        bridgeSecurity4.setSettingsChanged(true);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        boolean boolean6 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray12 = bridgeSecurity4.validateWhitelistUser("hi!", "TmdZ8cEBEN0=", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        spark.Request request6 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user7 = bridgeSecurity4.getAuthenticatedUser(request6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.addUser(user10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.delUser(user10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        java.lang.String str15 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        com.bwssystems.HABridge.LoginResult loginResult13 = bridgeSecurity4.validatePassword(user12);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap14 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult13);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        spark.Request request10 = null;
        com.bwssystems.HABridge.User user11 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request10, user11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        bridgeSecurity4.setSecurityData("");
        boolean boolean17 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("YjOtnQ3PuFs=");
        boolean boolean13 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        spark.Request request6 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.addUser(user13);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YjOtnQ3PuFs=");
        java.lang.String str8 = bridgeSecurity6.encrypt("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "z5O5eYyj7Gk=" + "'", str8.equals("z5O5eYyj7Gk="));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.createWhitelistUser("d95a1f34c7db4f3494ed4828650b1f98");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        java.lang.String str18 = bridgeSecurity4.createWhitelistUser("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray22 = bridgeSecurity4.validateWhitelistUser("xQ6SmWgtvKo=", "YjOtnQ3PuFs=", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass23 = hueErrorArray22.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1b82dd2a502a4c6bb1cfb57acbf31e31" + "'", str18.equals("1b82dd2a502a4c6bb1cfb57acbf31e31"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(hueErrorArray22);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        boolean boolean15 = bridgeSecurity4.isSecure();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        java.lang.String str17 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.String str19 = bridgeSecurity4.encrypt("d95a1f34c7db4f3494ed4828650b1f98");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=" + "'", str14.equals("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UxvDKZLGWU4=" + "'", str17.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2EkUIctFw9krKZHKiI5ppImih1pxqFBCSZqQaGdlWegJFjCJ3aaV0w==" + "'", str19.equals("2EkUIctFw9krKZHKiI5ppImih1pxqFBCSZqQaGdlWegJFjCJ3aaV0w=="));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        java.lang.Class<?> wildcardClass7 = charArray2.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "UxvDKZLGWU4=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        java.lang.Class<?> wildcardClass15 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        java.lang.String str8 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = bridgeSecurity4.findWhitelistUserByDeviceType("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UxvDKZLGWU4=" + "'", str8.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity8.setPassword(user9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.createWhitelistUser("z5O5eYyj7Gk=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        java.lang.String str11 = bridgeSecurity4.encrypt("UxvDKZLGWU4=");
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sPbDAe2fBG+wvoGdpgsr/g==" + "'", str11.equals("sPbDAe2fBG+wvoGdpgsr/g=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UxvDKZLGWU4=" + "'", str12.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity3.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo13 = bridgeSecurity4.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        spark.Request request11 = null;
        com.bwssystems.HABridge.User user12 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request11, user12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        spark.Request request10 = null;
        com.bwssystems.HABridge.User user11 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request10, user11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        java.lang.String str11 = bridgeSecurity4.encrypt("UxvDKZLGWU4=");
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap12 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sPbDAe2fBG+wvoGdpgsr/g==" + "'", str11.equals("sPbDAe2fBG+wvoGdpgsr/g=="));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        java.lang.String str8 = bridgeSecurity6.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity6.delUser(user9);
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.SecurityInfo securityInfo11 = bridgeSecurity6.getSecurityInfo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "xQ6SmWgtvKo=" + "'", str8.equals("xQ6SmWgtvKo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        java.lang.String str8 = bridgeSecurity3.getSecurityDescriptorData();
        java.lang.String str9 = bridgeSecurity3.getExecGarden();
        java.lang.String str10 = bridgeSecurity3.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TmdZ8cEBEN0=" + "'", str8.equals("TmdZ8cEBEN0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TmdZ8cEBEN0=" + "'", str10.equals("TmdZ8cEBEN0="));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray18 = bridgeSecurity4.validateWhitelistUser("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J", "MKvsXKnSSls=", true);
        boolean boolean19 = bridgeSecurity4.isSecureHueApi();
        com.bwssystems.HABridge.SecurityInfo securityInfo20 = bridgeSecurity4.getSecurityInfo();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(securityInfo20);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        java.lang.String str6 = bridgeSecurity4.setPassword(user5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = bridgeSecurity4.findWhitelistUserByDeviceType("z5O5eYyj7Gk=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "invalid user object given" + "'", str6.equals("invalid user object given"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        java.lang.Class<?> wildcardClass11 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        java.lang.String str8 = bridgeSecurity3.getSecurityDescriptorData();
        java.lang.String str9 = bridgeSecurity3.getExecGarden();
        java.lang.String str11 = bridgeSecurity3.encrypt("2EkUIctFw9krKZHKiI5ppImih1pxqFBCSZqQaGdlWegJFjCJ3aaV0w==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TmdZ8cEBEN0=" + "'", str8.equals("TmdZ8cEBEN0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "lFGRBLwp6e8pRwJe2IwZwC+Z+rYnrVSet3ip6V5FAl9L1VYOfFmCnYVLijdBgJmDC1KpJ3MUIzN6YjWwWhSaiw==" + "'", str11.equals("lFGRBLwp6e8pRwJe2IwZwC+Z+rYnrVSet3ip6V5FAl9L1VYOfFmCnYVLijdBgJmDC1KpJ3MUIzN6YjWwWhSaiw=="));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        spark.Request request6 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity3.removeAuthenticatedUser(request6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        java.lang.String str9 = bridgeSecurity4.getExecGarden();
        spark.Request request10 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MKvsXKnSSls=" + "'", str7.equals("MKvsXKnSSls="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.addUser(user17);
        spark.Request request19 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        spark.Request request12 = null;
        com.bwssystems.HABridge.User user13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request12, user13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        spark.Request request17 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeAuthenticatedUser(request17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity4.validatePassword(user8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.createWhitelistUser("SSU/a04q1QOSC5z5iNTT4w==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity3.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        spark.Request request8 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user9 = bridgeSecurity4.getAuthenticatedUser(request8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MKvsXKnSSls=" + "'", str7.equals("MKvsXKnSSls="));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("d95a1f34c7db4f3494ed4828650b1f98");
        bridgeSecurity4.setUseLinkButton(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "xQ6SmWgtvKo=" + "'", str6.equals("xQ6SmWgtvKo="));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request11 = null;
        com.bwssystems.HABridge.User user12 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request11, user12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UxvDKZLGWU4=" + "'", str10.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.delUser(user11);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        java.lang.String str17 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M");
        com.bwssystems.HABridge.User user20 = null;
        java.lang.String str21 = bridgeSecurity4.setPassword(user20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=" + "'", str14.equals("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "invalid user object given" + "'", str21.equals("invalid user object given"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity6.setPassword(user8);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = bridgeSecurity6.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = bridgeSecurity4.findWhitelistUserByDeviceType("ch1kwWYNgi9mbtnzrjMbb1+YjEvfxhxTtgmrXrOUsVhXW82ZVDjNJnLtsCLoPakKdzOiSsjmeogrUPKFYKJdA/iXdz4hLY4nhj1F0ajLkf9SESleBg/2KT3ve0MkCGAT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str13 = bridgeSecurity4.encrypt("lFGRBLwp6e8pRwJe2IwZwC+Z+rYnrVSet3ip6V5FAl9L1VYOfFmCnYVLijdBgJmDC1KpJ3MUIzN6YjWwWhSaiw==");
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.setPassword(user14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ch1kwWYNgi9mbtnzrjMbb1+YjEvfxhxTtgmrXrOUsVhXW82ZVDjNJnLtsCLoPakKdzOiSsjmeogrUPKFYKJdA/iXdz4hLY4nhj1F0ajLkf9SESleBg/2KT3ve0MkCGAT" + "'", str13.equals("ch1kwWYNgi9mbtnzrjMbb1+YjEvfxhxTtgmrXrOUsVhXW82ZVDjNJnLtsCLoPakKdzOiSsjmeogrUPKFYKJdA/iXdz4hLY4nhj1F0ajLkf9SESleBg/2KT3ve0MkCGAT"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str15 = bridgeSecurity4.createWhitelistUser("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UxvDKZLGWU4=" + "'", str13.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        boolean boolean9 = bridgeSecurity4.isSettingsChanged();
        boolean boolean10 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        java.lang.String str7 = bridgeSecurity6.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity6.setPassword(user8);
        bridgeSecurity6.setSettingsChanged(false);
        java.lang.String str13 = bridgeSecurity6.encrypt("SSU/a04q1QOSC5z5iNTT4w==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "xQ6SmWgtvKo=" + "'", str7.equals("xQ6SmWgtvKo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "qfXhchCgbUUexVR06hTJ2R6q5F9VpCfzfFkgUsM2PJU=" + "'", str13.equals("qfXhchCgbUUexVR06hTJ2R6q5F9VpCfzfFkgUsM2PJU="));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        java.lang.String str9 = bridgeSecurity4.getExecGarden();
        java.lang.String str10 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MKvsXKnSSls=" + "'", str7.equals("MKvsXKnSSls="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "xQ6SmWgtvKo=" + "'", str10.equals("xQ6SmWgtvKo="));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSettingsChanged(true);
        bridgeSecurity4.removeTestUsers();
        boolean boolean16 = bridgeSecurity4.isSecureHueApi();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str18 = bridgeSecurity4.findWhitelistUserByDeviceType("xQ6SmWgtvKo=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("");
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UxvDKZLGWU4=" + "'", str13.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.addUser(user17);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        java.lang.String str18 = bridgeSecurity4.createWhitelistUser("YjOtnQ3PuFs=");
        boolean boolean19 = bridgeSecurity4.isSecure();
        bridgeSecurity4.setSecureHueApi(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1367fccb92d749c2a4d819f3a3d28757" + "'", str18.equals("1367fccb92d749c2a4d819f3a3d28757"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.delUser(user14);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = bridgeSecurity4.createWhitelistUser("UxvDKZLGWU4=");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UxvDKZLGWU4=" + "'", str13.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        bridgeSecurity6.setSettingsChanged(true);
        java.lang.String str10 = bridgeSecurity6.encrypt("sPbDAe2fBG+wvoGdpgsr/g==");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hmBRNttW6BSdyGYZiW27SWqnd4KFMcUrUNBTlAW2p1o=" + "'", str10.equals("hmBRNttW6BSdyGYZiW27SWqnd4KFMcUrUNBTlAW2p1o="));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setSecureHueApi(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSecurityData("ch1kwWYNgi9mbtnzrjMbb1+YjEvfxhxTtgmrXrOUsVhXW82ZVDjNJnLtsCLoPakKdzOiSsjmeogrUPKFYKJdA/iXdz4hLY4nhj1F0ajLkf9SESleBg/2KT3ve0MkCGAT");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.Class<?> wildcardClass15 = loginResult14.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str14 = bridgeSecurity4.encrypt("SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = bridgeSecurity4.isSecureHueApi();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=" + "'", str14.equals("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("d95a1f34c7db4f3494ed4828650b1f98");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "xQ6SmWgtvKo=" + "'", str6.equals("xQ6SmWgtvKo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "vmssUO8ALIgBLyHGL+4VnD8e2jfTRQqc/tzChhVH/GAGS29359T9aOtQY1aCp3x3" + "'", str9.equals("vmssUO8ALIgBLyHGL+4VnD8e2jfTRQqc/tzChhVH/GAGS29359T9aOtQY1aCp3x3"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.addUser(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.User user5 = null;
        com.bwssystems.HABridge.LoginResult loginResult6 = bridgeSecurity4.validatePassword(user5);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.removeTestUsers();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity12 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("YjOtnQ3PuFs=");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        java.lang.String str9 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.delUser(user11);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap13 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        bridgeSecurity4.setSecurityData("d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray14 = bridgeSecurity4.validateWhitelistUser("lFGRBLwp6e8pRwJe2IwZwC+Z+rYnrVSet3ip6V5FAl9L1VYOfFmCnYVLijdBgJmDC1KpJ3MUIzN6YjWwWhSaiw==", "1367fccb92d749c2a4d819f3a3d28757", true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray14);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap15 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        java.lang.String str16 = bridgeSecurity4.decrypt("ch1kwWYNgi9mbtnzrjMbb1+YjEvfxhxTtgmrXrOUsVhXW82ZVDjNJnLtsCLoPakKdzOiSsjmeogrUPKFYKJdA/iXdz4hLY4nhj1F0ajLkf9SESleBg/2KT3ve0MkCGAT");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "lFGRBLwp6e8pRwJe2IwZwC+Z+rYnrVSet3ip6V5FAl9L1VYOfFmCnYVLijdBgJmDC1KpJ3MUIzN6YjWwWhSaiw==" + "'", str16.equals("lFGRBLwp6e8pRwJe2IwZwC+Z+rYnrVSet3ip6V5FAl9L1VYOfFmCnYVLijdBgJmDC1KpJ3MUIzN6YjWwWhSaiw=="));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.setPassword(user15);
        spark.Request request17 = null;
        com.bwssystems.HABridge.User user18 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request17, user18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.delUser(user9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        java.lang.String str9 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UxvDKZLGWU4=" + "'", str9.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.setPassword(user17);
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        spark.Request request7 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user8 = bridgeSecurity4.getAuthenticatedUser(request7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        com.bwssystems.HABridge.LoginResult loginResult13 = bridgeSecurity4.validatePassword(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.delUser(user14);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean16 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("ch1kwWYNgi9mbtnzrjMbb1+YjEvfxhxTtgmrXrOUsVhXW82ZVDjNJnLtsCLoPakKdzOiSsjmeogrUPKFYKJdA/iXdz4hLY4nhj1F0ajLkf9SESleBg/2KT3ve0MkCGAT");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+Q+2Q1niroT4jXQf9SQsr4TGm+kIvyOCmMS1UK7nNoDmXuFrQ5+uOcq+3mXZT4f6+MXZb2YKAnEUwFIkO8xvROHkdy6U5heIywrAdMuQu3Li/X2PDLYJn3Sp9ZUZZkJIFsmmCbcLgXpOMWEL+aByKnk0cvUoPkcq3cKXMVOsoYL7xb7K415i1w==" + "'", str8.equals("+Q+2Q1niroT4jXQf9SQsr4TGm+kIvyOCmMS1UK7nNoDmXuFrQ5+uOcq+3mXZT4f6+MXZb2YKAnEUwFIkO8xvROHkdy6U5heIywrAdMuQu3Li/X2PDLYJn3Sp9ZUZZkJIFsmmCbcLgXpOMWEL+aByKnk0cvUoPkcq3cKXMVOsoYL7xb7K415i1w=="));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.addUser(user7);
        java.lang.String str10 = bridgeSecurity4.encrypt("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        spark.Request request15 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user16 = bridgeSecurity4.getAuthenticatedUser(request15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J" + "'", str10.equals("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("d95a1f34c7db4f3494ed4828650b1f98");
        com.bwssystems.HABridge.api.hue.HueError[] hueErrorArray12 = bridgeSecurity4.validateWhitelistUser("UxvDKZLGWU4=", "8447c1505a8b4460acd64978e60929cf", true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "xQ6SmWgtvKo=" + "'", str6.equals("xQ6SmWgtvKo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hueErrorArray12);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        spark.Request request13 = null;
        com.bwssystems.HABridge.User user14 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request13, user14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("YjOtnQ3PuFs=");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.decrypt("b2538fd9459b4c3c8376beaab0848ebc");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        java.lang.String str14 = bridgeSecurity4.encrypt("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J");
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setUseLinkButton(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M" + "'", str14.equals("d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        java.lang.String str12 = bridgeSecurity4.encrypt("hmBRNttW6BSdyGYZiW27SWqnd4KFMcUrUNBTlAW2p1o=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UyhVqTfcIfCUW56cx8xYUdAytwu8QuTiRRJpU8ImrNYB82cqKGLn5D0l2d5WKDHi" + "'", str12.equals("UyhVqTfcIfCUW56cx8xYUdAytwu8QuTiRRJpU8ImrNYB82cqKGLn5D0l2d5WKDHi"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        boolean boolean13 = bridgeSecurity4.isSettingsChanged();
        java.lang.String str14 = bridgeSecurity4.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = bridgeSecurity4.createWhitelistUser("lFGRBLwp6e8pRwJe2IwZwC+Z+rYnrVSet3ip6V5FAl9L1VYOfFmCnYVLijdBgJmDC1KpJ3MUIzN6YjWwWhSaiw==");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        bridgeSecurity6.setSettingsChanged(true);
        java.lang.Class<?> wildcardClass9 = bridgeSecurity6.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YjOtnQ3PuFs=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        bridgeSecurity4.setSecurityData("YjOtnQ3PuFs=");
        java.lang.String str9 = bridgeSecurity4.encrypt("6xl0tmdRTemB2TUl3ojwjh7WC3vvIENdA31l3/WGhL60OneKSEgCvmjX8wbTbK1J");
        java.lang.String str11 = bridgeSecurity4.encrypt("b2538fd9459b4c3c8376beaab0848ebc");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M" + "'", str9.equals("d5Qewmd9CNmAl9UIVbLsS701KV6E9tTEoxdJKweOvy2ktqlBRTkTSxeeA25jk/8MkHuABSgcc9ZD+Ckn0DO4N2mcFoMNdt7M"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "FFAGCw8/FmbYElD0iJ/JsyxyoTrYVaJhkV/GOjliHSOfe8vdztFlwQ==" + "'", str11.equals("FFAGCw8/FmbYElD0iJ/JsyxyoTrYVaJhkV/GOjliHSOfe8vdztFlwQ=="));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        spark.Request request15 = null;
        com.bwssystems.HABridge.User user16 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request15, user16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        java.lang.String str13 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.delUser(user14);
        com.bwssystems.HABridge.User user16 = null;
        java.lang.String str17 = bridgeSecurity4.setPassword(user16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UxvDKZLGWU4=" + "'", str13.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "invalid user object given" + "'", str17.equals("invalid user object given"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.delUser(user13);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        bridgeSecurity4.setSecurityData("SSU/a04q1QOSC5z5iNTT4w==");
        bridgeSecurity4.setSecurityData("z5O5eYyj7Gk=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        spark.Request request6 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user7 = bridgeSecurity4.getAuthenticatedUser(request6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.delUser(user15);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = bridgeSecurity4.isUseLinkButton();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "qfXhchCgbUUexVR06hTJ2R6q5F9VpCfzfFkgUsM2PJU=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        java.lang.String str8 = bridgeSecurity4.getSecurityDescriptorData();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = bridgeSecurity4.decrypt("qfXhchCgbUUexVR06hTJ2R6q5F9VpCfzfFkgUsM2PJU=");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UxvDKZLGWU4=" + "'", str8.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        boolean boolean10 = bridgeSecurity4.isSettingsChanged();
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap11 = bridgeSecurity4.getWhitelist();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        bridgeSecurity4.setSettingsChanged(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        java.lang.String str7 = bridgeSecurity6.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity6.setPassword(user8);
        java.lang.String str10 = bridgeSecurity6.getExecGarden();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "xQ6SmWgtvKo=" + "'", str7.equals("xQ6SmWgtvKo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str10.equals("SSU/a04q1QOSC5z5iNTT4w=="));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.delUser(user6);
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.addUser(user8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = bridgeSecurity4.decrypt("8447c1505a8b4460acd64978e60929cf");
            org.junit.Assert.fail("Expected exception of type javax.crypto.BadPaddingException; message: Given final block not properly padded. Such issues can arise if a bad key is used during decryption.");
        } catch (javax.crypto.BadPaddingException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        java.lang.String str8 = bridgeSecurity3.getSecurityDescriptorData();
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity3.convertWhitelist(strMap9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TmdZ8cEBEN0=" + "'", str8.equals("TmdZ8cEBEN0="));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        com.bwssystems.HABridge.User user17 = null;
        java.lang.String str18 = bridgeSecurity4.addUser(user17);
        spark.Request request19 = null;
        com.bwssystems.HABridge.User user20 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.addAuthenticatedUser(request19, user20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "invalid user object given" + "'", str18.equals("invalid user object given"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        spark.Request request9 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.bwssystems.HABridge.User user10 = bridgeSecurity4.getAuthenticatedUser(request9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MKvsXKnSSls=" + "'", str7.equals("MKvsXKnSSls="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "SSU/a04q1QOSC5z5iNTT4w==");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity8 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "YjOtnQ3PuFs=");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity10 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "UxvDKZLGWU4=");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        bridgeSecurity4.setSecurityData("");
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap9 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.convertWhitelist(strMap9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        boolean boolean15 = bridgeSecurity4.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        boolean boolean7 = bridgeSecurity4.isSettingsChanged();
        com.bwssystems.HABridge.User user8 = null;
        java.lang.String str9 = bridgeSecurity4.delUser(user8);
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity4.validatePassword(user10);
        com.bwssystems.HABridge.User user12 = null;
        java.lang.String str13 = bridgeSecurity4.delUser(user12);
        com.bwssystems.HABridge.User user14 = null;
        java.lang.String str15 = bridgeSecurity4.delUser(user14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "invalid user object given" + "'", str13.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "invalid user object given" + "'", str15.equals("invalid user object given"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str6 = bridgeSecurity4.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user7 = null;
        java.lang.String str8 = bridgeSecurity4.setPassword(user7);
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity4.setPassword(user9);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean11 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UxvDKZLGWU4=" + "'", str6.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        bridgeSecurity4.setSettingsChanged(true);
        java.util.Map<java.lang.String, com.bwssystems.HABridge.api.hue.WhitelistEntry> strMap17 = null;
        // The following exception was thrown during execution in test generation
        try {
            bridgeSecurity4.setWhitelist(strMap17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity3.validatePassword(user8);
        java.lang.Class<?> wildcardClass10 = bridgeSecurity3.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        com.bwssystems.HABridge.LoginResult loginResult14 = bridgeSecurity4.validatePassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        com.bwssystems.HABridge.LoginResult loginResult16 = bridgeSecurity4.validatePassword(user15);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult16);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSecurityData("VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity4.setSettingsChanged(true);
        bridgeSecurity4.removeTestUsers();
        java.lang.Class<?> wildcardClass16 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.setPassword(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        char[] charArray1 = new char[] { '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity3 = new com.bwssystems.HABridge.BridgeSecurity(charArray1, "");
        com.bwssystems.HABridge.User user4 = null;
        java.lang.String str5 = bridgeSecurity3.addUser(user4);
        bridgeSecurity3.setSettingsChanged(true);
        com.bwssystems.HABridge.User user8 = null;
        com.bwssystems.HABridge.LoginResult loginResult9 = bridgeSecurity3.validatePassword(user8);
        com.bwssystems.HABridge.User user10 = null;
        com.bwssystems.HABridge.LoginResult loginResult11 = bridgeSecurity3.validatePassword(user10);
        boolean boolean12 = bridgeSecurity3.isSettingsChanged();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        char[] charArray5 = new char[] { 'a', 'a', '4', 'a', '#' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity7 = new com.bwssystems.HABridge.BridgeSecurity(charArray5, "VhGVPYP/Kst7g7c9g0Epi1nnjpxk8+FRP32f5BOVSs0=");
        bridgeSecurity7.setSettingsChanged(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        com.bwssystems.HABridge.User user6 = null;
        java.lang.String str7 = bridgeSecurity4.addUser(user6);
        java.lang.String str9 = bridgeSecurity4.encrypt("YjOtnQ3PuFs=");
        com.bwssystems.HABridge.User user10 = null;
        java.lang.String str11 = bridgeSecurity4.setPassword(user10);
        java.lang.String str12 = bridgeSecurity4.getSecurityDescriptorData();
        java.lang.Class<?> wildcardClass13 = bridgeSecurity4.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SSU/a04q1QOSC5z5iNTT4w==" + "'", str9.equals("SSU/a04q1QOSC5z5iNTT4w=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid user object given" + "'", str11.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UxvDKZLGWU4=" + "'", str12.equals("UxvDKZLGWU4="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        java.lang.String str12 = bridgeSecurity4.decrypt("YjOtnQ3PuFs=");
        java.lang.String str14 = bridgeSecurity4.decrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        bridgeSecurity4.setSettingsChanged(true);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = bridgeSecurity4.isSecure();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        char[] charArray2 = new char[] { '4', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "hi!");
        bridgeSecurity4.setSettingsChanged(false);
        java.lang.String str8 = bridgeSecurity4.encrypt("");
        com.bwssystems.HABridge.User user9 = null;
        com.bwssystems.HABridge.LoginResult loginResult10 = bridgeSecurity4.validatePassword(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity4.addUser(user11);
        com.bwssystems.HABridge.User user13 = null;
        java.lang.String str14 = bridgeSecurity4.setPassword(user13);
        com.bwssystems.HABridge.User user15 = null;
        java.lang.String str16 = bridgeSecurity4.addUser(user15);
        bridgeSecurity4.setSettingsChanged(false);
        com.bwssystems.HABridge.User user19 = null;
        java.lang.String str20 = bridgeSecurity4.delUser(user19);
        java.lang.String str21 = bridgeSecurity4.getSecurityDescriptorData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "YjOtnQ3PuFs=" + "'", str8.equals("YjOtnQ3PuFs="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(loginResult10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "invalid user object given" + "'", str14.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "invalid user object given" + "'", str16.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "invalid user object given" + "'", str20.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UxvDKZLGWU4=" + "'", str21.equals("UxvDKZLGWU4="));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity6 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str7 = bridgeSecurity6.getExecGarden();
        java.lang.String str8 = bridgeSecurity6.getSecurityDescriptorData();
        com.bwssystems.HABridge.User user9 = null;
        java.lang.String str10 = bridgeSecurity6.delUser(user9);
        com.bwssystems.HABridge.User user11 = null;
        java.lang.String str12 = bridgeSecurity6.addUser(user11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "invalid user object given" + "'", str7.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "xQ6SmWgtvKo=" + "'", str8.equals("xQ6SmWgtvKo="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "invalid user object given" + "'", str10.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "invalid user object given" + "'", str12.equals("invalid user object given"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        char[] charArray2 = new char[] { 'a', ' ' };
        com.bwssystems.HABridge.BridgeSecurity bridgeSecurity4 = new com.bwssystems.HABridge.BridgeSecurity(charArray2, "invalid user object given");
        java.lang.String str5 = bridgeSecurity4.getExecGarden();
        java.lang.String str7 = bridgeSecurity4.encrypt("");
        java.lang.String str8 = bridgeSecurity4.getExecGarden();
        java.lang.String str9 = bridgeSecurity4.getExecGarden();
        java.lang.String str11 = bridgeSecurity4.decrypt("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "invalid user object given" + "'", str5.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MKvsXKnSSls=" + "'", str7.equals("MKvsXKnSSls="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "invalid user object given" + "'", str8.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "invalid user object given" + "'", str9.equals("invalid user object given"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
		System.out.println("END testset at: "+ System.currentTimeMillis());
	}
}
