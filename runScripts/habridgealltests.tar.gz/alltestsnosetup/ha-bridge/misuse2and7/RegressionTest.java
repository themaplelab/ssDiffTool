package randoopTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Parameterized;
import com.github.peterwippermann.junit4.parameterizedsuite.ParameterizedSuite;

@RunWith(ParameterizedSuite.class)
@Suite.SuiteClasses({ RegressionTest0.class})
public class RegressionTest {
@Parameterized.Parameters
    public static Object[][] data() {
        return new Object[1000][0];
    }
    public RegressionTest() {
    }
	
}

